<?php
	session_start();
	unset($_SESSION["Id"]);
	unset($_SESSION["Username"]);
	header("Location:index.php");
?>