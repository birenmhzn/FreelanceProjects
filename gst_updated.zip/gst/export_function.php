<?php
    include('connection.php');
    session_start();

    date_default_timezone_set("Asia/Calcutta");
    $time = date("d/m/Y");

    /** Error reporting */
    error_reporting(E_ALL);




    /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                         PHPExcel CODE STARTS FROM HERE

    --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    set_time_limit(300);


    /** PHPExcel */
    require_once 'PHPExcel-1.8/PHPExcel-1.8/Classes/PHPExcel.php';
    require_once 'PHPExcel-1.8/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';

    // Create new PHPExcel object
    $objPHPExcel = new PHPExcel();
    
    // Set properties
    $objPHPExcel->getProperties()->setCreator("HellbentGST")
                                ->setLastModifiedBy("HellbentGST Software")
                                ->setTitle("Office 2007 XLSX Test Document")
                                ->setSubject("Office 2007 XLSX Test Document")
                                ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
                                ->setKeywords("office 2007 openxml php")
                                ->setCategory("Export File");





    /*-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------


                            Created First Sheet


    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    -------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

    
    //-----------------------------------------     Rename sheet 1   -------------------------------------

    $objPHPExcel->setActiveSheetIndex(0);
    $objPHPExcel->getActiveSheet()->setTitle('Sales');




    /*----------------------------------------------------------------------------------

                            Develop Excel UI first sheet

    ----------------------------------------------------------------------------------*/


    //----------------------------------------     Cell Color    -------------------------------------

    function cellColor($cells, $color)
    {
          global $objPHPExcel;

          $objPHPExcel->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray(array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'startcolor' => array(
                   'rgb' => $color
                )
          ));
        }

    for ($cellColor = 'A'; $cellColor <= 'M'; $cellColor++) 
    {
        $cellColor_format = $cellColor . "1";
        cellColor($cellColor_format , '0000B3');
    }





    //---------------------------------------     Header Cell Value    -------------------------------------

    $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'Sr. Id.')
                ->setCellValue('B1', 'Bill Number')
                ->setCellValue('C1', 'Bill Date')
                ->setCellValue('D1', 'Name')
                ->setCellValue('E1', 'Gst Number')
                ->setCellValue('F1', 'Bill Amount')
                ->setCellValue('G1', 'CGST')
                ->setCellValue('H1', 'CGST Amount')
                ->setCellValue('I1', 'SGST')
                ->setCellValue('J1', 'SGST Amount')
                ->setCellValue('K1', 'Other Amount')
                ->setCellValue('L1', 'Gross Amount')
                ->setCellValue('M1', 'Created By');




    //-----------------------------------     Other cell UI Part   -------------------------------------


    foreach (range('A', $objPHPExcel->getActiveSheet()->getHighestDataColumn()) as $col) 
    {
        $objPHPExcel
        ->getActiveSheet()
        ->getColumnDimension($col)
        ->setAutoSize(true);
    }
    
    $sheet = $objPHPExcel->getActiveSheet();


    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $sheet->getStyle("A1:M1")->applyFromArray($style);

    $styleArray = array(
    'font'  => array(
        'bold'  => true,
        'color' => array('rgb' => 'ffffff')
    ));
    
    $sheet->getStyle('A1:M1')->applyFromArray($styleArray);


    $RowNumber = 2;
    $EndCellNumber = 1;
    $SaleBillAmount = null;
    $SaleCGSTAmount = null;
    $SaleSGSTAmount = null;
    $SaleGrossAmount = null;

    $query = "SELECT 
                b.*, u.Username [CreatedByName] 
                FROM Bill b 
                JOIN dbo.[User] u 
                ON b.CreatedBy = u.[Id] 
                WHERE BillType = '1' 
                AND 
                b.ClientId = '".$_SESSION["ClientId"]."' 
                ORDER BY b.id ASC";  

    $result = sqlsrv_query($connect, $query, array(), array( "Scrollable" => 'static' ));

    while ($row = sqlsrv_fetch_array($result)) 
    {

        $ai = 'A'.$RowNumber;
        $bi = 'B'.$RowNumber;
        $ci = 'C'.$RowNumber;
        $di = 'D'.$RowNumber;
        $ei = 'E'.$RowNumber;
        $fi = 'F'.$RowNumber;
        $gi = 'G'.$RowNumber;
        $hi = 'H'.$RowNumber;
        $ii = 'I'.$RowNumber;
        $ji = 'J'.$RowNumber;
        $ki = 'K'.$RowNumber;
        $li = 'L'.$RowNumber;
        $mi = 'M'.$RowNumber;

        $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($ai, $row["Id"])
                    ->setCellValue($bi, $row["BillNumber"])
                    ->setCellValue($ci, $row["BillDate"])
                    ->setCellValue($di, $row["Name"])
                    ->setCellValue($ei, $row["GstNumber"])
                    ->setCellValue($fi, $row["BillAmount"])
                    ->setCellValue($gi, $row["Cgst"])
                    ->setCellValue($hi, $row["CgstAmount"])
                    ->setCellValue($ii, $row["Sgst"])
                    ->setCellValue($ji, $row["SgstAmount"])
                    ->setCellValue($ki, $row["OtherAmount"])
                    ->setCellValue($li, $row["GrossAmount"])
                    ->setCellValue($mi, $row["CreatedByName"]);

        $RowNumber++;
        $EndCellNumber++;

        $SaleBillAmount = $SaleBillAmount + $row["BillAmount"];
        $SaleCGSTAmount = $SaleCGSTAmount + $row["CgstAmount"];
        $SaleSGSTAmount = $SaleSGSTAmount + $row["SgstAmount"];
        $SaleGrossAmount = $SaleGrossAmount + $row["GrossAmount"];
    }

    $EndCellNumber = $EndCellNumber + 1;



    for ($cellColor = 'A'; $cellColor <= 'M'; $cellColor++) 
    {
        $cellColor_format = $cellColor . $EndCellNumber;
        cellColor($cellColor_format , '000000');
    }

    $sheet->getStyle('A'.$EndCellNumber.':M'.$EndCellNumber)->applyFromArray($styleArray);




    //---------------------------------------     Footer Cell Value    -------------------------------------

    $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A'.$EndCellNumber, '')
                ->setCellValue('B'.$EndCellNumber, '')
                ->setCellValue('C'.$EndCellNumber, '')
                ->setCellValue('D'.$EndCellNumber, '')
                ->setCellValue('E'.$EndCellNumber, 'Total')
                ->setCellValue('F'.$EndCellNumber, $SaleBillAmount)
                ->setCellValue('G'.$EndCellNumber, '')
                ->setCellValue('H'.$EndCellNumber, $SaleCGSTAmount)
                ->setCellValue('I'.$EndCellNumber, '')
                ->setCellValue('J'.$EndCellNumber, $SaleSGSTAmount)
                ->setCellValue('K'.$EndCellNumber, '')
                ->setCellValue('L'.$EndCellNumber, $SaleGrossAmount)
                ->setCellValue('M'.$EndCellNumber, '');







    /*-------------------------------------------------------------------------------------------------------------------------------------------
    -------------------------------------------------------------------------------------------------------------------------------------------
    -------------------------------------------------------------------------------------------------------------------------------------------



                            Created Second Sheet


    -------------------------------------------------------------------------------------------------------------------------------------------
    -------------------------------------------------------------------------------------------------------------------------------------------
    ----------------------------------------------------------------------------------------------------------------------------------------------*/



    $objPHPExcel->createSheet();


    //-----------------------------------     REname sheet 2   -------------------------------------

    $objPHPExcel->setActiveSheetIndex(1);
    $objPHPExcel->getActiveSheet()->setTitle('Purchase');



    /*----------------------------------------------------------------------------------

                            Develop Excel UI for second sheet

    ----------------------------------------------------------------------------------*/



    //----------------------------------------     Cell Color    -------------------------------------

    for ($cellColor = 'A'; $cellColor <= 'M'; $cellColor++) 
    {
        $cellColor_format = $cellColor . "1";
        cellColor($cellColor_format , '0000B3');
    }





    //---------------------------------------     Header Cell Value    -------------------------------------

    $objPHPExcel->setActiveSheetIndex(1)
                ->setCellValue('A1', 'Sr. Id.')
                ->setCellValue('B1', 'Bill Number')
                ->setCellValue('C1', 'Bill Date')
                ->setCellValue('D1', 'Name')
                ->setCellValue('E1', 'Gst Number')
                ->setCellValue('F1', 'Bill Amount')
                ->setCellValue('G1', 'CGST')
                ->setCellValue('H1', 'CGST Amount')
                ->setCellValue('I1', 'SGST')
                ->setCellValue('J1', 'SGST Amount')
                ->setCellValue('K1', 'Other Amount')
                ->setCellValue('L1', 'Gross Amount')
                ->setCellValue('M1', 'Created By');




    //-----------------------------------     Other cell UI Part   -------------------------------------


    foreach (range('A', $objPHPExcel->getActiveSheet()->getHighestDataColumn()) as $col) {
        $objPHPExcel
        ->getActiveSheet()
        ->getColumnDimension($col)
        ->setAutoSize(true);
    }
    
    $sheet = $objPHPExcel->getActiveSheet();
    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );

    $sheet->getStyle("A1:M1")->applyFromArray($style);

    $styleArray = array(
    'font'  => array(
        'bold'  => true,
        'color' => array('rgb' => 'ffffff')
    ));
    
    $sheet->getStyle('A1:M1')->applyFromArray($styleArray);


    $RowNumber = 2;
    $EndCellNumber = 1;
    $PurchaseBillAmount = null;
    $PurchaseCGSTAmount = null;
    $PurchaseSGSTAmount = null;
    $PurchaseGrossAmount = null;

    $query = "SELECT 
                b.*, u.Username [CreatedByName] 
                FROM Bill b 
                JOIN dbo.[User] u 
                ON b.CreatedBy = u.[Id] 
                WHERE BillType = '2' 
                AND 
                b.ClientId = '".$_SESSION["ClientId"]."' 
                ORDER BY b.id ASC"; 

    $result = sqlsrv_query($connect, $query, array(), array( "Scrollable" => 'static' ));
    
    while($row = sqlsrv_fetch_array($result))
    {
        $ai = 'A'.$RowNumber;
        $bi = 'B'.$RowNumber;
        $ci = 'C'.$RowNumber;
        $di = 'D'.$RowNumber;
        $ei = 'E'.$RowNumber;
        $fi = 'F'.$RowNumber;
        $gi = 'G'.$RowNumber;
        $hi = 'H'.$RowNumber;
        $ii = 'I'.$RowNumber;
        $ji = 'J'.$RowNumber;
        $ki = 'K'.$RowNumber;
        $li = 'L'.$RowNumber;
        $mi = 'M'.$RowNumber;

        $objPHPExcel->setActiveSheetIndex(1)
                    ->setCellValue($ai, $row["Id"])
                    ->setCellValue($bi, $row["BillNumber"])
                    ->setCellValue($ci, $row["BillDate"])
                    ->setCellValue($di, $row["Name"])
                    ->setCellValue($ei, $row["GstNumber"])
                    ->setCellValue($fi, $row["BillAmount"])
                    ->setCellValue($gi, $row["Cgst"])
                    ->setCellValue($hi, $row["CgstAmount"])
                    ->setCellValue($ii, $row["Sgst"])
                    ->setCellValue($ji, $row["SgstAmount"])
                    ->setCellValue($ki, $row["OtherAmount"])
                    ->setCellValue($li, $row["GrossAmount"])
                    ->setCellValue($mi, $row["CreatedByName"]);

        $RowNumber++;
        $EndCellNumber++;

        $PurchaseBillAmount = $PurchaseBillAmount + $row["BillAmount"];
        $PurchaseCGSTAmount = $PurchaseCGSTAmount + $row["CgstAmount"];
        $PurchaseSGSTAmount = $PurchaseSGSTAmount + $row["SgstAmount"];
        $PurchaseGrossAmount = $PurchaseGrossAmount + $row["GrossAmount"];
    }

    $EndCellNumber=$EndCellNumber+1;



    for ($cellColor = 'A'; $cellColor <= 'M'; $cellColor++) 
    {
        $cellColor_format = $cellColor . $EndCellNumber;
        cellColor($cellColor_format , '000000');
    }

    $sheet->getStyle('A'.$EndCellNumber.':M'.$EndCellNumber)->applyFromArray($styleArray);




    //---------------------------------------     Footer Cell Value    -------------------------------------

    $objPHPExcel->setActiveSheetIndex(1)
                ->setCellValue('A'.$EndCellNumber, '')
                ->setCellValue('B'.$EndCellNumber, '')
                ->setCellValue('C'.$EndCellNumber, '')
                ->setCellValue('D'.$EndCellNumber, '')
                ->setCellValue('E'.$EndCellNumber, 'Total')
                ->setCellValue('F'.$EndCellNumber, $PurchaseBillAmount)
                ->setCellValue('G'.$EndCellNumber, '')
                ->setCellValue('H'.$EndCellNumber, $PurchaseCGSTAmount)
                ->setCellValue('I'.$EndCellNumber, '')
                ->setCellValue('J'.$EndCellNumber, $PurchaseSGSTAmount)
                ->setCellValue('K'.$EndCellNumber, '')
                ->setCellValue('L'.$EndCellNumber, $PurchaseGrossAmount)
                ->setCellValue('M'.$EndCellNumber, '');



    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter1 = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

    function excel_export($objWriter)
    {

        // Redirect output to a client’s web browser (Excel2007)
        $time = date("d/m/Y");
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="GSTExport'.$time.'.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter->save('php://output');
        echo '<script>window.location="show_data.php";</script>';

    }

    /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                         PHPExcel CODE ENDS HERE

    --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------*/




    /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                         PHPMail CODE STARTS FROM HERE

    --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

    function email($objWriter1)
    {
        
        $time = date("d-m-Y");
        $objWriter1->save('upload/GSTExport.xlsx');
        
        
        $message1 = "GSTExport".$time;
        $email = "dev.hellbent@gmail.com";
        $user_email="dev.hellbent@gmail.com";      
                  
        $encrypt_email = base64_encode($email);
        $decrypt_email = base64_decode($encrypt_email);

        require 'PHPMailer_5.2.0/class.phpmailer.php'; 
        require_once('PHPMailer_5.2.0/class.smtp.php');

        $link = $serveradd.'confirm.php?passkey=' . $code .'&email='.$user_email;
        
        $message = file_get_contents('emailhead.php');
        $message .= '<p>Message: '.$message1.'<br></p>';
        $message .= file_get_contents('emailfoot.php');
        
        include 'mailconfig.php';
           
        $mail->Subject = "GSTExport".$time;
        $mail->AddAddress($user_email);
        $mail->AddAttachment('upload/GSTExport.xlsx');
        
        if(!$mail->Send()) 
        {
            echo '<script>alert("Error to sending File.");
            window.location="show_data.php";</script>';
        } 
        else 
        {
            echo '<script>alert("Your File Send Successfuly.");
            window.location="show_data.php";</script>';
        }

        //echo '<script>window.location="show_data.php";</script>';
        //header('Location: show_data.php');

    }




    /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                         PHPMail CODE ENDS HERE

    --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    --------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

    /*-------------------------------------------------------------------------------------------------------------------------------------------------------------------
                
                                                                        FUNCTION CALL

    -------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

    if(isset($_POST["Email"]))
    {
        email($objWriter1);
    }

    else if(isset($_POST["Export"]))
    {
        excel_export($objWriter);
    }
    else 
    {
        echo 'window.location="show_data.php";</script>';
    }

    exit;
?>