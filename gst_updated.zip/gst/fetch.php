<?php
	include('connection.php');
 
 	$name = $_GET['cname'];
 
	$sql = "SELECT GstNumber FROM bill WHERE Name = '$name'";
 
	$res = sqlsrv_query($connect,$sql);
	 
	$result = array();
	 
	while($row = sqlsrv_fetch_array($res))
	{
	 	array_push($result, 
	 	array('gst_number'=>$row[0]));
	}
	echo json_encode(array('result'=>$result));
	sqlsrv_close($connect);
?>  