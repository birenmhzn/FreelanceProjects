$('#cname').change(function(){
 $.getJSON(
 '../fetch.php',
 'cname='+$('#cname').val(),
 function(result){
 $('#gst_number').empty();
 $.each(result.result, function(){ 	
    document.getElementById('gst_number').value = this['gst_number'];
 });
 }
 );
});