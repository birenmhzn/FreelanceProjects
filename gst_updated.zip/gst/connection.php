<?php 
	//Development
        //these credentials will not work, we need to create a new database and server and then use it.
        //I will give you different credentials.
	$serverName = "sql6003.site4now.net";   
	$uid = "DB_A2BC29_GST_admin";     
	$pwd = "Here98day";    
	$databaseName = "DB_A2BC29_GST";   
	   
	$connection = array( "UID"=>$uid,                              
                         "PWD"=>$pwd,                              
                         "Database"=>$databaseName,
                     	 'ReturnDatesAsStrings'=>true);  //<-- This is the important line

	/* Connect using SQL Server Authentication. */    
	$connect = sqlsrv_connect( $serverName, $connection);
?>