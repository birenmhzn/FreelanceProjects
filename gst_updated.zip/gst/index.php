<?php
    
    include('connection.php');
    
    session_start();
    
    $message = "";
    
    if(count($_POST) > 0) 
    {
        // Fetching the Username and Password  from table
        $result = sqlsrv_query($connect, "SELECT u.Id, u.Username, u.EmailId, c.[Name], c.GSTNumber, 
                u.ClientId,u.IsViewOnly FROM dbo.[User] u 
                JOIN dbo.[Client] c ON u.ClientId = c.Id 
                WHERE u.Username='" . $_POST["username"] . "' and u.Password= '". $_POST["password"]."'");   

        $row = sqlsrv_fetch_array($result);   // Fetched result stored in array called $row

        // is_array will check $row is array or not
        if(is_array($row))
        {
            $_SESSION["Id"] = $row[Id]; // $_SESSION[] array will availabel through out the website
            $_SESSION["Username"] = $row[Username];
            $_SESSION["ClientId"] = $row[ClientId];
            $_SESSION["ClientGSTNumber"] = $row[GSTNumber];
            $_SESSION["IsViewOnly"] = $row[IsViewOnly];
        } 
        else 
        {
            $message = "<script>alert('Invalid Username or Password!');</script>";
        }
    }
    if(isset($_SESSION["Id"])) // isset will check variable is set or not 
    {
        header("Location:select_op.php");   
    }
?>

<html>
    <head>

        <title>User Login</title>

        <link rel="stylesheet" href="css/loginform_style.css" type="text/css" />
        <link rel="stylesheet" href="css/gradientbg.css" type="text/css" />

    </head>
    <body> 
        <form name="frmUser" method="post" action="" align="center">
            <div class="message"><?php if($message!="") { echo $message; } ?></div>
            
            <div class="login">
                <div class="heading">
                    <h2>Sign in</h2>  
                    
                    <div class="input-group input-group-lg">
                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" name="username" class="form-control" placeholder="Username or email" required>
                    </div>

                    <br>

                    <div class="input-group input-group-lg">
                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>

                    <br><br>

                    <button type="submit" class="float">Login</button>
                </div>
            </div>
        </form>
    </body>
</html>