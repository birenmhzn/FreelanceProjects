<?php
	error_reporting(0);
	ini_set('display_errors', 0);
  	include('connection.php');
	session_start();

	$keyword = strval($_POST['query']);
	$search_param = "{$keyword}%";

    $key=$_GET['key'];
    $billNameResult = array();
	$clientId = $_SESSION['ClientId'];
	
    $query=sqlsrv_query($connect, "SELECT DISTINCT Name from bill WHERE Name LIKE '%{$key}%' AND ClientId = '$clientId'");
    while($row=sqlsrv_fetch_array($query))
    {
        $billNameResult[] = $row['Name'];
    }
    echo json_encode($billNameResult);
    sqlsrv_close($connect);
?>