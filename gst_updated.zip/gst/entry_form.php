<?php

    header('Cache-Control: no cache'); //no cache
    session_cache_limiter('private_no_expire'); // works

    session_start();
    
    $billtype=""; 
    $isUpdate = 0;
    
    date_default_timezone_set("Asia/Calcutta");
    
    include('connection.php');

    if($_SESSION["Username"]) 
    {

        $time = date("d/m/Y");
        $BillNumber = null;
        $CustomerName=null;
        $BillDate = null;
        $GSTNumber = null;
        $BillAmount = null;
        $CGSTAmount = null;
        $SGSTAmount = null;
        $OtherAmount = null;
        $GrossAmount = null;
        $ClientGSTNumber = null;
	
        if(isset($_POST["sale"]))
        {
            $billtype = "1";
        } 
        else if(isset($_POST["purchase"]))
        {
            $billtype = "2";
        }
         
        $sql = "SELECT b.Id, b.BillNumber, b.BillDate, b.[Name], B.GstNumber, b.BillAmount, b.Cgst, 
			       b.CgstAmount, b.Sgst, b.SgstAmount, b.OtherAmount, b.GrossAmount, b.BillType, u.Username, b.ClientId, b.Month, b.Year FROM Bill b JOIN dbo.[User] u ON b.CreatedBy = u.[Id] WHERE b.ClientId = '".$_SESSION["ClientId"]."' ORDER BY b.id DESC";

        $result = sqlsrv_query($connect, $sql); // Fetching the query into result
        $row=sqlsrv_fetch_array($result); // stores the result into $row
		
        if(isset($_POST["BillDetails"]))
        {

            $isUpdate = 1;
            $BillId = $_POST["BillId"];

            $sqlFetchExistingBill = "SELECT * FROM Bill WHERE Id = $BillId";
            $resultExistingBill = sqlsrv_query($connect, $sqlFetchExistingBill);

            $exitingBill = sqlsrv_fetch_array($resultExistingBill);
            $BillDate = strtotime($exitingBill["BillDate"]);
            $BillDate = date('d-m-Y',$BillDate);
            $BillNumber = $exitingBill['BillNumber'];

            $CustomerName = $exitingBill['Name'];
            $GSTNumber = $exitingBill['GstNumber'];
            $BillAmount = $exitingBill['BillAmount'];
            $CGSTAmount = $exitingBill['Cgst'];
            $SGSTAmount = $exitingBill['Sgst'];
            $OtherAmount = $exitingBill['OtherAmount'];
            $GrossAmount = $exitingBill['GrossAmount'];
            $billtype = $exitingBill['BillType'];

        }

      /*----------------------------------------------------------------------------------------------------------------*/
?>
<html>
    <head>

        <title>Bill Entry</title>

        <link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/entry_form.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script type="text/javascript" src="js/typeahead.js"></script>

        <!------ Include the above in your HEAD tag ---------->


        <script>
            function validateForm() 
            {
            
                var val_bill_number= document.forms["myForm"]["bill_number"].value;
                var val_name1 = document.forms["myForm"]["brand"].value;
                var val_name = val_name1.toString();
                var val_gst_number = document.forms["myForm"]["item"].value;
                
                if (val_bill_number == "") 
                {
                    alert("Bill Number must be filled out");
                    return false;
                }
                else if (val_name == "") 
                {
                    alert("Name must be filled out");
                    return false;
                }
                else if (val_gst_number == "") 
                {
                    alert("GST Number must be filled out");
                    return false;
                }

            }

            function stringlength(inputtxt, minlength, maxlength)
            { 
                var field = inputtxt.value; 
                var mnlen = minlength;
                var mxlen = maxlength;
                if(field.length<mnlen || field.length> mxlen)
                { 
                    alert("Please Enter Correct GST Number.");
                    return false;
                }
                else
                { 
                    //alert('Your userid have accepted.');
                    return true;
                }
            }
        </script>
    </head>
    <body onload='document.myForm.gst_number.focus();'>


        <div class="container" style="float: right;border: 0px solid black;width: 15%;"></div>

        <div class="container"> 
            <center>
                <div class="container">

                <div class="row">
                    <div class="col-md-12" style="border:0px solid black;">
                        <font style="color:black;font-size:250%;font-weight: bold;margin-left: 21%;">Bill Details</font>
                        <a href="logout.php"><button class="log_button" style="float: right;vertical-align:middle;width: 170px;padding: 7px;" name="logout"><span>Logout</span></button></a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6" style="border:0px solid black;">
                        <button onclick="history.go(-1);" type="button" class="log_button btn btn-success" style="width: 170px;padding: 7px;background-color: #0000B3;float: left;">Back</button>
                    </div>
                    <div class="col-md-6" style="border:0px solid black;">
                        <button type="button" onclick="myFunction()" class="log_button btn btn-success" style="width: 170px;padding: 7px;background-color: #0000B3;float: right;">Reset</button>
                    </div>
                </div>

                <div class="container">

                    <form action="store_data.php" method="post" autocomplete="off" onsubmit="return validateForm()" id="myForm" name="myForm">
                        <h4>
                            <input type="radio" name="bill_type" value="sale" id="sale" checked> Sale&nbsp;&nbsp;&nbsp;<input id="purchase" type="radio" name="bill_type" value="purchase"> Purchase
                        </h4>

                        <br><br>
                        
                        <?php if($billtype == "1") 
                        { ?>
                        
                            <script>
                                document.getElementById("sale").checked = true;
                                document.getElementById("purchase").disabled = true;
                            </script>

                        <?php } else if($billtype == "2") { ?>
                            
                            <script>
                                document.getElementById("purchase").checked = true;
                                document.getElementById("sale").disabled = true;
                            </script>

                        <?php } ?>

                        <div class="row r-pad-left-5">
                            <!-- Include Bootstrap Datepicker -->
                            <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css" />
                            <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css" />

                            <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>

                            <div class="col-md-2"></div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Bill Number</label>
                                    <input type="text" class="form-control" placeholder="Bill Number..." id="bill_number" name="bill_number" value="<?php echo $BillNumber; ?>"required>
                                </div>
                            </div>


                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Bill Date</label>
                                    <div class="input-group input-append date" id="datePicker">
                                        <input type="text" class="form-control" id="frmDate" name="bill_date" value="<?php echo $BillDate; ?>">
                                        <span class="input-group-addon span-cal-border-none">
                                              <span class="glyphicon glyphicon-calendar txtboxItem"></span>
                                        </span>

                                        <script>

                                            <?php if ($isUpdate == 0) { ?>

                                                var datestring;
                                                function getDate()
                                                {
                                                    var todaydate = new Date();
                                                    var day = todaydate.getDate();
                                                    var month = todaydate.getMonth();
                                                    var year = todaydate.getFullYear();
                                                    datestring = day + "-" + month + "-" + year;
                                                    document.getElementById("frmDate").value = datestring; 
                                                } 
                                                getDate();

                                            <?php } ?>

                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row r-pad-left-5">

                            <div class="col-md-1"></div>
                          
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control typeahead cname"id="cname" placeholder="Enter Name..." name="name" value="<?php echo $CustomerName; ?>" required />
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">GST Number</label>
                                    <input type="text" class="form-control" placeholder="GST Number..."id="gst_number" maxlength="15" minlength="15" name="gst_number" value="<?php echo $GSTNumber; ?>" required />
                                </div>
                            </div>
                            				
                            <script>
                                $(document).ready(function () 
                                {
                                    $('.cname').typeahead({
                                        source: function (query, result) 
                                        {
                                            $.ajax({
                                                url: "server.php",
                                                data: 'query=' + query,
                                                dataType: "json",
                                                type: "POST",
                                                success: function (data) 
                                                {
                                                    result($.map(data, function (gst_number) 
                                                    {
                                                        return gst_number;
                                                    }));
                                                }
                                            });
                                        }
                                    });
                                });
                            </script>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Bill Amount</label>
                                    <input type="number" class="form-control" placeholder="Bill Amount..."id="bill_amount" name="bill_amount" value="<?php echo $BillAmount; ?>" min="0" required>
                                </div>
                            </div>
                        </div>


                        <div class="row r-pad-left-5">

                            <div class="col-md-1"></div>
                            
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">CGST</label>
                                    <input type="number" class="form-control" step=".01" placeholder="CGST..."id="cgst" name="cgst" min="0" max="100" value="<?php echo $CGSTAmount; ?>" required>
                                </div>
                                <br>
                            </div>


                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">SGST</label>
                                    <input type="number" class="form-control" step=".01" placeholder="SGST..."id="sgst" name="sgst" min="0" max="100" value="<?php echo $SGSTAmount; ?>" required>
                                </div>
                                <br>
                                <script type="text/javascript">

                                    var $cgst_f = $("#cgst");
                                    var $sgst_f = $("#sgst");

                                    $cgst_f.data("value", $cgst_f.val());
                                    $sgst_f.data("value", $sgst_f.val());

                                    setInterval(function() 
                                    {
                                        var dataamountcgst = $cgst_f.data("value"),valamountcgst = $cgst_f.val();
                                        var dataamountsgst = $sgst_f.data("value"),valamountsgst = $sgst_f.val();
                                        if (dataamountcgst !== valamountcgst)
                                        {
                                            var cgst_f=$cgst_f.data("value", valamountcgst);
                                            var cgstabs = Math.abs(valamountcgst);
                                            $("#sgst").val(cgstabs); 
                                        }
                                        if (dataamountsgst !== valamountsgst) 
                                        {
                                            var sgst_f=$sgst_f.data("value", valamountsgst);
                                            var sgstabs = Math.abs(valamountsgst);
                                            $("#cgst").val(sgstabs);
                                        }
                                    }, 100);

                                </script>
                            </div>


                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Other Amount</label>
                                    <input type="number" class="form-control" placeholder="Other Amount..."id="other_amount" name="other_amount" value="<?php echo $OtherAmount; ?>" required>
                                </div>
                            </div>

                        </div>


                        <div class="row r-pad-left-5">

                            <div class="col-md-4"></div>
                          
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="name">Total Amount</label>
                                    <input type="text" class="form-control" placeholder="Gross Amount..."id="gross_amount" name="gross_amount" value="<?php echo $GrossAmount; ?>">
                                </div>
                            </div>
                        </div>

                        <script type="text/javascript">

                            var $cgst = $("#cgst");
                            var $sgst = $("#sgst");
                            var $bill_amount = $("#bill_amount");
                            var $other_amount = $("#other_amount");

                            $cgst.data("value", $cgst.val());
                            $sgst.data("value", $sgst.val());
                            $bill_amount.data("value", $bill_amount.val());
                            $other_amount.data("value", $other_amount.val());

                            setInterval(function() 
                            {
                                var dataamount_cgst = $cgst.data("value"),valamount_cgst = $cgst.val();
                                var dataamount_sgst = $sgst.data("value"),valamount_sgst = $sgst.val();
                                var dataamount_bill_amount = $bill_amount.data("value"),valamount_bill_amount = $bill_amount.val();
                                var dataamount_other_amount = $other_amount.data("value"),valamount_other_amount = $other_amount.val();

                                if (dataamount_bill_amount !== valamount_bill_amount) 
                                {

                                    var cgst1=$cgst.data("value", valamount_cgst);
                                    var sgst1=$sgst.data("value", valamount_sgst);
                                    var bill_amount1=$bill_amount.data("value", valamount_bill_amount);
                                    var other_amount1=$other_amount.data("value", valamount_other_amount);

                                    var cgst = Math.abs(valamount_cgst);
                                    var sgst = Math.abs(valamount_sgst);
                                    var bill_amount = Math.abs(valamount_bill_amount);
                                    var other_amount = Math.abs(valamount_other_amount);

                                    var cgst = parseFloat(valamount_cgst);
                                    var sgst = parseFloat(valamount_sgst);
                                    var bill_amount = parseFloat(valamount_bill_amount);
                                    var other_amount = parseFloat(valamount_other_amount);

                                    var calc_cgst1 = cgst/100;
                                    var calc_sgst2 = sgst/100;

                                    var calc_cgst = calc_cgst1*bill_amount;
                                    var calc_sgst = calc_sgst2*bill_amount;

                                    var total1 = bill_amount+calc_cgst;
                                    var total = total1+calc_sgst;
                                    var grand_total1 = total+other_amount;

                                    var grand_total = grand_total1.toFixed(2);

                                    $("#gross_amount").val(grand_total);

                                }

                                if (dataamount_cgst !== valamount_cgst) 
                                {

                                    var cgst1=$cgst.data("value", valamount_cgst);
                                    var sgst1=$sgst.data("value", valamount_sgst);
                                    var bill_amount1=$bill_amount.data("value", valamount_bill_amount);
                                    var other_amount1=$other_amount.data("value", valamount_other_amount);

                                    var cgst = parseFloat(valamount_cgst);
                                    var sgst = parseFloat(valamount_sgst);
                                    var bill_amount = parseFloat(valamount_bill_amount);
                                    var other_amount = parseFloat(valamount_other_amount);

                                    var cgst = Math.abs(valamount_cgst);
                                    var sgst = Math.abs(valamount_sgst);
                                    var bill_amount = Math.abs(valamount_bill_amount);
                                    var other_amount = Math.abs(valamount_other_amount);

                                    var calc_cgst1 = cgst/100;
                                    var calc_sgst2 = sgst/100;

                                    var calc_cgst = calc_cgst1*bill_amount;
                                    var calc_sgst = calc_sgst2*bill_amount;

                                    var total1 = bill_amount+calc_cgst;
                                    var total = total1+calc_sgst;
                                    var grand_total1 = total+other_amount;

                                    var grand_total = grand_total1.toFixed(2);

                                    $("#gross_amount").val(grand_total); 

                                }

                                if (dataamount_sgst !== valamount_sgst) 
                                {

                                    var cgst1=$cgst.data("value", valamount_cgst);
                                    var sgst1=$sgst.data("value", valamount_sgst);
                                    var bill_amount1=$bill_amount.data("value", valamount_bill_amount);
                                    var other_amount1=$other_amount.data("value", valamount_other_amount);

                                    var cgst = parseFloat(valamount_cgst);
                                    var sgst = parseFloat(valamount_sgst);
                                    var bill_amount = parseFloat(valamount_bill_amount);
                                    var other_amount = parseFloat(valamount_other_amount);

                                    var cgst = Math.abs(valamount_cgst);
                                    var sgst = Math.abs(valamount_sgst);
                                    var bill_amount = Math.abs(valamount_bill_amount);
                                    var other_amount = Math.abs(valamount_other_amount);

                                    var calc_cgst1 = cgst/100;
                                    var calc_sgst2 = sgst/100;

                                    var calc_cgst = calc_cgst1*bill_amount;
                                    var calc_sgst = calc_sgst2*bill_amount;

                                    var total1 = bill_amount+calc_cgst;
                                    var total = total1+calc_sgst;
                                    var grand_total1 = total+other_amount;

                                    var grand_total = grand_total1.toFixed(2);

                                    $("#gross_amount").val(grand_total);

                                }
                                if (dataamount_other_amount !== valamount_other_amount) 
                                {

                                    var cgst1=$cgst.data("value", valamount_cgst);
                                    var sgst1=$sgst.data("value", valamount_sgst);
                                    var bill_amount1=$bill_amount.data("value", valamount_bill_amount);
                                    var other_amount1=$other_amount.data("value", valamount_other_amount);

                                    var cgst = parseFloat(valamount_cgst);
                                    var sgst = parseFloat(valamount_sgst);
                                    var bill_amount = parseFloat(valamount_bill_amount);
                                    var other_amount = parseFloat(valamount_other_amount);

                                    var cgst = Math.abs(valamount_cgst);
                                    var sgst = Math.abs(valamount_sgst);
                                    var bill_amount = Math.abs(valamount_bill_amount);
                                    var other_amount = Math.abs(valamount_other_amount);

                                    var calc_cgst1 = cgst/100;
                                    var calc_sgst2 = sgst/100;

                                    var calc_cgst = calc_cgst1*bill_amount;
                                    var calc_sgst = calc_sgst2*bill_amount;

                                    var total1 = bill_amount+calc_cgst;
                                    var total = total1+calc_sgst;
                                    var grand_total1 = total+other_amount;

                                    var grand_total = grand_total1.toFixed(2);

                                    $("#gross_amount").val(grand_total); 

                                }

                            }, 100);
                        </script>

                        <span class="form-group">

                            <center>
                                <?php if ($isUpdate == 0) { ?>

                                    <button class="btn log_button" id='butSubmit'style="width: 170px;padding: 7px;background-color: #0000B3;" value="Submit" name="butSubmit" onclick="stringlength(document.myForm.gst_number,15,15)"> 
                                        Submit
                                    </button>

                                <?php } else { ?>

                                    <button class="btn log_button" id='butUpdate'style="width: 170px;padding: 7px;background-color: #0000B3;" value="Update" name="butUpdate" onclick="stringlength(document.myForm.gst_number,15,15)">
                                        Update
                                    </button>

                                <?php } ?>
                            </center>

                        </span>
                    </form>
                </div>
            </center>
        </div>

        <script>

            $(document).ready(function() 
            {

                $('#datePicker')
                .datepicker({
                    format: 'dd-mm-yyyy'
                })

                .on('changeDate', function(e) 
                {
                    // Revalidate the date field
                    $('#eventForm').formValidation('revalidateField', 'date');
                    exit(); 
                });

                $('#eventForm').formValidation({

                    framework: 'bootstrap',
                    icon: 
                    {
                        valid: 'glyphicon glyphicon-ok',
                        invalid: 'glyphicon glyphicon-remove',
                        validating: 'glyphicon glyphicon-refresh'
                    },
                    fields: 
                    {
                        name: 
                        {
                            validators: 
                            {
                                notEmpty: 
                                {
                                message: 'The name is required'
                                }
                            }
                        },

                        date: 
                        {
                            validators: 
                            {
                                notEmpty: 
                                {
                                    message: 'The date is required'
                                },
                                date: 
                                {
                                    format: 'DD-MM-YYYY',
                                    message: 'The date is not a valid'
                                }
                            }
                        }
                    }
                });
            });

        </script>

        <script>
        
            $('#cname').change(function()
            {
                $.getJSON(
                    'fetch.php',
                    'cname='+$('#cname').val(),
                    function(result)
                    {
                        $('#gst_number').empty();
                        $.each(result.result, function()
                        {
                            document.getElementById('gst_number').value = this['gst_number'];
                        });
                    }
                );
            });

            function myFunction() 
            {
                document.getElementById("myForm").reset();
                var choosetype = '<?php echo $billtype; ?>';
                
                if (choosetype == "1") 
                {
                    document.getElementById("sale").checked = true;
                    document.getElementById("purchase").disabled = true;
                }
                else if (choosetype == "2") 
                {
                    document.getElementById("purchase").checked = true;
                    document.getElementById("sale").disabled = true;
                }
            }

        </script>
    </body>
</html>

<?php
    }
    else echo "<script>alert('Please login first!!');</script>";
?>