<?php

    header('Cache-Control: no cache'); //no cache
    session_cache_limiter('private_no_expire'); // works
    
    session_start();

    if($_SESSION["Username"])
    {
        $btnname = null;
        
        $url = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    
        $posted_bill_type = null;

        if (strpos($url, '?') !== false) 
        {
            $myArray = explode('?', $url);
            $posted_bill_type = $myArray[1];
        }


        if(isset($_POST["sale"]) || $posted_bill_type == '1')
        { 
            $btnname = "1"; 
        }
        
        if(isset($_POST["purchase"]) || $posted_bill_type == '2')
        { 
            $btnname = "2"; 
        }
        
        include('connection.php');

        //query for fetch the result from table
        $select_query = "SELECT b.Id, b.BillNumber, b.BillDate, b.[Name], B.GstNumber,
                        b.BillAmount, b.Cgst,	b.CgstAmount, b.Sgst, b.SgstAmount,
                        b.OtherAmount, b.GrossAmount, b.BillType, u.Username,
                        b.ClientId, b.Month, b.Year FROM Bill b 
                        JOIN dbo.[User] u ON b.CreatedBy = u.[Id]
                        WHERE BillType = '".$btnname."' AND b.ClientId = '".$_SESSION["ClientId"]."' ORDER BY b.id DESC"; 
        
        	
        $select_result = sqlsrv_query($connect, $select_query); //fetch the query into $select_result

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Show Bill data</title>

        <link rel = "stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <script type = "text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type = "text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <link rel = "stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
        <link rel = "stylesheet" type="text/css" href="css/button.css" />
        <link rel = "stylesheet" type="text/css" href ="css/show_data.css">
        <script src = "https://www.w3schools.com/lib/w3.js"></script>

        <script type="text/javascript">

            ;
             
            (function($) 
            {
                $.fn.fixMe = function() 
                {
                    return this.each(function() 
                    {
                        var $this = $(this),
                        $t_fixed;

                        function init() 
                        {
                            $this.wrap('<div class="container" />');
                            $t_fixed = $this.clone();
                            $t_fixed.find("tbody").remove().end().addClass("fixed").insertBefore($this);
                            resizeFixed();
                        }

                        function resizeFixed() 
                        {
                            $t_fixed.find("th").each(function(index) 
                            {
                                $(this).css("width",$this.find("th").eq(index).outerWidth()+"px");
                            });
                        }

                        function scrollFixed() 
                        {
                            var offset = $(this).scrollTop(),
                                tableOffsetTop = $this.offset().top,
                                tableOffsetBottom = tableOffsetTop + $this.height() - $this.find("thead").height();
                            
                            if(offset < tableOffsetTop || offset > tableOffsetBottom)
                                $t_fixed.hide();
                            else if(offset >= tableOffsetTop && offset <= tableOffsetBottom && $t_fixed.is(":hidden"))
                                $t_fixed.show();
                        }

                        $(window).resize(resizeFixed);
                        $(window).scroll(scrollFixed);
                        init();
                    });
                };
            })(jQuery);

            $(document).ready(function()
            {
                $("table").fixMe();
                $(".up").click(function() 
                {
                    $('html, body').animate({
                        scrollTop: 0
                    }, 2000);
                });
            });

        </script>
     
    </head>
    <body>

        <div class="container">

            <div id="jquery-script-menu">

                <table id="table_format" class="table-responsive table table-bordered blue tblData">

                    <thead>

                        <tr style="border: none;background-color: white;border-right: 15px solid white;border-top: 3px solid white;border-left: 3px solid white;">
                            <td colspan="10" style="border: none;background-color: white;">
                                <center>
                                    <font style="color:black;font-size:250%;font-weight: bold;" align="center">Summary</font>
                                </center>
                            </td>
                            
                            <td colspan="5" style="border: none;background-color: white;">
                                <center>
                                    <a href="logout.php"><input class="button" style="vertical-align:middle,font-size: 70%;width: 170px;padding: 7px;" name="logout" value="Logout"></a>
                                </center>
                            
                            </td>
                        </tr>

                        <tr style="border: none;background-color: white;border-right: 15px solid white;border-top: 0px solid white;border-left: 3px solid white;">
                            <td colspan="2" style="border: none;background-color: white;">
                                <center>
                                   <input onclick="history.go(-1);" type="submit" class="button" style="vertical-align:middle" value="Back">
                                </center>
                            </td>

                            <td colspan="2" style="border: none;background-color: white;">
                                <center>
                                    <form method="post" action="export_function.php">
                                        <input type="submit" id="email" class="button" style="vertical-align:middle" value="E-Mail" name="Email"><!--<span>E-Mail</span></button>-->
                                    </form>
                                </center>
                            </td>
                            
                            <td colspan="2" style="border: none;background-color: white;">
                                <form method="post" action="export_function.php">
                                    <input type="submit"id="export" name="Export" class="button" style="vertical-align:middle" value="Export"><!--<span>Export</span></button>-->
                                </form>
                            </td>

                            <th colspan="1" style="border: none;background-color: white;"> </th>
                            
                            <!--<th class="ab" colspan="4" style="border: none;background-color: white;">
                                Month
                            </th>
                            
                            <th class="ab" colspan="4" style="border: none;background-color: white;">
                                Year
                            </th>-->
                        </tr>

                        <tr>
                            <th style="cursor:pointer;">ID </th>
                            <!-- for sort button <th class="tab_header" style="cursor:pointer;">ID </th>-->
                            <th style="cursor:pointer;">Bill Number </th>
                            <th style="cursor:pointer;">Bill Date </th>
                            <th style="cursor:pointer">Name </th>
                            <th style="cursor:pointer;">GST Number </th>
                            <th style="cursor:pointer;">Bill Amount </th>
                            <th style="cursor:pointer">CGST </th>
                            <th style="cursor:pointer;">CGST Amount </th>
                            <th style="cursor:pointer">SGST </th>
                            <th style="cursor:pointer;">SGST Amount </th>
                            <th style="cursor:pointer;">Other Amount </th>
                            <th style="cursor:pointer;">Total Amount </th>
                            <th style="cursor:pointer;">Bill Type</th>
                            <th style="cursor:pointer;">Entered By</th>
                            <th style="cursor:pointer;border-right: 15px solid white;">Action</th>
                            <th style="cursor:pointer;display:none;">Month </th>
                            <th style="cursor:pointer;display:none;">Year </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                            while($row = sqlsrv_fetch_array($select_result)) // stores the result into $row
                            {
                                $bill_type = "";
                                if($row["BillType"] == "1")
                                {
                                    $bill_type = "Sale";
                                }
                                else if ($row["BillType"] == "2") 
                                {
                                    $bill_type = "Purchase";
                                }

                                $bill_date = strtotime($row["BillDate"]);
                                $bill_date = date('d-m-Y',$bill_date);
                                $bill_month = strtotime($bill_date);
                                $bill_month_Ext = date('m',$bill_month);
                                $current_month = strtotime(date("d-m-Y"));
                                $current_month_Ext = date('m',$current_month);
                                $previous_month = $current_month_Ext-1;

                                 
                                if($bill_month_Ext == $previous_month) //shows the data from $row 
                                {
                                    echo '
                                        <tr>
                                            <td class="tfdata" style="display:none"><font style="text-align:center;">'.$row["Month"].'</font></td>
                                            <td class="tfdata" style="display:none"><font style="text-align:center;">'.$row["Year"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["Id"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["BillNumber"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$bill_date.'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["Name"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["GstNumber"].'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["BillAmount"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["Cgst"].'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["CgstAmount"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$row["Sgst"].'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["SgstAmount"].'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["OtherAmount"].'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["GrossAmount"].'</font></td>
                                            <td class="tfdata"><font style="text-align:center;">'.$bill_type.'</font></td>
                                            <td class="tfdata"><font style="float:right;">'.$row["Username"].'</font></td>

                                            <form method="post" id="action" action="entry_form.php">
                                                <input type="hidden" name="BillId" value='.$row["Id"].' required>
                                                <td class="tfdata">
                                                    <span style="float:right;">
                                                        <input type="submit" name="BillDetails" value="Edit">
                                                    </span>
                                                </td>
                                            </form>
                                        </tr>
                                    ';
                                }
                            }
                        ?>
                    </tbody>
                </table>
                <br/>
            </div>
        </div>
        
            <!--<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>-->

            <script src="js/filter.js"></script>
            <script>
                jQuery('#table_format').ddTableFilter();
            </script>
        </div>
    </body>
</html>


<?php
    }
    else echo "<script>alert('Please login first!!');</script>";
?>
