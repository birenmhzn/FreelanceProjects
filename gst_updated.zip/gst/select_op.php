<?php

    header('Cache-Control: no cache'); //no cache
    session_cache_limiter('private_no_expire'); // works
    
    session_start();
    if($_SESSION["Username"]) {
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Homepage</title>    

        <link rel="stylesheet" type="text/css" href="library/font-awesome-4.3.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300" type="text/css" />
        <!-- loadnig the bootstrap -->
        <link rel="stylesheet" type="text/css" href="css/select_op.css">
       
    </head>
    <body>

  <div class="container" style="float: right;border: 0px solid black;width: 15%;">
    <a href="logout.php"><button class="button" style="vertical-align:middle,font-size: 70%;width: 170px;padding: 7px;" name="logout"><span>Logout</span></button></a>
  </div>
        <center>
            <div class="center">
                <div class="container p" style="vertical-align: middle;">
                    <div class="row">
                      
                        <div class="col-sm-1"></div>

              					<?php 
              						if ($_SESSION["IsViewOnly"] == 0){ ?>
                            <div class="row">
                                
                                <div class="col-sm-3"></div>

                                <div class="col-sm-2">
                                    <form action="entry_form.php" method="post">
                                        <button class="button" style="vertical-align:middle;" name="sale"><span>Sales Entry </span></button>
                                    </form>                        
                                </div>

                                <div class="col-sm-1"></div>
                                    
                                <div class="col-sm-2">
                                    <form action="entry_form.php" method="post">
                                        <button class="button" style="vertical-align:middle;" name="purchase"><span>Purchase Entry </span></button>
                                    </form>
                                </div>

                            </div>

                            <br>
                            <br>

                            <div class="col-sm-1"></div>

                            <div class="row">

                                <div class="col-sm-3"></div>

                                <div class="col-sm-2">
                                    <form action="show_data.php" method="post">
                                        <button class="button" style="vertical-align:middle" name="sale"><span>View Sales Entries </span></button>
                                    </form>
                                </div>

                                <div class="col-sm-1"></div>
                                
                                <div class="col-sm-2">
                                    <form action="show_data.php" method="post">
                                        <button class="button" style="vertical-align:middle" name="purchase"><span>View Purchase Entries </span></button>
                                    </form>
                                </div>
                            </div>
                            
              							
                            
              					
                        <?php 	} else { ?>
              					
                        		<div>
                                <form action="show_data.php" method="post">
                                    <button class="button" style="vertical-align:middle" name="sale"><span>View Sales Entries </span></button>
                                </form>
              							</div>
                            
                            <div>
                                <form action="show_data.php" method="post">
                                    <button class="button" style="vertical-align:middle" name="purchase"><span>View Purchase Entries </span></button>
                                </form>
                            </div>
              					<?php }?>
                        
                        
                    </div>
                </div>
            </div>
        </center>
    </body>
</html>
<?php
    }
    else echo "<script>alert('Please login first!!');</script>";  
?>