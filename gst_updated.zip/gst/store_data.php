<?php
    session_start();
    include('connection.php');

    if(isset($_POST["sale"]))// Set the bill type as sale
    {
        $billtype = "1";
    }
    else if(isset($_POST["purchase"])) // Set the bill type as purchase
    {
        $billtype = "2";
    }
     

    /* isset will check variable is set or not values in the form is fetch into following variables by $_POST[] */
    if(isset($_POST["butSubmit"])) 
    {
    
        $bill_type1 = $_POST["bill_type"];
        $bill_number = $_POST["bill_number"];
        $bill_date = $_POST["bill_date"];
        $name = $_POST["name"];
        $gst_number = $_POST["gst_number"];
        $bill_amount = $_POST["bill_amount"];
        $cgst = $_POST["cgst"];
        $sgst = $_POST["sgst"];
        $other_amount = $_POST["other_amount"];
        $client_id = $_SESSION["ClientId"];
        $created_by = $_SESSION["Id"];

        $bill_date = date("Y-m-d", strtotime($bill_date));
        $month_year = explode("-",$bill_date);
        $year = $month_year[0];
        $month1 = $month_year[1];


        switch ($month1) 
        {
            case "01":
                $month = "January";
                break;
            
            case "02":
                $month = "February";
                break;
            
            case "03":
                $month = "March";
                break;
            
            case "04":
                $month = "April";
                break;
            
            case "05":
                $month = "May";
                break;
            
            case "06":
                $month = "June";
                break;
            
            case "07":
                $month = "July";
                break;
            
            case "08":
                $month = "August";
                break;
            
            case "09":
                $month = "September";
                break;
            
            case "10":
                $month = "October";
                break;
            
            case "11":
                $month = "November";
                break;
            
            case "12":
                $month = "December";
                break;
        }
        
        $calc_cgst = ($cgst / 100) * $bill_amount;
        $calc_sgst = ($sgst / 100) * $bill_amount;
        $total = $bill_amount + $calc_cgst + $calc_sgst;
        $grand_total = $total + $other_amount;
        $bill_type = "";

        if($bill_type1 == "sale")// set the bill type as sale
        {
            $bill_type = "1";
        }
        else if ($bill_type1 == "purchase")//set the bill type as purchase 
        {
            $bill_type = "2"; 
        }

        
        /* insert query that will insert the values into bill table */

        $insert_query = "INSERT INTO Bill(BillNumber,BillDate,Name,GstNumber,BillAmount,Cgst,CgstAmount,Sgst,SgstAmount,OtherAmount,GrossAmount,BillType,Month,Year,ClientId,CreatedBy) VALUES('$bill_number', '$bill_date','$name','$gst_number','$bill_amount','$cgst','$calc_cgst','$sgst','$calc_sgst','$other_amount','$grand_total','$bill_type','$month','$year',
        '$client_id','$created_by')"; 


        $insert_result = sqlsrv_query($connect, $insert_query);
        header("location: show_data.php?".$bill_type);

    }

    //----------------------------------------------------------------------------------//


    /* isset will check variable is set or not updated values in the form is fetch into following variables */
    if(isset($_POST["butUpdate"]))
    {

        $bill_id1_updt=$_POST['Id'];
        $bill_type1_updt = $_POST["bill_type"];
        $bill_number1_updt = $_POST["bill_number"];
        $bill_date1_updt = $_POST["bill_date"];
        $name1_updt = $_POST["name"];
        $gst_number1_updt = $_POST["gst_number"];
        $bill_amount1_updt = $_POST["bill_amount"];
        $cgst1_updt = $_POST["cgst"];
        $sgst1_updt = $_POST["sgst"];
        $other_amount1_updt = $_POST["other_amount"];
        $client_id1_updt = $_SESSION["ClientId"];
        $created_by1_updt = $_SESSION["Id"];

        $bill_date1_updt = date("Y-m-d", strtotime($bill_date1_updt));
        $month_year1_updt = explode("-",$bill_date1_updt);
        $year1_updt = $month_year[0];
        $month2_updt = $month_year[1];

        switch ($month2_updt) 
        {
            case "01":
                $month = "January";
                break;
            
            case "02":
                $month = "February";
                break;
            
            case "03":
                $month = "March";
                break;
            
            case "04":
                $month = "April";
                break;
            
            case "05":
                $month = "May";
                break;
            
            case "06":
                $month = "June";
                break;
            
            case "07":
                $month = "July";
                break;
            
            case "08":
                $month = "August";
                break;
            
            case "09":
                $month = "September";
                break;
            
            case "10":
                $month = "October";
                break;
            
            case "11":
                $month = "November";
                break;
            
            case "12":
                $month = "December";
                break;
        }

        $calc_cgst1_updt = ($cgst1_updt / 100) * $bill_amount1_updt;
        $calc_sgst1_updt = ($sgst1 / 100) * $bill_amount1_updt;
        $total1_updt = $bill_amount1_updt + $calc_cgst1_updt + $calc_sgst1_updt;
        $grand_total1_updt = $total1_updt + $other_amount1_updt;
        $bill_type = "";

        if($bill_type1_updt == "sale") // Set the bill type as sale
        {
            $bill_type = "1";
        }
        else if ($bill_type1_updt == "purchase")// Set the bill type as purchase 
        {
            $bill_type = "2"; 
        }

        /* Update query that will update the values in existing bill */

        $update_query = "UPDATE Bill
                        SET 
                        Name = '$name1_updt',
                        BillDate = '$bill_date1_updt',
                        GstNumber = '$gst_number1_updt',
                        BillAmount = '$bill_amount1_updt',
                        Cgst = '$cgst1_updt',
                        CgstAmount = '$calc_cgst1_updt',
                        Sgst = '$sgst1_updt',
                        SgstAmount = '$calc_sgst1_updt',
                        OtherAmount = '$other_amount1_updt',
                        GrossAmount = '$grand_total1_updt'
                         
                        WHERE BillNumber = '$bill_number1_updt'";


        $update_result = sqlsrv_query($connect, $update_query);
        header("location: show_data.php?".$bill_type);
     
    }


?>

