<!--Mobile View-->
<br><br>
<div id="bmg-mobile-view" class="fluid-container mobile-card-new" style="border: none;width: 90%;margin-left: 5%;">
	<center>
		<div class="fluid-container bmg-mobile-tab-box-inner" style="border: none;">
			<div class="table-responsive" style="border: none;">
				<table class="table">
					<tr>
						<div class="tab">
							<td>
								<button id="bmg-button-1" class="tablinks bmg-tab-button bmg-tab-button1" style="width: 100%;" onclick="openCity(event, 'London1'); BmgRemClassBtn1();">Be Guide</button>
							</td>
							<td>
								<button id="bmg-button-2" class="tablinks bmg-tab-button bmg-tab-button1" style="width: 100%;" onclick="openCity(event, 'Paris1');BmgRemClassBtn2();">Hire Guide</button>
							</td>
						</div>
					</tr>
				</table>
			</div>
		</div>
		<div class="fluid-container" style="background-color: transparent;margin-bottom: 5px;">
			<div class="row">							
				<div class="col-md-11"></div>
			</div>
		</div>
		<div id="London1" class="tabcontent fluid-container bmg-mobile-tab-box-inner">
  			<center>
				<form action="" method="">
					<font class="bmg-tab-fontbc">
						BE A GUIDE & TRAVEL THE WORLD FOR FREE
					</font>
					<input type="text" name="UserFirstName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="First Name" style="width: 42%;">

					<input type="text" name="UserLastName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Last Name" style="width: 42%;">

					<input type="email" name="UserEmail" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Email">

					<input type="text" name="UserCity" class="bmg-input-1" required="You cannot leave this field empty." placeholder="City" style="width: 42%;">

					<input type="text" name="UserCountry" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Country" style="width: 42%;">

					<button class="bmg-tab-button bmg-tab-button1">BE GUIDE</button>
				</form>
			</center><br>&nbsp;
		</div>
		<div id="Paris1" class="tabcontent fluid-container bmg-mobile-tab-box-inner">
  			<center>
				<form>
					<font class="bmg-tab-fontbc">
						HIRE GUIDE THAT PERFECT FOR YOU TRAVEL DESTINATION
					</font>
					<input type="text" name="UserFirstName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="First Name" style="width: 42%;">

					<input type="text" name="UserLastName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Last Name" style="width: 42%;">

					<input type="text" name="UserDestinationCity" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Destination City">

					<input type="text" name="userDestinationCountry" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Destination Country">

					<button class="bmg-tab-button bmg-tab-button1">HIRE GUIDE</button>
				</form>
			</center><br>&nbsp;
		</div>
		<script type="text/javascript" src="js/other/tab.js"></script>
	</center>
</div>