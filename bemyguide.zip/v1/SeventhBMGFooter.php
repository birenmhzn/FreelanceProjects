<style type="text/css">
	.co a {
		color: white;
		text-decoration: none;
	}
</style>
<div class="container" style="background-color: #16355c;width: 100%;color: white;"> <!-- #aedbbf-->
	<div class="container" style="margin-top: 3%;">	
		<center>
			<div class="row">
				<div class="col-md-2">
				</div>
				<div class="col-md-3" style="padding: 2% 2%;">
					<p>
						<h4>
							<font style="">
								BeMyGuide
							</font>
						</h4><hr>
						<font class="co">
							<a href="">About Us</a><br>
							<a href="">Contact Us</a><br>
							<a href="">Career</a><br>
							<a href="">Promotion</a><br>
							<a href="">Privacy Policy</a><br>
							<a href="">Complaints</a><br>
							<a href="">User Agreement</a><br>
							<a href="">Franchise Program Details</a><br>
							<a href="">Testimonial</a><br>
							<a href="">Stories</a><br>

						</font>
					</p>
				</div>
				<div class="col-md-3" style="padding: 2% 2%;">
					<p>
						<h4>
							<font>
								Join BeMyGuide Family
							</font>
						</h4><hr>	
						<font class="co">
							<a href="">List Your Hotel</a><br>
							<a href="">List Your Home</a><br>
							<a href="">List Your Cab</a><br>
							<a href="">List Your Business</a><br>
						</font>					
					</p>
				</div>
				<div class="col-md-3" style="padding: 2% 2%;">
					<p>
						<h4>
							<font>
								Android BeMyGuide
							</font>
						</h4><hr>
						<font class="co">
						</font>						
					</p>
				</div>
			</div>
			<h4>
				<font style="font-weight: bold;color: white;">
					© BEMYGUIDE
				</font>
			</h4>
		</center>
	</div><br>
</div>