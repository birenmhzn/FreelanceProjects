<link rel="stylesheet" type="text/css" href="css/other/ulstyle6.css">
<div class="container" style="background-color: white;width: 100%;color: #2e3192;">
	<center>
		<h2>
			<div class="bmg-link-wrapper">
				<span class="bmg-link bmg-hover-6" style="cursor: pointer;">
					BMG VERIFIED GUIDE
				</span>
			</div>
		</h2><hr>
	</center>
	<div class="container" style="width: 100%;">
		<div class="row">
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/2.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/3.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/4.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/6.jpg">
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<img class="img-responsive" src="img/background/5.jpg">
			</div>
		</div>
	</div>
	<br><br>
</div>