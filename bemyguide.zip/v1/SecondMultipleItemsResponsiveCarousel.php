<link rel="stylesheet" type="text/css" href="css/other/MultipleItemsResponsiveCarousel.css">
<div class="container" style="width:100%;background-color: #f2f2f2;padding-top: 5%;">
	<div class="row">
		<div class="col-xs-11 col-md-10 col-centered">
			<div id="carousel" class="carousel slide" data-ride="carousel" data-type="multi" data-interval="2500">
				<div class="carousel-inner bmg-black-shadow">
					<div class="item active">
						<div class="carousel-col">
							<div class="block img-responsive" style="background-color: white;">
								<div class="row">
									<div class="col-md-10" style="font-size: 130%;color: #2e3192;padding-left: 10%;">
										<b>Events Near You</b>
										<hr>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="block img-responsive" style="background-color: white;">
								<div class="row">
									<div class="col-md-10" style="font-size: 130%;color: #2e3192;padding-left: 10%;">
										<b>Popular Destination</b>
										<hr>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="block img-responsive" style="background-color: white;">
								<div class="row">
									<div class="col-md-10" style="font-size: 130%;color: #2e3192;padding-left: 10%;">
										<b>Hotels In Budget</b>
										<hr>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="block img-responsive" style="background-color: white;">
								<div class="row">
									<div class="col-md-10" style="font-size: 130%;color: #2e3192;padding-left: 10%;">
										<b>Book On BeMyGuide</b>
										<hr>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					<!-- Controls -->
				<div class="left carousel-control">
					<a href="#carousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left bmg-black-shadow" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
				</div>
				<div class="right carousel-control">
					<a href="#carousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right bmg-black-shadow" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
				<script type="text/javascript" src="js/other/MultipleItemsResponsiveCarousel.js"></script>
			</div>
		</div>
	</div>
	<br><br><br><br>
</div>  