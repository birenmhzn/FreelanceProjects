<div class="container" style="background-color: white;width: 100%;color: #2e3192;">
	<br>
	<center>
		<h2>
			<div class="bmg-link-wrapper">
				<span class="bmg-link bmg-hover-6" style="cursor: pointer;">
					CONTACT BE MY GUIDE
				</span>
			</div>
		</h2><hr>
		<div class="container">
			<center>
				<form action="" method="">
					<input type="text" name="ContactUserName" class="bmg-input-2" required="You cannot leave this field empty." placeholder="Full Name" style="width: 30%;margin-right: 5%;">

					<input type="email" name="ContactUserEmail" class="bmg-input-2" required="You cannot leave this field empty." placeholder="Email" style="width: 30%;">
					
					<br>
					
					<textarea rows="4" name="ContactUserMessage" class="bmg-input-2" placeholder="Message" style="width: 65%;" required></textarea>

					<button class="bmg-button-1 bmg-button-2" style="width: 50%;">Submit</button>
				</form>
			</center>
		</div>
	</center>	
	<br><br>
</div>