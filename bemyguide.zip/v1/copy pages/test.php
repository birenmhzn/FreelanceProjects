<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.bg-img {
  /* The image used */
  background-image: url("img/other/8.png");
  height: 650px;
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
	</style>
</head>
<body>
	  	<?php include "bootstraplinks.php"; ?>
	<div class="bg-img fluid-container img-responsive">
		<div class="container" style="border: 1px solid black;width: 50%;float: left;">
			<div class="row">
				<div class="col-md-4" style="border: 1px solid black">
					<h2>hin</h2>
				</div>
				<div class="col-md-4" style="border: 1px solid black">
					<div class="form-group">
            <input type="text" class="form-control" placeholder="Username" required="required">
        </div>
				</div>

			</div>
		</div>
	</div>
</body>
</html>