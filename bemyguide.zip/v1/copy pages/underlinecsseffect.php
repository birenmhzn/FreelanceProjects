
<link rel="stylesheet" type="text/css" href="ulstyleoriginal.css">
<h1>Links hover animations</h1>
<div class="link-cont">
    <div class="link-wrapper">
        <a class="link hover-1" href="#">#1 - left to right</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-2" href="#">#2 center to tips</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-3" href="#">#3 left to right</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-4" href="#">#4 right to left</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-5" href="#">#5 scaling height</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-6" href="#">#6 edges to center</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-7" href="#">#7 top & bottom, left to right + reverse</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-8" href="#">#8 top & bottom, left to right</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-9" href="#">#9 top & bottom, right to left</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-10" href="#">#10 top & bottom tips to center</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-11" href="#">#11 top & bottom, scaling height</a>
    </div>
    <div class="link-wrapper">
        <a class="link hover-12" href="#">#12 top & bottom, left to right + reverse</a>
    </div>
    <div class="link-wrapper">
        <span class="inner-wrapper wrapper-13">
            <a class="link hover-13" href="#">#13 top & bottom, tips to center</a>
        </span>
    </div>
    <div class="link-wrapper">
        <span class="inner-wrapper wrapper-14">
            <a class="link hover-14" href="#">#14 square effect, center to edges</a>
        </span>
    </div>
    <div class="link-wrapper">
        <span class="inner-wrapper wrapper-15">
            <a class="link hover-15" href="#">#15 square effect, symetrical</a>
        </span>
    </div>
    <div class="link-wrapper">
        <span class="inner-wrapper wrapper-16">
            <a class="link hover-16" href="#">#16 square effect, simultaneous</a>
        </span>
    </div>
    <div class="link-wrapper">
        <span class="inner-wrapper wrapper-17">
            <a class="link hover-17" href="#">#17 square effect, side by side</a>
        </span>
    </div>
</div>
