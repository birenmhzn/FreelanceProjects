
			  				<div class="tab">
				  				<table class="table">
				  					<tr>
				  						<td class="bmg-border-black bmg-width-40">
											<button class="tablinks" onclick="openCity(event, 'London')">London</button>		
										</td>
				  						<td class="bmg-border-black bmg-width-40">
											<button class="tablinks" onclick="openCity(event, 'Paris')">Paris</button>		
										</td>
				  					</tr>
				  				</table>
				  			</div>
				  			<div id="London" class="tabcontent">
							    <h3>London</h3>
							    <p>London is the capital city of England.</p>
							</div>

							<div id="Paris" class="tabcontent">
							    <h3>Paris</h3>
							    <p>Paris is the capital of France.</p> 
							</div>
							<script type="text/javascript" src="js/other/tab.js"></script>