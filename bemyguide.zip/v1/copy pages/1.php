
  	  <div class="row margin-top-5">
  	  	<div class="col-md-1 margin-top-5">
  	  		<div class="container">
  	  		</div>
  	  	</div>
  	  	<div class="col-md-2 bmgborder">
  	  		<div class="container bmgborder margin-top-5">
  	  			<button type="button" class="btn btn-info">Guide</button>
  	  		</div>
  	  	</div>
  	  	<div class="col-md-2 bmgborder">
  	  		<div class="container bmgborder">
  	  			<button type="button" class="btn btn-primary">Hotel</button>
  	  		</div>
  	  	</div>
  	  	<div class="col-md-2 bmgborder">
  	  		<div class="container bmgborder">
  	  			<button type="button" class="btn btn-success">Bus</button>
  	  		</div>
  	  	</div>
  	  	<div class="col-md-2 bmgborder">
  	  		<div class="container bmgborder">
  	  			<button type="button" class="btn btn-danger">Car</button>
  	  		</div>
  	  	</div>
  	  	<div class="col-md-2 bmgborder">
  	  		<div class="container bmgborder">
  	  			<button type="button" class="btn btn-warning bmgwidth-70">Homestay</button>
  	  		</div>
  	  	</div>
  	  </div>