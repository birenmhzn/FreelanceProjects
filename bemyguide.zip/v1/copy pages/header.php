<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/other/header.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <?php include "Cdnbootstrap.php"; ?>
        <nav id="navbar" class="container"> 
            <div class="nav-wrapper">
                <!-- Navbar Logo -->
                <div id="logo" class="logo">
                    <!-- Logo Placeholder for Inlustration -->
                    <a href="index.php" class="bmg-text-logo"><i class="fa fa-chess-knight"></i>BeMyGuide</a>
                </div>

                <!-- Navbar Links -->
                <ul id="menu" class="main_menu bmg-navbar-text" style="float: left;">
                    <li><a href="index.php"><b>Trains</b></a></li>
                    <li><a href="index.php"><b>Homestay</b></a></li>
                    <li><a href="contact.php"><b>Holiday</b></a></li>
                    <li><a href="contact.php"><b>Promotions</b></a></li>
                    <li><a href="contact.php"><b>Travel Shopping</b></a></li>
                    <li><a href="contact.php"><b>Top Guides</b></a></li>
                    <li><a href="contact.php"><b>
                        <img src="img/icon/login.png" height="30" width="30" alt="Profile">
                    </b></a></li>
                    <li><a href="contact.php"><b>
                                <img src="img/icon/signup.png" height="30" width="30">
                    </b></a></li>
                </ul>
            </div>
        </nav>

        <!-- Menu Icon -->
        <div class="menuIcon">
            <span class="icon icon-bars"></span>
            <span class="icon icon-bars overlay"></span>
        </div>

        <div class="overlay-menu">
            <ul id="menu">
                <li><a href="index.php"><b>abc</b></a></li>
                <li><a href="contact.php"><b>abc</b></a></li>
            </ul>
        </div>
        

        <!--<div class="side-icon-bar">
          <a href="#" class="facebook"><i class="fa fa-facebook"></i></a> 
          <a href="#" class="twitter"><i class="fa fa-twitter"></i></a> 
          <a href="#" class="google"><i class="fa fa-google"></i></a> 
          <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
          <a href="#" class="youtube"><i class="fa fa-youtube"></i></a> 
        </div>-->
        <script type="text/javascript" src="js/other/header.js"></script>
    </body>
</html>