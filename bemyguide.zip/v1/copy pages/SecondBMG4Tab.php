<div class="container bmg-width-50 table-responsive">
				<link rel="stylesheet" type="text/css" href="css/other/style.css">
		  	  	<table class="table">
		  	  		<tbody class="">
		  	  	  		<tr>
		  	  	    		<td class="bmg-width-20 bmg-border-bottom-3-grey bmg-btn-active">
		  	  	    			<center>
		  	  	    				<button type="button" class="btn btn-primary bmg-width-100">Guide</button>
		  	  	    			</center>
		  	  				</td>
		  	  	    		<td class="bmg-width-20">
		  	  	    			<center>
		  	  	    				<button type="button" class="btn btn-primary bmg-width-100">Hotel</button>
		  	  	    			</center>
		  	  				</td>
		  	  	    		<td class="bmg-width-20">
		  	  	    			<center>
		  	  	    				<button type="button" class="btn btn-primary bmg-width-100">Bus</button>
		  	  	    			</center>
		  	  				</td>
		  	  	    		<td class="bmg-width-20">
		  	  	    			<center>
		  	  	    				<button type="button" class="btn btn-primary bmg-width-100">Car</button>
		  	  	    			</center>
		  	  				</td>
		  	  	    		<td class="bmg-width-20">
		  	  	    			<center>
		  	  	    				<button type="button" class="btn btn-primary bmg-width-100">Homestay</button>
		  	  	    			</center>
		  	  				</td>
		  	  			</tr>
		  	  		</tbody>
		  	  	</table>
		  	</div>
			<div class="fluid-container bmg-border-light-grey bmg">
		  		hi
		  	</div>	  	