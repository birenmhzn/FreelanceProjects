<!DOCTYPE html>
<html>
	<head>
		<title>Homepage | BeMyGuide</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/other/style.css">
		<script type="text/javascript" src="js/other/script.js"></script>
	</head>
	<body>
	  	<?php include "Header.php"; ?>
	  	<?php include "Cdnbootstrap.php"; ?>
	  	<br><br>

		<div class="fluid-container">
			<?php include "FirstBMGBigContainerDesktopView.php" ?>		
		</div>

		<div class="fluid-container">
			<?php include "FirstBMGBigContainerMobileView.php" ?>		
		</div>

		<br><br>

	  	<div class="fluid-container">	
			<?php include "SecondMultipleItemsResponsiveCarousel.php"; ?>		
	  	</div>

	  	<div class="fluid-container">
	  		<?php include "ThirdBMGVerifiedGuides.php"; ?>
	  	</div>

	  	<div class="fluid-container">
	  		<?php include "FourthBMGSocialMediaLink.php"; ?>
	  	</div>

	  	<div class="fluid-container">
	  		<?php include "FifthBMGGallery.php"; ?>
	  	</div>

	  	<div class="fluid-container">
	  		<?php include "SixthBMGContactPage.php"; ?>
	  	</div>

	  	<div class="fluid-container">
	  		<?php include "SeventhBMGFooter.php"; ?>
	  	</div>
	</body>
</html>