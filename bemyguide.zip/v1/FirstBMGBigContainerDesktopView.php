	
		<!--Desktop View-->
<div id="bmg-desktop-view" class="fluid-container bmg-tab-box-outer card-new">
	<center>
		<div class="fluid-container bmg-tab-box-inner">
			<div class="row">
				<div class="col-md-1"></div>
				<div class="tab">							
					<div class="col-md-5">
						<button id="bmg-button-1" class="tablinks bmg-tab-button bmg-tab-button1" style="width: 100%;" onclick="openCity(event, 'London2'); BmgRemClassBtn1();">Be Guide</button>
					</div>
					<div class="col-md-5">
						<button id="bmg-button-2" class="tablinks bmg-tab-button bmg-tab-button1" style="width: 100%;" onclick="openCity(event, 'Paris2');BmgRemClassBtn2();">Hire Guide</button>
					</div>
				</div>
			</div>
		</div>
		<div class="fluid-container" style="background-color: transparent;margin-bottom: 5px;">
			<div class="row">							
				<div class="col-md-11"></div>
			</div>
		</div>
		<div id="London2" class="tabcontent fluid-container bmg-tab-box-inner">
  			<center>
				<form action="" method="">
					<font class="bmg-tab-fontbc">
						BE A GUIDE & TRAVEL THE WORLD FOR FREE
					</font>
					<input type="text" name="UserFirstName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="First Name" style="width: 42%;">

					<input type="text" name="UserLastName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Last Name" style="width: 42%;">

					<input type="email" name="UserEmail" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Email">

					<input type="text" name="UserCity" class="bmg-input-1" required="You cannot leave this field empty." placeholder="City" style="width: 42%;">

					<input type="text" name="UserCountry" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Country" style="width: 42%;">

					<button class="bmg-tab-button bmg-tab-button1">BE GUIDE</button>
				</form>
			</center><br>&nbsp;
		</div>
		<div id="Paris2" class="tabcontent fluid-container bmg-tab-box-inner">
  			<center>
				<form>
					<font class="bmg-tab-fontbc">
						HIRE GUIDE THAT PERFECT FOR YOU TRAVEL DESTINATION
					</font>
					<input type="text" name="UserFirstName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="First Name" style="width: 42%;">

					<input type="text" name="UserLastName" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Last Name" style="width: 42%;">

					<input type="text" name="UserDestinationCity" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Destination City">

					<input type="text" name="userDestinationCountry" class="bmg-input-1" required="You cannot leave this field empty." placeholder="Destination Country">

					<button class="bmg-tab-button bmg-tab-button1">HIRE GUIDE</button>
				</form>
			</center><br>&nbsp;
		</div>
		<script type="text/javascript" src="js/other/tab.js"></script>
	</center>
</div>