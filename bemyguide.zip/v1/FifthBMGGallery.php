<div class="container" style="background-color: white;width: 100%;color: #2e3192;">
	<br>
	<center>
		<h2>
			<div class="bmg-link-wrapper">
				<span class="bmg-link bmg-hover-6" style="cursor: pointer;">
					GALLERY
				</span>
			</div>
		</h2><hr>
	</center>
	<div class="container">
		<div class="row">
			<div class="col-md-7">
				<div class="row">
					<div class="col-md-12">
						<img class="img-responsive" src="img/background/7.jpg">
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<img class="img-responsive" src="img/background/1.jpg">
					</div>
				</div>
			</div>
			<div class="col-md-5">
				<div class="row">
					<div class="col-md-12">
						<img class="img-responsive" src="img/background/3.jpg">
					</div>					
				</div>
				<div class="row">
					<div class="col-md-12">
						<img class="img-responsive" src="img/background/4.jpg">
					</div>					
				</div>
				<div class="row">
					<div class="col-md-12">
						<img class="img-responsive" src="img/background/10.jpg">
					</div>					
				</div>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<img class="img-responsive" src="img/background/2.jpg">
			</div>
			<div class="col-md-6">
				<img class="img-responsive" src="img/background/6.jpg">
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/2.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/3.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/4.jpg">
			</div>
			<div class="col-md-3">
				<img class="img-responsive" src="img/background/6.jpg">
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<img class="img-responsive" src="img/background/5.jpg">
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<center>
					<button class="bmg-button-1 bmg-button-2" style="width: 40%;">Upload Yours</button>
				</center>
			</div>
			<div class="col-md-6">
				<center>
					<button class="bmg-button-1 bmg-button-2" style="width: 40%;">View More</button>
				</center>
			</div>
		</div>
	</div>
	<br><br>
</div>