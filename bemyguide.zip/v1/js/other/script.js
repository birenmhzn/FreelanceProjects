function BmgHideOneTab(){
	document.getElementById("Paris").style.display = "none";
}
function BmgRemClassBtn1(){
	document.getElementById("bmg-button-1").style.borderBottom = "3px solid blue";
	document.getElementById("bmg-button-1").style.color = "#ffed00";
	document.getElementById("bmg-button-2").style.color = "white";
	document.getElementById("bmg-button-2").style.borderBottom = "none";
}
function BmgRemClassBtn2(){
	document.getElementById("bmg-button-1").style.borderBottom = "none";
	document.getElementById("bmg-button-1").style.color = "white";
	document.getElementById("bmg-button-2").style.color = "#ffed00";
	document.getElementById("bmg-button-2").style.borderBottom = "3px solid blue";
}