<!DOCTYPE html>
<html>
	<head>
		<title>About Us | BeMyGuide</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/other/style.css">
	</head>
	<body>
	  	<?php include "Header.php"; ?>
	  	<?php include "Cdnbootstrap.php"; ?>
	  	<br><br>

	</body>
</html>