<!DOCTYPE html>
<html>
	<head>
		<title></title>
	        <link rel="stylesheet" type="text/css" href="css/other/header2.css">
	        <link rel="stylesheet" type="text/css" href="css/other/ulstyle1.css">
	        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #f8f9fad1;color: black;border: none;">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color: #2e3192;border: none;cursor: pointer;">
						<span class="icon-bar" style="cursor: pointer;"></span>
						<span class="icon-bar" style="cursor: pointer;"></span>
						<span class="icon-bar" style="cursor: pointer;"></span>
					</button>					
					<a class="navbar-brand" href="index.php" style="letter-spacing: 1px;text-transform: uppercase;color: #2e3192;font-weight: bold;text-decoration: none;">
						BEMYGUIDE
					</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul id="nav" class="nav navbar-nav navbar-left" style="width:85%;margin-left: 2%;word-spacing: 5px;">
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;word-spacing: 5px;cursor: pointer;">
								Top Guides
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;margin-right: 10%;">
								Homestay
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;margin-right: 10%;">
								Holiday
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;margin-right: 10%;">
								Rentals
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;margin-right: 10%;">
								Travel Accessories
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: black;font-size: 120%;margin-right: 10%;">
								Trains
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="login.php" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: #2e3192;font-weight: bold;font-size: 120%;margin-right: 10%;">
								<img src="img/icon/login.png" height="30" width="30" alt="Profile">
							</a>
						</li>
						<li class="bmg-link-wrapper-ulstyle-1">
							<a href="#" class="bmg-link-ulstyle-1 bmg-hover-1-ulstyle-1" style="width:100%;color: #2e3192;font-weight: bold;font-size: 120%;margin-right: 10%;">
								<img src="img/icon/signup.png" height="30" width="30" alt="Profile">
							</a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
	</body>
</html>