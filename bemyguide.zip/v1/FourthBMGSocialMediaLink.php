<div class="container" style="background-color: #f7b594;width: 100%;">
	<div class="container" style="margin-top: 8%;">		
		<font style="font-size: 150%;font-weight: bold;color: black;font-family: Palatino Linotype;letter-spacing: 0.80em;line-height: 2em">
			SHARE YOUR EXPERIENCE ON <br>
			<a style="color: white;font-family: Palatino Linotype;text-decoration: none;cursor: pointer;">INSTAGRAM</a>, 
			<a style="color: white;font-family: Palatino Linotype;text-decoration: none;cursor: pointer;">FACEBOOK</a> 
			& 
			<a style="color: white;font-family: Palatino Linotype;text-decoration: none;cursor: pointer;">TWITTER</a>
			BY USING THE FOLLOWING HASHTAG<br><br>
			<center>
				<a style="color: white;font-family: Palatino Linotype;text-decoration: none;cursor: pointer;letter-spacing: 0.30em;">
					#BEMYGUIDEIN
				</a>
			</center>
		</font>
	</div><br><br><br><br>
</div>