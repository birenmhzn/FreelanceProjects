<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
<?php
    include('sqlserverfiles/Config.php');
    session_start();
    $url=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	//echo $url;
	$myArray = explode('lid=', $url);
	$id = $myArray[1];
    $decrypt_email = base64_decode($id);
    if(isset($_POST['update_password_btn']))
    {
    	
        $update_password = $_POST["update_password"];
        if (CRYPT_BLOWFISH == 1)
        {
            $passwordhash = crypt($update_password ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
        }
        else
        {   
            echo '<script>alert("Blowfish DES not supported.");
            window.location="login.php";</script>';
        }
                    
        $sql="UPDATE `tgroups_user` SET `applicant_password` = '$passwordhash',`decoded` = '$update_password' WHERE `tgroups_user`.`login_id` = '$decrypt_email'";//`
        $runquery = mysqli_query($con,$sql);
        if($runquery)
    	{
            echo '<script>alert("Your password successfully updated....");
    			window.location="login.php";</script>';
    	}	
    	else
    	{ 
    		echo "Error to update your password..."; 
    	}
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Update Password</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Update Password</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="signupform">
			<div class="container">
				<!-- main content -->
				<div class="main-content">
					<div class="contect_left_form">
						<div class="left_grid_info">
							<h1>Manage Your Business Account</h1>
							<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
							<img src="images/image.jpg" alt="" />
						</div>
					</div>
					<div class="login_info">
						<h2>Update your password now</h2>
						<p>Enter your new password.</p>
						<form action="#" method="post">
							<label>Enter New Password</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="password" placeholder="Enter New Password" name="update_password" required> 
							</div> 						
							<input class="btn btn-danger btn-block" type="submit" value="Update Password" name="update_password_btn" /> 
              			</form>
						<p class="account1"><a href="login.php">Login</a></p>
					</div>
				</div>
				<!-- //main content -->
			</div>
		</div>
		
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>