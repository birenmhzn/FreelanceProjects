<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Direct Joins</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Direct Joins</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<?php
			$sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id' ORDER BY `id` DESC LIMIT 1";//`
		    $runquery = mysqli_query($con,$sql);
		    $row=mysqli_fetch_assoc($runquery);
		    $user_id = $row['user_id'];
		?>
		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Your direct joins</h3></b></center><br>

				
				<div class="container">
				  	<h2>User ID: <?php echo $user_id; ?></h2>     
					<?php
								$sql1="SELECT `user_id`, `applicant_name`, `applicant_mobile_number` FROM `tgroups_user` WHERE `sponsor_id` = '$user_id' AND `active` = '1' AND `deactivate` = '0'";//`
							    $runquery1 = mysqli_query($con,$sql1);
					    		if($runquery1)
                            	{    
                            		$collapse_count = 1;
                                	while($row1=mysqli_fetch_ASsoc($runquery1)) 
                                	{

	                                    $user_id1 = $row1['user_id'];
	                                    $applicant_name1 = $row1['applicant_name'];
	                                    $applicant_mobile_number1 = $row1['applicant_mobile_number'];
					    	?>
								      	
									  	<div class="panel-group">
										  	<div class="panel panel-default">
										    	<div class="panel-heading">
										      		<h4 class="panel-title">
										        	<a data-toggle="collapse" href="#collapse<?php echo $collapse_count; ?>" style="color:#705ecf;">&darr;&nbsp;<?php echo $user_id1 ?></a>
										        	<a><b>Name :</b><?php echo $applicant_name1 ?></a>
										        	<a><b>Mobile Number :</b><?php echo $applicant_mobile_number1 ?>
										        	</a>
										      	</h4>
										    </div>
										    	<div id="collapse<?php echo $collapse_count; ?>" class="panel-collapse collapse">
											        <ul class="list-group">
											        	<?php
											        		$sql2="SELECT `user_id`, `applicant_name`, `applicant_mobile_number` FROM `tgroups_user` WHERE `sponsor_id` = '$user_id1' AND `active` = '1' AND `deactivate` = '0'";//`
														    $runquery2 = mysqli_query($con,$sql2);
												    		if($runquery2)
							                            	{    
							                            		$collapse_count = 1;
							                                	while($row2=mysqli_fetch_ASsoc($runquery2)) 
							                                	{

								                                    $user_id2 = $row2['user_id'];
								                                    $applicant_name2 = $row2['applicant_name'];
								                                    $applicant_mobile_number2 = $row2['applicant_mobile_number'];
											        	?>
														          	<li class="list-group-item">
														          		<b>User ID :</b><?php echo $user_id2; ?>&nbsp;&nbsp;
														          		<b>Name : </b><?php echo $user_id2; ?>&nbsp;&nbsp;
														          		<b>Mobile Number : </b><?php echo $applicant_mobile_number2; ?>&nbsp;&nbsp;
														          	</li>
														<?php } } ?>
											        </ul>
										    	</div>
										  	</div>
										</div> 
							<?php $collapse_count = $collapse_count + 1; }  } ?>
				</div>
			</div>
		</div>


		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>