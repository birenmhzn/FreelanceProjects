
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Startup a Corporate Category Bootstrap Responsive Website Template | Faq's </title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
</head>

<body>
	<!-- main banner -->
	<div class="main-top" id="home">
		
		<!-- header -->
		<header>
			<?php include "header.php"; ?>
		</header>
		<!-- //header -->

		<!-- banner -->
		<div class="banner_temps-amklspvt-2">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
				<li class="breadcrumb-item" aria-current="page">Faq's</li>
			</ol>
		</div>
		<!-- //banner -->
	</div>
	<!-- //main banner -->

	<!-- faq -->
	<div class="about-inner py-5">
		<div class="container pb-xl-5 pb-lg-3">
			<div class="row py-xl-4">
				<div class="col-lg-6 welcome-right text-center mb-lg-0 mb-5">
					<img src="images/faq.png" alt="" class="img-fluid" />
				</div>
				<div class="col-lg-6 about-right-faq">
					<h3 class="mt-2 mb-3">Frequently asked questions</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse porta erat sit.</p>
					<p class="mt-3">Suspendisse porta erat sit amet eros sagittis, quis hendrerit libero aliquam. Fusce semper augue
						ac dolor
						efficitur.</p>
					<a href="about.html" class="btn button-style mt-sm-5 mt-4">Read More</a>
				</div>
			</div>
			<!-- accordions -->
			<ul class="accordion css-accordion mt-5">
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item1" />
					<label for="item1" class="accordion-item-hd">At vero eos et accusamus et iusto odio dignissimos ducimus <span
						 class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">AmetLorem ipsum dolor sit amet</h6>
						<p>Sodales quis.At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item2" />
					<label for="item2" class="accordion-item-hd">Lorem ipsum dolor sit amet <span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">Dolores et ea rebum lorem ipsum</h6>
						<p>Duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item3" />
					<label for="item3" class="accordion-item-hd">Tque corrupti quos dolores et quas molestias excepturi sint occaecati
						<span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">At vero eos et accusam et</h6>
						<p>sodales quis. At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
				<li class="accordion-item">
					<input class="accordion-item-input" type="checkbox" name="accordion" id="item4" />
					<label for="item4" class="accordion-item-hd">Dolores et quas molestias excepturi sint occaecati <span class="accordion-item-hd-cta">&#9650;</span></label>
					<div class="accordion-item-bd">
						<h6 class="accordion-textm">Lorem ipsum dolor sit amet</h6>
						<p>Sodales quis at vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit ametLorem ipsum
							dolor sit amet,sed diam nonumy. Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
							dolore magna aliqua.</p>
					</div>
				</li>
			</ul>
			<!-- //accordions -->
		</div>
	</div>
	<!-- //faq -->

	<!-- footer -->
	<footer class="bg-li py-5">
		<div class="container py-xl-5 py-lg-3">
			<!-- subscribe -->
			<div class="subscribe mx-auto">
				<div class="icon-effect-temps-amk">
					<span class="fa fa-envelope"></span>
				</div>
				<h2 class="tittle text-center font-weight-bold">Stay Updated!</h2>
				<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">Sed do eiusmod tempor incididunt ut labore et dolore magna
					aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
				<form action="#" method="post" class="subscribe-amk-tems pt-2">
					<div class="d-flex subscribe-amk-tems-field">
						<input class="form-control" type="email" placeholder="Enter your email..." name="email" required="">
						<button class="btn form-control w-50" type="submit">Subscribe</button>
					</div>
				</form>
			</div>
			<!-- //subscribe -->
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright bottom -->
	<div class="copy-bottom bg-li py-4 border-top">
		<div class="container-fluid">
			<div class="d-md-flex px-md-3 position-relative text-center">
				<!-- footer social icons -->
				<div class="social-icons-footer mb-md-0 mb-3">
					<ul class="list-unstyled">
						<li>
							<a href="#">
								<span class="fa fa-facebook"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-instagram"></span>
							</a>
						</li>
					</ul>
				</div>
				<!-- //footer social icons -->
				<!-- copyright -->
				<div class="copy_right mx-md-auto mb-md-0 mb-3">
					<p class="text-bl let">© 2019 Startup. All rights reserved.
					</p>
				</div>
				<!-- //copyright -->
				<!-- move top icon -->
				<a href="#home" class="move-top text-center">
					<span class="fa fa-level-up" aria-hidden="true"></span>
				</a>
				<!-- //move top icon -->
			</div>
		</div>
	</div>
	<!-- //copyright bottom -->

</body>

</html>