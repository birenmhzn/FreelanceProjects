
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Startup a Corporate Category Bootstrap Responsive Website Template | 404 </title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
</head>

<body>
	<!-- main banner -->
	<div class="main-top" id="home">
		
		<!-- header -->
		<header>
			<?php include "header.php"; ?>
		</header>
		<!-- //header -->

		<!-- banner -->
		<div class="banner_temps-amklspvt-2">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
				<li class="breadcrumb-item" aria-current="page">404 Error Page</li>
			</ol>
		</div>
		<!-- //banner -->
	</div>
	<!-- //main banner -->

	<!-- 404 -->
	<div class="error pb-5 pt-2 text-center" id="price">
		<div class="container pb-xl-5 pb-lg-3">
			<img src="images/error.png" alt="" class="img-fluid" />
			<h3 class="title-temps-amk text-bl my-3 font-weight-bold text-capitalize">Oops! This page can’t be found.</h3>
			<p class="sub-tittle text-center4">Sed do eiusmod tempor incididunt ut labore et dolore magna
				aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
			<a href="index.html" class="btn button-style mt-5">Back To Home</a>
		</div>
	</div>
	<!-- //404 -->

	<!-- footer -->
	<footer class="bg-li py-5">
		<div class="container py-xl-5 py-lg-3">
			<!-- subscribe -->
			<div class="subscribe mx-auto">
				<div class="icon-effect-temps-amk">
					<span class="fa fa-envelope"></span>
				</div>
				<h2 class="tittle text-center font-weight-bold">Stay Updated!</h2>
				<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">Sed do eiusmod tempor incididunt ut labore et dolore magna
					aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
				<form action="#" method="post" class="subscribe-amk-tems pt-2">
					<div class="d-flex subscribe-amk-tems-field">
						<input class="form-control" type="email" placeholder="Enter your email..." name="email" required="">
						<button class="btn form-control w-50" type="submit">Subscribe</button>
					</div>
				</form>
			</div>
			<!-- //subscribe -->
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright bottom -->
	<div class="copy-bottom bg-li py-4 border-top">
		<div class="container-fluid">
			<div class="d-md-flex px-md-3 position-relative text-center">
				<!-- footer social icons -->
				<div class="social-icons-footer mb-md-0 mb-3">
					<ul class="list-unstyled">
						<li>
							<a href="#">
								<span class="fa fa-facebook"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-instagram"></span>
							</a>
						</li>
					</ul>
				</div>
				<!-- //footer social icons -->
				<!-- copyright -->
				<div class="copy_right mx-md-auto mb-md-0 mb-3">
					<p class="text-bl let">© 2019 Startup. All rights reserved.
					</p>
				</div>
				<!-- //copyright -->
				<!-- move top icon -->
				<a href="#home" class="move-top text-center">
					<span class="fa fa-level-up" aria-hidden="true"></span>
				</a>
				<!-- //move top icon -->
			</div>
		</div>
	</div>
	<!-- //copyright bottom -->

</body>

</html>