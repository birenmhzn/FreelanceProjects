
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Plan</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
</head>

<body>
	<!-- main banner -->
	<div class="main-top" id="home">
		
		<!-- header -->
		<header>
			<?php include "header.php"; ?>
		</header>
		<!-- //header -->

		<!-- banner -->
		<div class="banner_temps-amklspvt-2">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
				<li class="breadcrumb-item" aria-current="page">Pricing</li>
			</ol>
		</div>
		<!-- //banner -->
	</div>
	<!-- //main banner -->

	<!-- price -->
	<div class="price-sec py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="inner_sec_info_temps-amk_info mt-3">
				<div class="row price-grid-main">
					<div class="col-lg-3 col-sm-6 price-info">
						<div class="prices p-4">
							<div class="prices-top">
								<h3 class="text-center text-wh rounded-circle">$30</h3>
							</div>
							<div class="prices-bottom text-center">
								<div class="prices-h border-bottom p-4">
									<h4>Standard</h4>
								</div>
								<ul class="mt-4">
									<li>Community Access</li>
									<li>Annual Reports</li>
									<li>Free Support</li>
									<li>Expert Reviews</li>
								</ul>
								<a href="#" class="btn button-style mt-4">Purchase</a>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6  price-info price-mkres-2">
						<div class="prices p-4 active">
							<div class="prices-top">
								<h3 class="text-center text-wh rounded-circle">$80</h3>
							</div>
							<div class="prices-bottom text-center">
								<div class="prices-h border-bottom p-4">
									<h4>Premium</h4>
								</div>
								<ul class="mt-4">
									<li>Limitless Concepts</li>
									<li>Annual Reports</li>
									<li>Free Support</li>
									<li>Expert Reviews</li>
								</ul>
								<a href="#" class="btn button-style mt-4">Purchase</a>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6  price-info price-mkres">
						<div class="prices p-4">
							<div class="prices-top">
								<h3 class="text-center text-wh rounded-circle">$60</h3>
							</div>
							<div class="prices-bottom text-center">
								<div class="prices-h border-bottom p-4">
									<h4>Golden</h4>
								</div>
								<ul class="mt-4">
									<li>Community Access</li>
									<li>Annual Reports</li>
									<li>Free Support</li>
									<li>Expert Reviews</li>
								</ul>
								<a href="#" class="btn button-style mt-4">Purchase</a>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6  price-info price-mkres">
						<div class="prices p-4 active">
							<div class="prices-top">
								<h3 class="text-center text-wh rounded-circle">$30</h3>
							</div>
							<div class="prices-bottom text-center">
								<div class="prices-h border-bottom p-4">
									<h4>Ultimate</h4>
								</div>
								<ul class="mt-4">
									<li>Limitless Concepts</li>
									<li>Annual Reports</li>
									<li>Free Support</li>
									<li>Expert Reviews</li>
								</ul>
								<a href="#" class="btn button-style mt-4">Purchase</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //price -->

	<!-- footer -->
	<footer class="bg-li py-5">
		<div class="container py-xl-5 py-lg-3">
			<!-- subscribe -->
			<div class="subscribe mx-auto">
				<div class="icon-effect-temps-amk">
					<span class="fa fa-envelope"></span>
				</div>
				<h2 class="tittle text-center font-weight-bold">Stay Updated!</h2>
				<p class="sub-tittle text-center mt-3 mb-sm-5 mb-4">Sed do eiusmod tempor incididunt ut labore et dolore magna
					aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
				<form action="#" method="post" class="subscribe-amk-tems pt-2">
					<div class="d-flex subscribe-amk-tems-field">
						<input class="form-control" type="email" placeholder="Enter your email..." name="email" required="">
						<button class="btn form-control w-50" type="submit">Subscribe</button>
					</div>
				</form>
			</div>
			<!-- //subscribe -->
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright bottom -->
	<div class="copy-bottom bg-li py-4 border-top">
		<div class="container-fluid">
			<div class="d-md-flex px-md-3 position-relative text-center">
				<!-- footer social icons -->
				<div class="social-icons-footer mb-md-0 mb-3">
					<ul class="list-unstyled">
						<li>
							<a href="#">
								<span class="fa fa-facebook"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-twitter"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-google-plus"></span>
							</a>
						</li>
						<li>
							<a href="#">
								<span class="fa fa-instagram"></span>
							</a>
						</li>
					</ul>
				</div>
				<!-- //footer social icons -->
				<!-- copyright -->
				<div class="copy_right mx-md-auto mb-md-0 mb-3">
					<p class="text-bl let">© 2019 Startup. All rights reserved.
					</p>
				</div>
				<!-- //copyright -->
				<!-- move top icon -->
				<a href="#home" class="move-top text-center">
					<span class="fa fa-level-up" aria-hidden="true"></span>
				</a>
				<!-- //move top icon -->
			</div>
		</div>
	</div>
	<!-- //copyright bottom -->

</body>

</html>