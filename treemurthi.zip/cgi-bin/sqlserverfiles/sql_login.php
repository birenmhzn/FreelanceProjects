<?php
    include('Config.php');
    if(isset($_POST['login']))
    {  
        if(count($_POST)>0) 
        {
            $loginid = $_POST["login_id"];
            $applicantpassword = $_POST["applicant_password"];
            $passwordhash = null;

            if (CRYPT_BLOWFISH == 1)
            {
                $passwordhash = crypt($applicantpassword ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
            }
            else
            {   
                echo '<script>alert("Blowfish DES not supported.");
                window.location="../login.php";</script>';
            }

            $sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$loginid' AND `applicant_password` = '$passwordhash'";//`
            $runquery = mysqli_query($con,$sql);
            $row=mysqli_fetch_assoc($runquery);

                if($row)
                {                                       
                    $_SESSION["loginid"] = $row[login_id];
                    $_SESSION["applicantname"] = $row[applicant_name];
                    $_SESSION['loggedin_time'] = time();                     
                    echo '<script>alert("Welcome.");
                        window.location="../profile.php";</script>';
                }
                else
                {
                    echo '<script>alert("Enter wrong credentials.");
                    window.location="../login.php";</script>';
                }
        }
    }
?>