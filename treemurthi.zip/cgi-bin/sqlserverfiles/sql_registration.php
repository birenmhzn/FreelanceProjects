<?php
    include "Config.php";

    if(isset($_POST['register']))
    {    

        $sponsor_name = $_POST['sponsor_name'];
        $sponsor_id = $_POST['sponsor_id'];
        $applicant_name = $_POST['applicant_name'];
        $applicant_mobile_number = $_POST['applicant_mobile_number'];
        $applicant_email_id = $_POST['applicant_email_id'];
        $applicant_password = $_POST['applicant_password'];
        $bank_name = $_POST['bank_name'];
        $branch_name = $_POST['branch_name'];
        $account_number = $_POST['account_number'];
        $ifsc_code = $_POST['ifsc_code'];
        $paytm_number = $_POST['paytm_number'];
        $phonepe_number = $_POST['phonepe_number'];
        $google_pay_number = $_POST['google_pay_number'];
        $pancard_number = $_POST['pancard_number'];
        $adhar_number = $_POST['adhar_number'];
        
        $passwordhash = null;



        /*--------------------------------------------------------------------------------------------------------
                                    Generate login id and fixed id
        ---------------------------------------------------------------------------------------------------------*/
        $n2= mt_rand(100, 999);;
        $characters = '0123456789'; 
        $randomString = ''; 
        $randomString1 = ''; 

        for ($i = 0; $i < 3; $i++) 
        { 
            $index = rand(0, strlen($characters) - 1); 
            $randomString .= $characters[$index]; 
        } 
        for ($j = 0; $j < 3; $j++) 
        { 
            $index1 = rand(0, strlen($characters) - 1); 
            $randomString1 .= $characters[$index1]; 
        } 
        $my_fixed_id=$randomString.$randomString1;
        $my_login_id = $my_fixed_id;

        /*--------------------------------------------------------------------------------------------------------
                                            Generate joining id
         ---------------------------------------------------------------------------------------------------------*/
            
        $myname1 = $applicant_name;
        $generate_random_2_digit_number= mt_rand(10, 99);
        $myname = str_replace(' ', $generate_random_2_digit_number, $myname1);
        $myadharcard = $adhar_number;
        $generate_random_3_digit_number= mt_rand(100, 999);
        $result = substr($myname, 0, 3);
        $result1 = mb_substr($myadharcard, 0, 3);
        $final=  $result.$generate_random_3_digit_number.$result1;
        $my_joining_id = strtoupper($final);

        /*--------------------------------------------------------------------------------------------------------

        ---------------------------------------------------------------------------------------------------------*/



        /*--------------------------------------------------------------------------------------------------------
                                        Check sponsor id if present or not
        ---------------------------------------------------------------------------------------------------------*/

        $sql = "SELECT `joining_id` FROM `tgroups_user` WHERE `joining_id` = '$sponsor_id'";
        $runquery = mysqli_query($con,$sql);

        if (mysqli_num_rows($runquery) <= 0)
        {        
            echo '<script>alert("Please check your sponser ID.");
            window.location="../registration.php";</script>';
        }
        else
        {


            /*--------------------------------------------------------------------------------------------------------
                                            Check adhar card registered 3 times or not
            ---------------------------------------------------------------------------------------------------------*/


            $sql0 = "SELECT COUNT(`same_pancard_account`) AS account_count FROM `tgroups_user` WHERE `adhar_number` = '$adhar_number'";
            $runquery0 = mysqli_query($con,$sql0);
            $row0 = mysqli_fetch_assoc($runquery0);
            if ($row0['account_count'] == 3) 
            {
                echo '<script>alert("You can not create more than 3 accounts with same adhar card.");
                    window.location="../registration.php";</script>';
            }
            else
            {


                /*--------------------------------------------------------------------------------------------------------
                                                Check sponsor id is block or deacivated
                ---------------------------------------------------------------------------------------------------------*/


                $sql1 = "SELECT `active`, `block`, `id`  FROM `tgroups_user` WHERE `joining_id` = '$sponsor_id'";
                $runquery1 = mysqli_query($con,$sql1);
                $row1 = mysqli_fetch_assoc($runquery1);

                $id = $row1['id'];

                if ($row1['active'] == "0")
                {        
                    echo '<script>alert("Sponser ID is deactivated.");
                    window.location="../registration.php";</script>';
                }
                else if ($row1['block'] == "1")
                {        
                    echo '<script>alert("Sponser ID is blocked.");
                    window.location="../registration.php";</script>';
                }
                else 
                {   



                    /*--------------------------------------------------------------------------------------------------------
                                                Check under member count
                    ---------------------------------------------------------------------------------------------------------*/

                    $sql2 = "SELECT `under_member_count` FROM `tgroups_user` WHERE `id` = '$id'";
                    $runquery2 = mysqli_query($con,$sql2);
                    $row2 = mysqli_fetch_assoc($runquery2);
                    //$undercount = null;
                    //$runquery3 = null;

                    if($row2['under_member_count'] == 0)
                    {
                        $undercount = '1';
                        $sql3 = "UPDATE `tgroups_user` SET `under_member_count` = '$undercount' WHERE `tgroups_user`.`joining_id` = '$sponsor_id'";
                        $runquery3 = mysqli_query($con,$sql3);
                    } 
                    else if($row2['under_member_count'] == 1)
                    {
                        $undercount = '2';
                        $sql3 = "UPDATE `tgroups_user` SET `under_member_count` = '$undercount' WHERE `tgroups_user`.`joining_id` = '$sponsor_id'";
                        $runquery3 = mysqli_query($con,$sql3);
                    }
                    else if($row2['under_member_count'] == 2)
                    {
                        echo '<script>alert("Sponser ID limit exceeded.");
                            window.location="../registration.php";</script>';
                    }
                    $runquery6 = null;
                    if ($runquery2)
                    {



                        /*--------------------------------------------------------------------------------------------------------
                                                    Check 2 under member count
                        ---------------------------------------------------------------------------------------------------------*/



                        $sql4 = "SELECT `sponsor_id` FROM `tgroups_user` WHERE `joining_id` = '$sponsor_id'";
                        $runquery4 = mysqli_query($con,$sql4);
                        $row4 = mysqli_fetch_assoc($runquery4);
                        $sponsor_of_this_user = $row4['sponsor_id'];
                        if($runquery4)
                        {

                            $sql5 = "SELECT `under_2_member_count` FROM `tgroups_user` WHERE `joining_id` = '$sponsor_of_this_user'";
                            $runquery5 = mysqli_query($con,$sql5);
                            $row5 = mysqli_fetch_assoc($runquery5);
                            $undercount1 = null;

                            if($runquery5)
                            {

                                if($row5['under_2_member_count'] == 0){$undercount1 = 1;} else if($row5['under_2_member_count'] == 1){$undercount1 = 2;}
                                else if($row5['under_2_member_count'] == 2){$undercount1 = 3;}else if($row5['under_2_member_count'] == 3){$undercount1 = 4;}

                                $sql6 = "UPDATE `tgroups_user` SET `under_2_member_count` = '$undercount1' WHERE `tgroups_user`.`joining_id` = '$sponsor_of_this_user'";
                                $runquery6 = mysqli_query($con,$sql6);
                            }
                        }






                        /*--------------------------------------------------------------------------------------------------------


                                                                TREE STRUCTURE START


                        ---------------------------------------------------------------------------------------------------------*/
                        




                        /*-----------------------------------------Get upper sponsor id------------------------------------------*/
                        $runquery12 = null;
                        if ($runquery6) 
                        {

                            $sql7 = "SELECT `fixed_id` FROM `tgroups_joining_id` WHERE `joining_id` = '$sponsor_id'";
                            $runquery7 = mysqli_query($con,$sql7);
                            $row7 = mysqli_fetch_assoc($runquery7);
                            $upper_sponsor_fixed_id = $row7['fixed_id'];

                            if($runquery7)
                            {
                                /*-----------------------------------------Get main sponsor id------------------------------------------*/

                                $sql8 = "SELECT `sponsor_fixed_id` FROM `tgroups_my_and_sponsor_fixed_id` WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
                                $runquery8 = mysqli_query($con,$sql8);
                                $row8 = mysqli_fetch_assoc($runquery8);
                                $main_sponsor_fixed_id = $row8['sponsor_fixed_id'];

                                if ($runquery8) 
                                {
                                    
                                    /*-----------------------------------------Update My fixed id into my main and upper sponsores row------------------------------------------*/


                                    /*---------------------------------In Upper sponsor row First check there is any column is empty------------------------------*/

                                    $sql9 = "SELECT `first_row_first_member`, `first_row_second_member` FROM `tgroups_tree_structure` WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
                                    $runquery9 = mysqli_query($con,$sql9);
                                    $row9 = mysqli_fetch_assoc($runquery9);
                                    $first_row_first_member = $row9['first_row_first_member'];
                                    $first_row_second_member = $row9['first_row_second_member'];

                                    if ($runquery9) 
                                    {

                                        if ($first_row_first_member == "" && $first_row_second_member == "") 
                                        {
                                            
                                            /*-----------------------------------------Update my login id at my upper sponsor id row in tree structure----------------------------*/

                                            $sql10 = "UPDATE `tgroups_tree_structure` SET `first_row_first_member` = '$my_fixed_id' WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
                                            $runquery10 = mysqli_query($con,$sql10);

                                        }
                                        else if ($first_row_first_member != "" && $first_row_second_member == "") 
                                        {
                                            
                                            /*-----------------------------------------Update my login id at my upper sponsor id row in tree structure----------------------------*/

                                            $sql10 = "UPDATE `tgroups_tree_structure` SET `first_row_second_member` = '$my_fixed_id' WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
                                            $runquery10 = mysqli_query($con,$sql10);

                                        }
                                    }



                                    /*--------------------------------------------------------------------------------------------------------

                                    ---------------------------------------------------------------------------------------------------------*/


                                    /*---------------------------------In Main sponsor row First check there is any column is empty------------------------------*/

                                    $sql11 = "SELECT * FROM `tgroups_tree_structure` WHERE `fixed_id` = '$main_sponsor_fixed_id'";
                                    $runquery11 = mysqli_query($con,$sql11);
                                    $row11 = mysqli_fetch_assoc($runquery11);

                                    $first_row_first_member = $row11['first_row_first_member'];
                                    $first_row_second_member = $row11['first_row_second_member'];

                                    $second_row_first_member = $row11['second_row_first_member'];
                                    $second_row_second_member = $row11['second_row_second_member'];
                                    $second_row_third_member = $row11['second_row_third_member'];
                                    $second_row_fourth_member = $row11['second_row_fourth_member'];

                                    if ($runquery11) 
                                    {
                                        if ($first_row_first_member == $upper_sponsor_fixed_id) 
                                        {
                                            if ($second_row_first_member == "" && $second_row_second_member == "") 
                                            {
                                               /*-----------------------------------------Update my login id at my main sponsor id row in tree structure----------------------------*/

                                                $sql12 = "UPDATE `tgroups_tree_structure` SET `second_row_first_member` = '$my_fixed_id' WHERE `fixed_id` = '$main_sponsor_fixed_id'";
                                                $runquery12 = mysqli_query($con,$sql12);

                                            }
                                            else if ($second_row_first_member != "" && $second_row_second_member == "") 
                                            {
                                               /*-----------------------------------------Update my login id at my main sponsor id row in tree structure----------------------------*/

                                                $sql12 = "UPDATE `tgroups_tree_structure` SET `second_row_second_member` = '$my_fixed_id' WHERE `fixed_id` = '$main_sponsor_fixed_id'";
                                                $runquery12 = mysqli_query($con,$sql12);

                                            }
                                        }
                                        else if ($first_row_second_member == $upper_sponsor_fixed_id) 
                                        {
                                            if ($second_row_third_member == "" && $second_row_fourth_member == "") 
                                            {
                                               /*-----------------------------------------Update my login id at my main sponsor id row in tree structure----------------------------*/

                                                $sql12 = "UPDATE `tgroups_tree_structure` SET `second_row_third_member` = '$my_fixed_id' WHERE `fixed_id` = '$main_sponsor_fixed_id'";
                                                $runquery12 = mysqli_query($con,$sql12);

                                            }
                                            else if ($second_row_third_member != "" && $second_row_fourth_member == "") 
                                            {
                                               /*-----------------------------------------Update my login id at my main sponsor id row in tree structure----------------------------*/

                                                $sql12 = "UPDATE `tgroups_tree_structure` SET `second_row_fourth_member` = '$my_fixed_id' WHERE `fixed_id` = '$main_sponsor_fixed_id'";
                                                $runquery12 = mysqli_query($con,$sql12);

                                            }
                                        }
                                    }

                                }


                                /*--------------------------------------------------------------------------------------------------------


                                                                        TREE STRUCTURE END


                                ---------------------------------------------------------------------------------------------------------*/




                                /*--------------------------------------------------------------------------------------------------------


                                                                        insert queries start


                                ---------------------------------------------------------------------------------------------------------*/



                                /*---------------------------------------------------------------------------------------------------------
                                                                        JOINING ID TABLE
                                ---------------------------------------------------------------------------------------------------------*/
                                $runquery13_1 = null;
                                if ($runquery12 || $runquery10) 
                                {

                                    $sql13_1 = "INSERT INTO `tgroups_tree_structure` 
                                            (
                                                `fixed_id`,
                                                `sponsor_id`
                                            ) 
                                            VALUES
                                            (
                                                '$my_fixed_id',
                                                '$sponsor_id'
                                            )";
                                    $runquery13_1 = mysqli_query($con,$sql13_1);
                                            
                                }


                                /*---------------------------------------------------------------------------------------------------------
                                                                        JOINING ID TABLE
                                ---------------------------------------------------------------------------------------------------------*/
                                $runquery13 = null;
                                if ($runquery13_1) 
                                {

                                    $sql13 = "INSERT INTO `tgroups_joining_id` 
                                            (
                                                `fixed_id`,
                                                `joining_id`
                                            ) 
                                            VALUES
                                            (
                                                '$my_fixed_id',
                                                '$my_joining_id'
                                            )";
                                    $runquery13 = mysqli_query($con,$sql13);
                                            
                                }



                                /*---------------------------------------------------------------------------------------------------------
                                                                        MY AND SPONSOR FIXED ID
                                ---------------------------------------------------------------------------------------------------------*/
                                $runquery14 = null;
                                if ($runquery13) 
                                {

                                    $sql14 = "INSERT INTO `tgroups_my_and_sponsor_fixed_id` 
                                            (
                                                `fixed_id`,
                                                `sponsor_fixed_id`
                                            ) 
                                            VALUES
                                            (
                                                '$my_fixed_id',
                                                '$upper_sponsor_fixed_id'
                                            )";
                                    $runquery14 = mysqli_query($con,$sql14);
                                            
                                }



                                /*---------------------------------------------------------------------------------------------------------
                                                                        WALLET
                                ---------------------------------------------------------------------------------------------------------*/
                                $runquery15 = null;
                                if ($runquery14) 
                                {

                                    $sql15 = "INSERT INTO `tgroups_wallet` 
                                            (
                                                `fixed_id`
                                            ) 
                                            VALUES
                                            (
                                                '$my_fixed_id'
                                            )";
                                    $runquery15 = mysqli_query($con,$sql15);
                                            
                                }



                                /*---------------------------------------------------------------------------------------------------------
                                                                        USER REGISTRATION
                                ---------------------------------------------------------------------------------------------------------*/
                                $runquery16 = null;
                                if ($runquery15) 
                                {

                                    $sql16 = "INSERT INTO `tgroups_user` 
                                            (
                                                `fixed_id`, 
                                                `login_id`, 
                                                `joining_id`, 
                                                `decoded`, 
                                                `sponsor_name`, 
                                                `sponsor_id`, 
                                                `applicant_name`, 
                                                `applicant_mobile_number`, 
                                                `applicant_email_id`, 
                                                `applicant_password`, 
                                                `bank_name`, 
                                                `branch_name`, 
                                                `account_number`, 
                                                `ifsc_code`, 
                                                `paytm_number`, 
                                                `phonepe_number`, 
                                                `google_pay_number`, 
                                                `pancard_number`,
                                                `adhar_number`
                                            ) 
                                            VALUES
                                            (
                                                '$my_fixed_id',
                                                '$my_login_id',
                                                '$my_joining_id',
                                                '$applicant_password',
                                                '$sponsor_name',
                                                '$sponsor_id',
                                                '$applicant_name',
                                                '$applicant_mobile_number',
                                                '$applicant_email_id',
                                                '$passwordhash',
                                                '$bank_name',
                                                '$branch_name',
                                                '$account_number',
                                                '$ifsc_code',
                                                '$paytm_number',
                                                '$phonepe_number',
                                                '$google_pay_number',
                                                '$pancard_number',
                                                '$adhar_number'
                                            ) ";
                                      
                                    $runquery16 = mysqli_query($con,$sql16);
                                }

                                if($runquery16)
                                {
                                    $message = '<p><h2>Welcome</h2>,<h3><b>'.$applicant_name.'</b></h3><br>Your successfully registered with us.Now seat back and earn money.<br>Thanks, Trimurthi Groups Admin.
                                    <a href="http://trimurthigroups.com/login.php">Login To Your Account</a></p>';
                                    //to send HTML mail, the Content-type header must be set:
                                    $headers = "From: noreply@trimurthigroups.com\r\n";
                                    $headers .= "Reply-To: noreply@trimurthigroups.com\r\n";
                                    $headers .= "MIME-Version: 1.0\r\n";
                                    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                            
                                    $subject = "Trimurthi Groups Account Registration";
                                    //mail function
                                    $mail = mail($applicant_email_id, $subject, $message, $headers);
                                    
                                    header("location: ../show_login_id.php?".$my_login_id);
                                    echo "<script>alert('User successfully registered.');</script>";
                                }
                                else
                                {
                                    echo '<script>alert("Error!! in registering user....");
                                    window.location="../registration.php";</script>';
                                }
                            }
                            
                        }
                    }

                }
            }
        }
    }
    
?>