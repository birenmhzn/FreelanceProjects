<?php
	session_start();
	unset($_SESSION["login_id"]);
	unset($_SESSION["applicant_name"]);
	header("Location:login.php");
?>