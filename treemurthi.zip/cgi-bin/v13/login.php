
<script type="text/javascript">
    window.onload=function(){
      document.getElementById("add_redirect").click();
    };
</script>
<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if(isset($_POST['login']))
    {
        if(count($_POST)>0) 
        {
            $loginid = $_POST["login_id"];
            $applicantpassword = $_POST["applicant_password"];
            $passwordhash = null;

            if (CRYPT_BLOWFISH == 1)
            {
                $passwordhash = crypt($applicantpassword ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
            }
            else
            {   
                echo '<script>alert("Blowfish DES not supported.");
                window.location="login.php";</script>';
            }

            $sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$loginid' AND `applicant_password` = '$passwordhash' AND `block` = '0'";//`
            $runquery = mysqli_query($con,$sql);
            $row=mysqli_fetch_assoc($runquery);
            $sponsor_id1 = $row['sponsor_id'];
            /*--------------------------------------------------------------------------------------------------------

            ---------------------------------------------------------------------------------------------------------*/
                
            $myname = $row['applicant_name'];
            $myaccountnumber = $row['account_number'];
            $generate_random_3_digit_number= mt_rand(100, 999);
            $result = substr($myname, 0, 3);
            $result1 = mb_substr($myaccountnumber, 0, 3);
            $final=  $result.$generate_random_3_digit_number.$result1;
            $user_id = strtoupper($final);

            /*--------------------------------------------------------------------------------------------------------

            ---------------------------------------------------------------------------------------------------------*/
            if($row)
            {  
                $sql2="SELECT `login_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id1' ORDER BY `id` DESC LIMIT 1";//`
                $runquery2 = mysqli_query($con,$sql2);
                $row2=mysqli_fetch_assoc($runquery2);
                $login_id1 = $row2['login_id'];        

                if($row2)
                {
                    $sql3="SELECT `user_id` FROM `tgroups_user` WHERE `login_id` = '$login_id1' ORDER BY `id` DESC LIMIT 1";//`
                    $runquery3 = mysqli_query($con,$sql3);
                    $row3=mysqli_fetch_assoc($runquery3);
                    $user_id1 = $row3['user_id'];

                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/

                    if($row2)
                    {  
                        $loginid4 = $row['login_id'];
                        $_SESSION["applicant_name"] = $row['applicant_name'];
                        $_SESSION["login_id"] = $row['login_id'];
        	            $_SESSION['loggedin_time'] = time();       
        	            echo '<script>alert("Welcome.");
                                window.location="profile.php";</script>';
                    }
                    else
                    {
                        echo '<script>alert("Something went wrong.");
                            window.location="login.php";</script>';
                    } 
                }
            }
            else
            {
                echo '<script>alert("Enter wrong credentials or your ID is blocked or not active.");
                    window.location="login.php";</script>';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Login</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Login</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="signupform">
			<div class="container">
				<!-- main content -->
				<div class="main-content">
					<div class="contect_left_form">
						<div class="left_grid_info">
							<h1>Manage Your Business Account</h1>
							<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
							<img src="images/image.jpg" alt="" />
						</div>
					</div>
					<div class="login_info">
						<h2>Login to your Account</h2>
						<p>Enter your details to login.</p>
						<form action="#" method="post">
							<label>Login ID</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" placeholder="Enter Your Login ID" name="login_id" required> 
							</div>
							<label>Password</label>
							<div class="input-group">
								<span class="fa fa-lock" aria-hidden="true"></span>
								<input type="Password" placeholder="Enter Password" name="applicant_password" required>
							</div> 
							<div class="login-check">
								 <label class="checkbox"><input type="checkbox" name="checkbox" checked><i> </i> Remember me</label>
							</div>						
							<input class="btn btn-danger btn-block" type="submit" value="Login" name="login" /> 
              			</form>
						<p class="account">By clicking login, you agree to our <a href="#">Terms & Conditions!</a></p>
						<p class="account1">Dont have an account? <a href="registration.php">Register here</a></p>
						<p class="account1"><a href="registration.php">Forget password?</a></p>
					</div>
				</div>
				<!-- //main content -->
			</div>
		</div>
		
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>