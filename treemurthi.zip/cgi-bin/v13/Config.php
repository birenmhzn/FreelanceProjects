<?php
    $con = mysqli_connect("localhost","tgroups_admin","Tgroupsadmin@1"); 
    if (!$con)
    {
        die('Could not connect1: ' . mysqli_error());
    }
      /*if($con){
          die('Database connected successfuly.');
      }*/
    if(!mysqli_select_db($con, "tgroups_secured_db"))
    {
        die('Database not connected: ' . mysqli_error());
    }
?>