<?php
    include('../sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["admin_login_id"]) {
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Admin Dashboard</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Admin Dashboard</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<?php
			$sql="SELECT tgroups_withdraw_request.`withdraw_amount`, tgroups_withdraw_request.`user_id`, tgroups_withdraw_request.`datetime`, tgroups_user.`applicant_name`, tgroups_user.`fixed_id` FROM tgroups_withdraw_request INNER JOIN tgroups_user ON tgroups_withdraw_request.`user_id`=tgroups_user.`user_id` WHERE tgroups_withdraw_request.`is_status` = 'PENDING'";
		    $runquery = mysqli_query($con,$sql);
		    $row=mysqli_fetch_assoc($runquery);
		?>
		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Users Withdraw Request</h3></b></center><br>
				<div class="table-responsive">
					<table class="table table-bordered">
					    <thead>
					      	<tr>
					        	<th>User ID</th>
					        	<th>Applicant Name</th>
					        	<th>Withdraw Amount</th>
					        	<th>Date Time</th>
					        	<th></th>
					      	</tr>
					    </thead>
					    <tbody>
					      	<?php
								$sql="SELECT tgroups_withdraw_request.`withdraw_amount`, tgroups_withdraw_request.`user_id`, tgroups_withdraw_request.`datetime`, tgroups_user.`applicant_name`, tgroups_user.`fixed_id` FROM tgroups_withdraw_request INNER JOIN tgroups_user ON tgroups_withdraw_request.`user_id`=tgroups_user.`user_id` WHERE tgroups_withdraw_request.`is_status` = 'PENDING'";
							    $runquery = mysqli_query($con,$sql);
					    		if($runquery)
                            	{     
                                	while($row=mysqli_fetch_assoc($runquery)) 
                                	{
					    	?>
								      	<tr style="font-weight: normal;">
								        	<td><?php echo $row['user_id']; ?></td>
								        	<td><?php echo $row['applicant_name']; ?></td>
								        	<td><?php echo $row['withdraw_amount']; ?></td>
								        	<td><?php echo $row['datetime']; ?></td>
								        	<td><input class="btn btn-success btn-block" type="submit" value="Approved" name="withdraw_approved" /> </td>
								      	</tr>
							<?php } } ?>
					    </tbody>
					</table>
				</div>
			</div>
		</div>

		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "../footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'index.php';
            </script>";
    }
?>