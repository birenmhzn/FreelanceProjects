<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<script>
			addEventListener("load", function () {
				setTimeout(hideURLbar, 0);
			}, false);

			function hideURLbar() {
				window.scrollTo(0, 1);
			}
		</script>
		<!-- //Meta tag Keywords -->

		<!-- Custom-Files -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Bootstrap-Core-CSS -->
		<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
		<!-- Style-CSS -->

		<!-- css files -->
		<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<!-- google fonts -->
		<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- //google fonts -->


		<!-- Web-Fonts -->
		<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext"
		 rel="stylesheet">
		<!-- //Web-Fonts -->
	</head>
	<body>
				<div class="container-fluid">
					<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
						<!-- logo -->
						<div id="logo">
							<h1><a href="index.php"><span class="fa fa-linode mr-2"></span>Trimurthi Groups</a></h1>
						</div>
						<!-- //logo -->
						<!-- nav -->
						<div class="nav_temps-amkls">
							<?php
					            if(isset($_SESSION["login_id"])) 
					            {
					                $applicant_name = $_SESSION["applicant_name"];
					                $login_id = $_SESSION["login_id"]; 
					                
					                $sql4="SELECT `active` FROM `tgroups_user` WHERE `login_id` = '$login_id'";//`
			                        $runquery4 = mysqli_query($con,$sql4);
			                        $row4=mysqli_fetch_assoc($runquery4);
			                        $active4 = $row4['active'];
			                        if ($active4 == '0') {
			                            echo '<script>alert("Your login id is not active please make payment of 250 rupees.");
			                                window.location="make_payment.php";</script>';
			                        } 
					        ?>
					        		<nav>
										<label for="drop" class="toggle">Menu</label>
										<input type="checkbox" id="drop" />
										<ul class="menu">
											<li><a href="index.php" class="active">Home</a></li>
											<li><a href="contact.php">Contact Us</a></li>
											<li><a href="withdraw.php">Withdraw</a></li>
											<li><a href="direct_joins.php">Direct Joins</a></li>
											<li><a href="re_entry.php">Re-Entry</a></li>
											<li><a href="login.php"><span class="glyphicon glyphicon-user"></span>&nbsp;Hello,&nbsp;<b><?php echo $_SESSION["applicant_name"]; ?></b></a></li>
											<?php
												$sql="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id'";//`
									            $runquery = mysqli_query($con,$sql);
									            $row=mysqli_fetch_assoc($runquery);
											?>
											<li><a><b>Balance : <font style="color: #705ecf;"><?php echo $row['balance_amount']; ?></font></a></li>
											<li><a href="logout.php">Logout</a></li>
										</ul>
									</nav>
					        <?php
					            }
					            else
					            {
					        ?>  
									<nav>
										<label for="drop" class="toggle">Menu</label>
										<input type="checkbox" id="drop" />
										<ul class="menu">
											<li><a href="index.php" class="active">Home</a></li>
											<!--<li>
												<-- First Tier Drop Down ->
												<label for="drop-2" class="toggle toogle-2">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span>
												</label>
												<a href="#">Dropdown <span class="fa fa-angle-down" aria-hidden="true"></span></a>
												<input type="checkbox" id="drop-2" />
												<ul>
													<li><a href="#services" class="drop-text">Services</a></li>
													<li><a href="faq.php" class="drop-text">Faq's</a></li>
													<li><a href="404.php" class="drop-text">404</a></li>
													<li><a href="#stats" class="drop-text">Statistics</a></li>
													<li><a href="about.php" class="drop-text">Why Choose Us?</a></li>
													<li><a href="about.php" class="drop-text">Our Team</a></li>
													<li><a href="#partners" class="drop-text">Partners</a></li>
												</ul>
											</li>-->
											<li><a href="contact.php">Contact Us</a></li>
											<!--<li><a href="plan.php">Plan</a></li>-->
											<li><a href="login.php">Log In</a></li>
											<li><a href="registration.php">Register</a></li>
										</ul>
									</nav>
							<?php
					            }
					        ?>
						</div>
						<!-- //nav ->
						<div class="d-flex mt-lg-1 mt-sm-2 mt-3 justify-content-center">
							<-- search ->
							<div class="search-temps-amklayouts mr-3">
								<form action="#" method="post" class="search-bottom-amk-tems d-flex">
									<input class="search" type="search" placeholder="Search Here..." required="">
									<button class="form-control btn" type="submit"><span class="fa fa-search"></span></button>
								</form>
							</div>
							<-- //search ->
						</div>-->
					</div>
				</div>
	</body>
</html>