<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
        $login_id = $_SESSION["login_id"];
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Re-Entry</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Re-Entry</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<?php
			$sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id' ORDER BY `id` DESC LIMIT 1";//`
		    $runquery = mysqli_query($con,$sql);
		    $row=mysqli_fetch_assoc($runquery);
		    $user_id = $row['user_id'];
		?>
		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Your Re-Entry</h3></b></center><br>

				<div class="container">
				  	<h2>Sponsor ID: <font style="color: #705ecf;"><?php echo $user_id; ?></font></h2>        
				  	<table class="table table-hover">
				    	<thead>
				      		<tr>
				        		<th>User ID</th>
				        		<th>Re-Entry Time/Date</th>
				      		</tr>
				    	</thead>
					    <tbody>
					    	<?php
								$sql1="SELECT `user_id`, `account_creation_date` FROM `tgroups_user` WHERE `login_id` = '$login_id'";//`
							    $runquery1 = mysqli_query($con,$sql1);
					    		if($runquery1)
                            	{     
                                	while($row1=mysqli_fetch_ASsoc($runquery1)) 
                                	{

	                                    $user_id = $row1['user_id'];
	                                    $account_creation_date = $row1['account_creation_date'];
					    	?>
								      	<tr style="font-weight: normal;">
								        	<td><?php echo $user_id; ?></td>
								        	<td><?php echo $account_creation_date; ?></td>
								      	</tr>
							<?php } } ?>
					    </tbody>
				  	</table>
				</div>
			</div>
		</div>


		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>