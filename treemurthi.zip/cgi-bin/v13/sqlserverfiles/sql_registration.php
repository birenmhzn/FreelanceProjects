<?php
    include "Config.php";
    if(isset($_POST['register']))
    {    
        $sponsor_name = $_POST['sponsor_name'];
        $sponsor_id = $_POST['sponsor_id'];
        $applicant_name = $_POST['applicant_name'];
        $applicant_mobile_number = $_POST['applicant_mobile_number'];
        $applicant_email_id = $_POST['applicant_email_id'];
        $applicant_password = $_POST['applicant_password'];
        $bank_name = $_POST['bank_name'];
        $branch_name = $_POST['branch_name'];
        $account_number = $_POST['account_number'];
        $ifsc_code = $_POST['ifsc_code'];
        $paytm_number = $_POST['paytm_number'];
        $phonepe_number = $_POST['phonepe_number'];
        $google_pay_number = $_POST['google_pay_number'];
        $pancard_number = $_POST['pancard_number'];
        $adhar_number = $_POST['adhar_number'];
        
        $passwordhash = null;
        /*--------------------------------------------------------------------------------------------------------
                                        Check sponsor id if present or not
        ---------------------------------------------------------------------------------------------------------*/

        $sql="SELECT `user_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id'";//`
        $runquery = mysqli_query($con,$sql);
        if (mysqli_num_rows($runquery) <= 0)
        {        
            echo '<script>alert("Please check your sponser ID.");
            window.location="../registration.php";</script>';
        }
        else
        {
            /*--------------------------------------------------------------------------------------------------------
                                            Check sponsor id if present or not
            ---------------------------------------------------------------------------------------------------------*/
            $sql2="SELECT `active`, `block`  FROM `tgroups_user` WHERE `user_id` = '$sponsor_id'";//`
            $runquery2 = mysqli_query($con,$sql2);
            $row2=mysqli_fetch_assoc($runquery2);
            if ($row2['active'] == "0" || $row2['block'] == "1"  )
            {        
                echo '<script>alert("Sponser ID is deactivated or blocked.");
                window.location="../registration.php";</script>';
            }
            else
            {   
                
                /*--------------------------------------------------------------------------------------------------------

                ---------------------------------------------------------------------------------------------------------*/

                $check2="SELECT `under_member_count` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id'";
                $rs2 = mysqli_query($con,$check2);
                $row2=mysqli_fetch_assoc($rs2);
                $undercount = null;
                $runquery3 = null;
                if($row2['under_member_count'] == 0){
                    $undercount = '1';
                    $sql3="UPDATE `tgroups_user` SET `under_member_count` = '$undercount' WHERE `tgroups_user`.`user_id` = '$sponsor_id'";//`
                    $runquery3 = mysqli_query($con,$sql3);
                } 
                else if($row2['under_member_count'] == 1){
                    $undercount = '2';
                    $sql3="UPDATE `tgroups_user` SET `under_member_count` = '$undercount' WHERE `tgroups_user`.`user_id` = '$sponsor_id'";//`
                    $runquery3 = mysqli_query($con,$sql3);
                }
                else if($row2['under_member_count'] == 2){
                    echo '<script>alert("Sponser ID limit exceeded.");
                        window.location="../registration.php";</script>';
                }
                if ($runquery3)
                {
                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/

                    $check3="SELECT `sponsor_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id'";
                    $rs3 = mysqli_query($con,$check3);
                    $row3=mysqli_fetch_assoc($rs3);
                    $sponsorofthisuser = $row3[sponsor_id];

                    $check4="SELECT `under_2_member_count` FROM `tgroups_user` WHERE `user_id` = '$sponsorofthisuser'";
                    $rs4 = mysqli_query($con,$check4);
                    $row4=mysqli_fetch_assoc($rs4);
                    $undercount1 = null;

                    if($row4[under_2_member_count] == 0){$undercount1 = 1;} else if($row4[under_2_member_count] == 1){$undercount1 = 2;}
                    else if($row4[under_2_member_count] == 2){$undercount1 = 3;}else if($row4[under_2_member_count] == 3){$undercount1 = 4;}
                    $sql4="UPDATE `tgroups_user` SET `under_2_member_count` = '$undercount1' WHERE `tgroups_user`.`user_id` = '$sponsorofthisuser'";//`
                    $runquery4 = mysqli_query($con,$sql4);

                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/
                    $n2= mt_rand(100, 999);;
                    $characters = '0123456789'; 
                    $randomString = ''; 
                    $randomString1 = ''; 

                    for ($i = 0; $i < 3; $i++) { 
                        $index = rand(0, strlen($characters) - 1); 
                        $randomString .= $characters[$index]; 
                    } 
                    for ($j = 0; $j < 3; $j++) { 
                        $index1 = rand(0, strlen($characters) - 1); 
                        $randomString1 .= $characters[$index1]; 
                    } 
                    $fixed_id=$randomString.$randomString1;
                    $login_id = $fixed_id;
                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/
                    
                    $myname = $applicant_name;
                    $myadharcard = $adhar_number;
                    $generate_random_3_digit_number= mt_rand(100, 999);
                    $result = substr($myname, 0, 3);
                    $result1 = mb_substr($myadharcard, 0, 3);
                    $final=  $result.$generate_random_3_digit_number.$result1;
                    $user_id = strtoupper($final);
                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/

                    if (CRYPT_BLOWFISH == 1)
                    {
                        $passwordhash = crypt($applicant_password ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
                    }
                    else
                    {   
                        echo '<script>alert("Blowfish DES not supported.");
                        window.location="../registration.php";</script>';
                    }
                    /*--------------------------------------------------------------------------------------------------------

                    ---------------------------------------------------------------------------------------------------------*/

                    $check="SELECT COUNT(`same_pancard_account`) AS account_count FROM `tgroups_user` WHERE `adhar_number` = '$adhar_number'";
                    $rs = mysqli_query($con,$check);
                    $row=mysqli_fetch_assoc($rs);
                    if($row[account_count] == 3) {
                        echo '<script>alert("You can not create more than 3 accounts with same pancard.");
                                window.location="../registration.php";</script>';
                    }
                    else
                    {
                        $sql1="INSERT INTO `tgroups_user` 
                        (`fixed_id`, 
                        `login_id`, 
                        `user_id`, 
                        `sponsor_name`, 
                        `sponsor_id`, 
                        `applicant_name`, 
                        `applicant_mobile_number`, 
                        `applicant_email_id`, 
                        `applicant_password`, 
                        `bank_name`, 
                        `branch_name`, 
                        `account_number`, 
                        `ifsc_code`, 
                        `paytm_number`, 
                        `phonepe_number`, 
                        `google_pay_number`, 
                        `pancard_number`,
                        `adhar_number`) 
                        VALUES
                        ('$fixed_id',
                        '$login_id',
                        '$user_id',
                        '$sponsor_name',
                        '$sponsor_id',
                        '$applicant_name',
                        '$applicant_mobile_number',
                        '$applicant_email_id',
                        '$passwordhash',
                        '$bank_name',
                        '$branch_name',
                        '$account_number',
                        '$ifsc_code',
                        '$paytm_number',
                        '$phonepe_number',
                        '$google_pay_number',
                        '$pancard_number',
                        '$adhar_number') ";
                          
                        $runquery1 = mysqli_query($con,$sql1);

                        $sql2="INSERT INTO `tgroups_wallet` 
                        (`login_id`, 
                        `balance_amount`) 
                        VALUES
                        ('$login_id',
                        '0') ";
                          
                        $runquery2 = mysqli_query($con,$sql2);


                          
                        if($runquery1 && $runquery2)
                        {
                            header("location: ../show_login_id.php?".$login_id);
                            echo "<script>alert('User successfully registered.');</script>";
                        }
                        else
                        {
                            echo '<script>alert("Error!! in registering user....");
                            window.location="../registration.php";</script>';
                        }
                    }
                }
            }
        }
    }
?>