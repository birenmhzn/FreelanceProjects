<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
        $login_id = $_SESSION["login_id"];
        if(isset($_POST['withdraw_btn']))
	    {
	        $withdraw_amount = $_POST["withdraw_amount"];
	        
	        
			$sql="SELECT `balance_amount` FROM ` tgroups_wallet` WHERE `login_id` = '$login_id'";
		    $runquery = mysqli_query($con,$sql);
		    $row=mysqli_fetch_assoc($runquery); 
		    $balance_amount = $row['balance_amount'];
		    if($balance_amount == '0' || $balance_amount <= '0'){
		        echo '<script>alert("Low balance.");
                window.location="withdraw.php";</script>';
		    }
		    else{
                $total_amount = $balance_amount - $withdraw_amount;
                $sql3="UPDATE ` tgroups_wallet` SET `balance_amount` = '$total_amount' WHERE ` tgroups_wallet`.`login_id` = '$login_id'";
                $runquery3 = mysqli_query($con,$sql3);
                
                
		        $percentage = 10;
                $totalWidth = $withdraw_amount;
                $calc = ($percentage / 100) * $totalWidth;
                $total_withdraw = $withdraw_amount - $calc;
                
    			$sql4="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id' ORDER BY `id` DESC LIMIT 1";//`
    		    $runquery4 = mysqli_query($con,$sql4);
    		    $row4=mysqli_fetch_assoc($runquery4);
    		    $user_id = $row4['user_id'];
                
                $sql5="INSERT INTO `tgroups_withdraw_request`(`fixed_id`, `user_id`, `withdraw_amount`, `is_status`) VALUES ('$login_id', '$user_id', '$total_withdraw', 'Pending' )";
                $runquery5 = mysqli_query($con,$sql5);
		    }
	    }
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Withdraw</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Withdraw</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Withdraw</h3></b></center><br>

				<div class="container" style="width:50%;">
				    <form method="post" action="#">
    				  	<input class="form-control" name="withdraw_amount" required>
    				  	<center>
    				  	    <input class="btn-success" type="submit" name="withdraw_btn">
    				  	</center>
				  	</form>
				</div>
				<div class="container">
				  	<h2>Withdraw History</h2>        
				  	<table class="table table-hover">
				    	<thead>
				      		<tr>
				        		<th>Amount</th>
				        		<th>Time/Date</th>
				        		<th>Status</th>
				      		</tr>
				    	</thead>
					    <tbody>
					    	<?php
								$sql1="SELECT `withdraw_amount`, `is_status`, `datetime` FROM `tgroups_withdraw_request` WHERE `fixed_id` = '$login_id'";//`
							    $runquery1 = mysqli_query($con,$sql1);
					    		if($runquery1)
                            	{     
                                	while($row1=mysqli_fetch_ASsoc($runquery1)) 
                                	{

	                                    $user_id = $row1['withdraw_amount'];
	                                    $datetime = $row1['datetime'];
	                                    $is_status = $row1['is_status'];
					    	?>
								      	<tr style="font-weight: normal;">
								        	<td><?php echo $user_id; ?></td>
								        	<td><?php echo $datetime; ?></td>
								        	<td><?php echo $is_status; ?></td>
								      	</tr>
							<?php } } ?>
					    </tbody>
				  	</table>
				</div>
			</div>
		</div>


		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>