<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
    	$login_id=$_SESSION["login_id"];
    	$url=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	    //echo $url;
	    $myArray = explode('&status=', $url);
	    $success = $myArray[1];
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Deposite</title>
	</head>

	<body>
	<?php
	
		if($success == "success")
		{
        	echo '<script>alert("Successfully transferred payment.");</script>';
            $sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id'";//`
            $runquery = mysqli_query($con,$sql);
            $row=mysqli_fetch_assoc($runquery);
            $sponsor_id1 = $row['sponsor_id'];

            $sql14="UPDATE `tgroups_user` SET `active` = '1' WHERE `tgroups_user`.`login_id` = '$login_id'";
			$runquery14 = mysqli_query($con,$sql14); 
            

            /*--------------------------------------------------------------------------------------------------------

            ---------------------------------------------------------------------------------------------------------*/
            if($row)
            {  
                $sql2="SELECT `login_id`, `sponsor_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id1' ORDER BY `id` DESC LIMIT 1";//`
                $runquery2 = mysqli_query($con,$sql2);
                $row2=mysqli_fetch_assoc($runquery2);
                $login_id2 = $row2['login_id'];  
                $sponsor_id2 = $row2['sponsor_id'];  

				/*--------------------------------------------------------------------------------------------------------

           	 	---------------------------------------------------------------------------------------------------------*/
				$sql10="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id2'";
				$runquery10 = mysqli_query($con,$sql10); 
	            $row10=mysqli_fetch_assoc($runquery10);
                $balance_amount10 = $row10['balance_amount']; 
                $total10 = $balance_amount10 + 100;

                $sql4="UPDATE `tgroups_wallet` SET `balance_amount` = '$total10' WHERE `tgroups_wallet`.`login_id` = '$login_id2'";
				$runquery4 = mysqli_query($con,$sql4); 

				if($runquery4)
	            {

	                $sql5="SELECT `login_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id2' ORDER BY `id` DESC LIMIT 1";//`
	                $runquery5 = mysqli_query($con,$sql5);
	                $row5=mysqli_fetch_assoc($runquery5);
	                $login_id5 = $row5['login_id'];  

					/*--------------------------------------------------------------------------------------------------------

           	 		---------------------------------------------------------------------------------------------------------*/
					$sql11="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id5'";
					$runquery11 = mysqli_query($con,$sql11); 
	                $row11=mysqli_fetch_assoc($runquery11);
	                $balance_amount11 = $row11['balance_amount']; 
	                $total11 = $balance_amount11 + 100;

	                $sql6="UPDATE `tgroups_wallet` SET `balance_amount` = '$total11' WHERE `tgroups_wallet`.`login_id` = '$login_id5'";
					$runquery6 = mysqli_query($con,$sql6); 

					/*--------------------------------------------------------------------------------------------------------

           	 		---------------------------------------------------------------------------------------------------------*/

					$sql12="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = 'ADMIN'";
					$runquery12 = mysqli_query($con,$sql12); 
		            $row12=mysqli_fetch_assoc($runquery12);
	                $balance_amount12 = $row12['balance_amount']; 
	                $total12 = $balance_amount12 + 50;

	                $sql7="UPDATE `tgroups_wallet` SET `balance_amount` = '$total12' WHERE `tgroups_wallet`.`login_id` = 'ADMIN'";
					$runquery7 = mysqli_query($con,$sql7); 
					if($runquery6 && $runquery7)
		            {

		        	    $sql2="SELECT `login_id`, `sponsor_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id1' ORDER BY `id` DESC LIMIT 1";//`
					    $runquery2 = mysqli_query($con,$sql2);
					    $row2=mysqli_fetch_assoc($runquery2);
					    $login_id2 = $row2['login_id'];  
					    $sponsor_id2 = $row2['sponsor_id'];  

		                if($row2)
		                {
		                    $sql3="SELECT `user_id` FROM `tgroups_user` WHERE `login_id` = '$login_id2' ORDER BY `id` DESC LIMIT 1";//`
		                    $runquery3 = mysqli_query($con,$sql3);
		                    $row3=mysqli_fetch_assoc($runquery3);
		                    $user_id1 = $row3['user_id'];

		                    /*--------------------------------------------------------------------------------------------------------

		                    ---------------------------------------------------------------------------------------------------------*/

		                    if($row2)
		                    {  

							    $sql13="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id5'";//`
							    $runquery13 = mysqli_query($con,$sql13);
							    $row13=mysqli_fetch_assoc($runquery13);
							    
							    
		        	             if($row13['under_2_member_count'] == '4')
		        	            {  					                
								   
									$sql15="SELECT * FROM `tgroups_wallet` WHERE `login_id` = '$login_id5'";
									$runquery15 = mysqli_query($con,$sql15); 
						            $row15=mysqli_fetch_assoc($runquery15);
					                $balance_amount15 = $row15['balance_amount']; 
					                $total15 = $balance_amount15 - 250;

					                $sql115="UPDATE `tgroups_wallet` SET `balance_amount` = '$total15' WHERE `tgroups_wallet`.`login_id` = '$login_id5'";
									$runquery115 = mysqli_query($con,$sql115); 
									if($runquery115 && $runquery15)
								    {
								    	$sql16="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id5'";//`
							            $runquery16 = mysqli_query($con,$sql16);
							            $row16=mysqli_fetch_assoc($runquery16);
							            $sponsor_id16 = $row16['sponsor_id'];

								    	$sql17="SELECT `login_id`, `sponsor_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id16' ORDER BY `id` DESC LIMIT 1";//`
						                $runquery17 = mysqli_query($con,$sql17);
						                $row17=mysqli_fetch_assoc($runquery17);
						                $login_id17 = $row17['login_id'];  
						                $sponsor_id17 = $row17['sponsor_id'];  

										if($runquery16 && $runquery17)
								    	{
											/*--------------------------------------------------------------------------------------------------------

							           	 	---------------------------------------------------------------------------------------------------------*/
											$sql18="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id17'";
											$runquery18 = mysqli_query($con,$sql18); 
								            $row18=mysqli_fetch_assoc($runquery18);
							                $balance_amount18 = $row18['balance_amount']; 
							                $total18 = $balance_amount18 + 100;

							                $sql118="UPDATE `tgroups_wallet` SET `balance_amount` = '$total18' WHERE `tgroups_wallet`.`login_id` = '$login_id17'";
											$runquery118 = mysqli_query($con,$sql118); 

											if($runquery118)
								            {

								                $sql19="SELECT `login_id` FROM `tgroups_user` WHERE `user_id` = '$sponsor_id17' ORDER BY `id` DESC LIMIT 1";//`
								                $runquery19 = mysqli_query($con,$sql19);
								                $row19=mysqli_fetch_assoc($runquery19);
								                $login_id19 = $row19['login_id'];  

												/*--------------------------------------------------------------------------------------------------------

							           	 		---------------------------------------------------------------------------------------------------------*/
												$sql20="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id19'";
												$runquery20 = mysqli_query($con,$sql20); 
								                $row20=mysqli_fetch_assoc($runquery20);
								                $balance_amount20 = $row20['balance_amount']; 
								                $total20 = $balance_amount20 + 100;

								                $sql201="UPDATE `tgroups_wallet` SET `balance_amount` = '$total20' WHERE `tgroups_wallet`.`login_id` = '$login_id19'";
												$runquery201 = mysqli_query($con,$sql201); 

												/*--------------------------------------------------------------------------------------------------------

							           	 		---------------------------------------------------------------------------------------------------------*/

												$sql21="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = 'ADMIN'";
												$runquery21 = mysqli_query($con,$sql21); 
									            $row21=mysqli_fetch_assoc($runquery21);
								                $balance_amount21 = $row21['balance_amount']; 
								                $total21 = $balance_amount21 + 50;

								                $sql211="UPDATE `tgroups_wallet` SET `balance_amount` = '$total21' WHERE `tgroups_wallet`.`login_id` = 'ADMIN'";
												$runquery211 = mysqli_query($con,$sql211); 

												if($runquery20 && $runquery201)
									            {
									            	/*--------------------------------------------------------------------------------------------------------

										            ---------------------------------------------------------------------------------------------------------*/
										                
										            $myname = $row13['applicant_name'];
										            $myaccountnumber = $row13['account_number'];
										            $generate_random_3_digit_number= mt_rand(100, 999);
										            $result = substr($myname, 0, 3);
										            $result1 = mb_substr($myaccountnumber, 0, 3);
										            $final=  $result.$generate_random_3_digit_number.$result1;
										            $user_id = strtoupper($final);


						                            $fixed_id = $row13['fixed_id'];
						                            $login_id = $row13['login_id'];
						                            $sponsor_name = $row13['sponsor_name'];
						                            $sponsor_id = $row13['sponsor_id'];
						                            $applicant_name = $row13['applicant_name'];
						                            $applicant_mobile_number = $row13['applicant_mobile_number'];
						                            $applicant_email_id = $row13['applicant_email_id'];
						                            $applicant_password = $row13['applicant_password'];
						                            $bank_name = $row13['bank_name'];
						                            $branch_name = $row13['branch_name'];
						                            $account_number = $row13['account_number'];
						                            $ifsc_code = $row13['ifsc_code'];
						                            $paytm_number = $row13['paytm_number'];
						                            $phonepe_number =  $row13['phonepe_number'];
						                            $google_pay_number = $row13['google_pay_number'];
						                            $active = $row13['active'];

						        	            	$sql1="INSERT INTO `tgroups_user` 
						                            (`fixed_id`, 
						                            `login_id`, 
						                            `user_id`, 
						                            `sponsor_name`, 
						                            `sponsor_id`, 
						                            `applicant_name`, 
						                            `applicant_mobile_number`, 
						                            `applicant_email_id`, 
						                            `applicant_password`, 
						                            `bank_name`, 
						                            `branch_name`, 
						                            `account_number`, 
						                            `ifsc_code`, 
						                            `paytm_number`, 
						                            `phonepe_number`, 
						                            `google_pay_number`,
						                            `active`) 
						                            VALUES
						                            ('$fixed_id',
						                            '$login_id',
						                            '$user_id',
						                            '$sponsor_name',
						                            '$sponsor_id',
						                            '$applicant_name',
						                            '$applicant_mobile_number',
						                            '$applicant_email_id',
						                            '$applicant_password',
						                            '$bank_name',
						                            '$branch_name',
						                            '$account_number',
						                            '$ifsc_code',
						                            '$paytm_number',
						                            '$phonepe_number',
						                            '$google_pay_number',
						                        	'$active') ";
						                              
						                            $runquery1 = mysqli_query($con,$sql1); 
						                        } 
						                        else
						                        {
						                            header("location: profile.php");
						                                //echo "<script>alert('Re-Entry successfully generated.');</script>";
						                        }
						                    }
					                    }           
				                    }      
		        	            }
		        	        }
		        	    }
		        	}
        	    }
        	header("location: profile.php");
        	}
        }
	?>
	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>