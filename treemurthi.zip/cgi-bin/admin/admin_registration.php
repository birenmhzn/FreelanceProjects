<?php
    include('../sqlserverfiles/Config.php');
    session_start();
    if(isset($_POST['admin_registration']))
    {    
        $admin_name = $_POST['admin_name'];
        $admin_password = $_POST['admin_password'];

        $passwordhash = null;

        /*--------------------------------------------------------------------------------------------------------

        ---------------------------------------------------------------------------------------------------------*/
                
        $admin_name = $admin_name;
        $admin_password = $admin_password;
        $generate_random_3_digit_number= mt_rand(100, 999);
        $result = substr($admin_name, 0, 3);
        $result1 = mb_substr($admin_password, 0, 3);
        $final=  $result.$generate_random_3_digit_number.$result1;
        $admin_login_id = strtoupper($final);

		/*--------------------------------------------------------------------------------------------------------

        ---------------------------------------------------------------------------------------------------------*/

        if (CRYPT_BLOWFISH == 1)
        {
            $adminpasswordhash = crypt($admin_password ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
        }
        else
        {   
            echo '<script>alert("Blowfish DES not supported.");
                window.location="admin_registration.php";</script>';
        }

        $sql="INSERT INTO `tgroups_admin`(`admin_login_id`, `admin_name`, `admin_password`) VALUES ('$admin_login_id', '$admin_name', '$adminpasswordhash')";//`
        $runquery = mysqli_query($con,$sql);
        if ($runquery) {
        	header("location: show_login_id.php?".$admin_login_id);
            echo "<script>alert('User successfully registered.');</script>";
        }
    }
    if(isset($_SESSION["admin_login_id"])) 
    {
        header("Location:index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Admin Registration</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="../css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Admin Registration</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="signupform">
			<div class="container">
				<!-- main content -->
				<div class="main-content">
					<div class="contect_left_form">
						<div class="left_grid_info">
							<h1>Register Your Admin Account</h1>
							<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
							<img src="images/image.jpg" alt="" />
						</div>
					</div>
					<div class="login_info">
						<h2>Admin Registration</h2>
						<p>Enter your details for registration.</p>
						<form action="#" method="post">
							<label>Admin Name</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" placeholder="Enter Your Name" name="admin_name" required> 
							</div>
							<label>Password</label>
							<div class="input-group">
								<span class="fa fa-lock" aria-hidden="true"></span>
								<input type="Password" placeholder="Enter Password" name="admin_password" required>
							</div> 						
							<input class="btn btn-danger btn-block" type="submit" value="Admin Registration" name="admin_registration" /> 
              			</form>
					</div>
				</div>
				<!-- //main content -->
			</div>
		</div>
		
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "../footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>