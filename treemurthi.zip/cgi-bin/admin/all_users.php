<?php
    include('../sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["admin_login_id"]) {

	    if(isset($_POST['active_user_btn']))
	    {
	        $active_user = $_POST["active_user"];
	        $active_user_login_id = $_POST["active_user_login_id"];
			$sql1="UPDATE `tgroups_user` SET `active` = '1' WHERE `tgroups_user`.`login_id` = '$active_user_login_id'";//`
			$runquery1 = mysqli_query($con,$sql1);
	    }
	        
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>All Users</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">All Users</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="fluid-container">
			<div class="container">
				<center><b><h3>All Users Details</h3></b></center><br>
				<div class="table-responsive">
					<table class="table table-bordered">
					    <thead>
					      	<tr>
					        	<th>Login ID</th>
					        	<th>User ID</th>
					        	<th>Password</th>
					        	<th>Sponsor Name</th>
					        	<th>Sponsor ID</th>
					        	<th>Applicant Name</th>
					        	<th>Applicant Mobile Number</th>
					        	<th>Balance</th>
					        	<th>active</th>
					        	<th>Account Create Date Time</th>
					      	</tr>
					    </thead>
					    <tbody>
					      	<?php
								$sql="SELECT * FROM `tgroups_user`";//`
							    $runquery = mysqli_query($con,$sql);
					    		if($runquery)
                            	{     
                                	while($row=mysqli_fetch_assoc($runquery)) 
                                	{
                                	    $login_id1 = $row['login_id'];
                                	    $sql1="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `login_id` = '$login_id1'";
							            $runquery1 = mysqli_query($con,$sql1);
							            $row1=mysqli_fetch_assoc($runquery1);
					    	?>
								      	<tr style="font-weight: normal;">
								        	<td><?php echo $row['login_id']; ?></td>
								        	<td><?php echo $row['user_id']; ?></td>
								        	<td><?php echo $row['decoded']; ?></td>
								        	<td><?php echo $row['sponsor_name']; ?></td>
								        	<td><?php echo $row['sponsor_id']; ?></td>
								        	<td><?php echo $row['applicant_name']; ?></td>
								        	<td><?php echo $row['applicant_mobile_number']; ?></td>
								        	<td><?php echo $row1['balance_amount']; ?></td>
								        	<td><?php echo $row['active']; ?></td>
								        	<!--<form action="#" method="post">
								        		<input class="form-control" type="hidden" name="active_user_login_id" value="<?php echo $row['login_id']; ?>">
									        	<input class="form-control" type="hidden" name="active_user" value="1">
									        	<td><input class="btn btn-success btn-block" type="submit" value="Active" name="active_user_btn" /> </td>
								        	</form>	-->	
								        	<td><?php echo $row['account_creation_date']; ?></td>
								        </tr>
							<?php } } ?>
					    </tbody>
					</table>
				</div>
			</div>
		</div>

		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "../footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'index.php';
            </script>";
    }
?>