<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
<?php
    include('../sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["admin_login_id"]) 
    {
		if(isset($_POST['add_money_user_btn']))
	    {
	    	$current_user_add_money = $_POST["add_money"];
	        $fixed_id = $_POST["add_money_user_login_id"];
	    	$upper_sponsor_fixed_id = $main_sponsor_fixed_id = $upper_sponsor_payment_from_member = $main_sponsor_payment_from_member = $runquery18 =  null;

	        


                /*--------------------------------------------------------------------------------------------------------


                                                                Get all fixed id


                ---------------------------------------------------------------------------------------------------------*/





	            /*------------------------        Upper sponsor fixed id         --------------------------------------------*/


				$sql = "SELECT `sponsor_fixed_id` FROM `tgroups_my_and_sponsor_fixed_id` WHERE `fixed_id` = '$fixed_id'";
	            $runquery = mysqli_query($con,$sql);
	            $row = mysqli_fetch_assoc($runquery);

	            $upper_sponsor_fixed_id = $row['sponsor_fixed_id'];

	            /*--------------------------------------------------------------------------------------------------------

	            ---------------------------------------------------------------------------------------------------------*/
	            if($row)
	            {  

		            $sql0 = "UPDATE `tgroups_user` SET `active` = '1' WHERE `tgroups_user`.`fixed_id` = '$fixed_id'";
					$runquery0 = mysqli_query($con,$sql0); 

		            if ($runquery)
		            {

			            /*------------------------        Main sponsor fixed id         --------------------------------------------*/

			            $sql1 = "SELECT `sponsor_fixed_id` FROM `tgroups_my_and_sponsor_fixed_id` WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
			            $runquery1 = mysqli_query($con,$sql1);
			            $row1 = mysqli_fetch_assoc($runquery1);

			            $main_sponsor_fixed_id = $row1['sponsor_fixed_id'];

			            if ($runquery1)
		            	{



			                /*--------------------------------------------------------------------------------------------------------


			                                                   Insert amount into upper sponsor wallet


			                ---------------------------------------------------------------------------------------------------------*/






			                $sql2 = "SELECT `payment_from_member` FROM `tgroups_joining_id` WHERE `fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
				            $runquery2 = mysqli_query($con,$sql2);
				            $row2 = mysqli_fetch_assoc($runquery2);

				            $upper_sponsor_payment_from_member = $row2['payment_from_member'];

				            if ($runquery2)
		            		{



		            			if ($upper_sponsor_payment_from_member == 0 || $upper_sponsor_payment_from_member == 1) 
		            			{


		            				$sql3 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
									$runquery3 = mysqli_query($con,$sql3); 

									if ($runquery3) 
									{
										
										if ($upper_sponsor_payment_from_member == 0) 
		            					{

		            						$sql4 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 1 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
											$runquery4 = mysqli_query($con,$sql4);

		            					}
		            					else if ($upper_sponsor_payment_from_member == 1) 
		            					{

		            						$sql4 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 2 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
											$runquery4 = mysqli_query($con,$sql4);

		            					}

									}

		            			}


		            			else if ($upper_sponsor_payment_from_member == 2) 
		            			{


		            				$sql5 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
									$runquery5 = mysqli_query($con,$sql5); 

									if ($runquery5) 
									{

										$sql6 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
										$runquery6 = mysqli_query($con,$sql6); 

										if ($runquery6) 
										{

		            						$sql7 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 3 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
											$runquery7 = mysqli_query($con,$sql7);

										}

									}

		            			}

		            			else if ($upper_sponsor_payment_from_member > 2) 
		            			{


		            				$sql8 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
									$runquery8 = mysqli_query($con,$sql8); 

									if ($runquery8) 
									{

										$sql9 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = `payment_from_member` + 1 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
										$runquery9 = mysqli_query($con,$sql9);

									}

		            			}

		            		}





		            		/*--------------------------------------------------------------------------------------------------------


			                                                   Insert amount into main sponsor wallet


			                ---------------------------------------------------------------------------------------------------------*/





			                if ($runquery2)
			            	{

				                $sql10 = "SELECT `payment_from_member` FROM `tgroups_joining_id` WHERE `fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
					            $runquery10 = mysqli_query($con,$sql10);
					            $row10 = mysqli_fetch_assoc($runquery10);

					            $main_sponsor_payment_from_member = $row10['payment_from_member'];

					            if ($runquery10)
			            		{



			            			if ($main_sponsor_payment_from_member == 0 || $main_sponsor_payment_from_member == 1) 
			            			{


			            				$sql11 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
										$runquery11 = mysqli_query($con,$sql11); 

										if ($runquery11) 
										{
											
											if ($main_sponsor_payment_from_member == 0) 
			            					{

			            						$sql12 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 1 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
												$runquery12 = mysqli_query($con,$sql12);

			            					}
			            					else if ($main_sponsor_payment_from_member == 1) 
			            					{

			            						$sql12 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 2 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
												$runquery12 = mysqli_query($con,$sql12);

			            					}

										}

			            			}


			            			else if ($main_sponsor_payment_from_member == 2) 
			            			{


			            				$sql13 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
										$runquery13 = mysqli_query($con,$sql13); 

										if ($runquery13) 
										{

											$sql14 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
											$runquery14 = mysqli_query($con,$sql14); 

											if ($runquery14) 
											{

			            						$sql15 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 3 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
												$runquery15 = mysqli_query($con,$sql15);

											}

										}

			            			}

			            			else if ($main_sponsor_payment_from_member > 2) 
			            			{


			            				$sql16 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
										$runquery16 = mysqli_query($con,$sql16); 

										if ($runquery16) 
										{

											$sql17 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = `payment_from_member` + 1 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
											$runquery17 = mysqli_query($con,$sql17);

										}

			            			}

			            		}
			            	}




			            	/*--------------------------------------------------------------------------------------------------------


			                                                   Insert amount into admin wallet


			                ---------------------------------------------------------------------------------------------------------*/




			                if ($runquery2)
			            	{

			            		$sql18 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = 'ADMIN'";
								$runquery18 = mysqli_query($con,$sql18); 

			            	}




			            	/*--------------------------------------------------------------------------------------------------------


			                                                   Re-entry process


			                ---------------------------------------------------------------------------------------------------------*/



			                if ($runquery18)
			            	{

			            		$sql19 = "SELECT `payment_from_member` FROM `tgroups_joining_id` WHERE `fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
					            $runquery19 = mysqli_query($con,$sql19);
					            $row19 = mysqli_fetch_assoc($runquery19);

					            $main_sponsor_payment_from_member = $row19['payment_from_member'];




		            			/*------------------------        Check that all users paid the fees or not         --------------------------------------------*/



					            if ($main_sponsor_payment_from_member == 6 && $runquery19) 
					            {




						            /*--------------------------------------------------------------------------------------------------------


						                                        Repeated process in this if for ---- RE-ENTRY


						            ---------------------------------------------------------------------------------------------------------*/


									if ($runquery19) 
									{
										



						                /*--------------------------------------------------------------------------------------------------------


						                                                                Get all fixed id for ---- RE-ENTRY


						                ---------------------------------------------------------------------------------------------------------*/





							            /*------------------------        Upper sponsor fixed id    for ---- RE-ENTRY     --------------------------------------------*/


										$sql = "SELECT `sponsor_fixed_id` FROM `tgroups_my_and_sponsor_fixed_id` WHERE `fixed_id` = '$main_sponsor_fixed_id'";
							            $runquery = mysqli_query($con,$sql);
							            $row = mysqli_fetch_assoc($runquery);

							            $upper_sponsor_fixed_id = $row['sponsor_fixed_id'];

							            if ($runquery)
							            {

								            /*------------------------        Main sponsor fixed id    for ---- RE-ENTRY     --------------------------------------------*/

								            $sql1 = "SELECT `sponsor_fixed_id` FROM `tgroups_my_and_sponsor_fixed_id` WHERE `fixed_id` = '$upper_sponsor_fixed_id'";
								            $runquery1 = mysqli_query($con,$sql1);
								            $row1 = mysqli_fetch_assoc($runquery1);

								            $main_sponsor_fixed_id = $row1['sponsor_fixed_id'];

								            if ($runquery1)
							            	{





								                /*--------------------------------------------------------------------------------------------------------


								                                                   Insert amount into upper sponsor wallet   for ---- RE-ENTRY


								                ---------------------------------------------------------------------------------------------------------*/






								                $sql2 = "SELECT `payment_from_member` FROM `tgroups_joining_id` WHERE `fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
									            $runquery2 = mysqli_query($con,$sql2);
									            $row2 = mysqli_fetch_assoc($runquery2);

									            $upper_sponsor_payment_from_member = $row2['payment_from_member'];

									            if ($runquery2)
							            		{



							            			if ($upper_sponsor_payment_from_member == 0 || $upper_sponsor_payment_from_member == 1) 
							            			{


							            				$sql3 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
														$runquery3 = mysqli_query($con,$sql3); 

														if ($runquery3) 
														{
															
															if ($upper_sponsor_payment_from_member == 0) 
							            					{

							            						$sql4 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 1 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																$runquery4 = mysqli_query($con,$sql4);

							            					}
							            					else if ($upper_sponsor_payment_from_member == 1) 
							            					{

							            						$sql4 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 2 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																$runquery4 = mysqli_query($con,$sql4);

							            					}

														}

							            			}


							            			else if ($upper_sponsor_payment_from_member == 2) 
							            			{


							            				$sql5 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
														$runquery5 = mysqli_query($con,$sql5); 

														if ($runquery5) 
														{

															$sql6 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
															$runquery6 = mysqli_query($con,$sql6); 

															if ($runquery6) 
															{

							            						$sql7 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 3 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																$runquery7 = mysqli_query($con,$sql7);

															}

														}

							            			}

							            			else if ($upper_sponsor_payment_from_member > 2) 
							            			{


							            				$sql8 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$upper_sponsor_fixed_id'";
														$runquery8 = mysqli_query($con,$sql8); 

														if ($runquery8) 
														{

															$sql9 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = `payment_from_member` + 1 WHERE `tgroups_joining_id`.`fixed_id` = '$upper_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
															$runquery9 = mysqli_query($con,$sql9);

														}

							            			}

							            		}





							            		/*--------------------------------------------------------------------------------------------------------


								                                                   Insert amount into main sponsor wallet    for ---- RE-ENTRY


								                ---------------------------------------------------------------------------------------------------------*/





								                if ($runquery2)
								            	{

									                $sql10 = "SELECT `payment_from_member` FROM `tgroups_joining_id` WHERE `fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
										            $runquery10 = mysqli_query($con,$sql10);
										            $row10 = mysqli_fetch_assoc($runquery10);

										            $main_sponsor_payment_from_member = $row10['payment_from_member'];

										            if ($runquery10)
								            		{



								            			if ($main_sponsor_payment_from_member == 0 || $main_sponsor_payment_from_member == 1) 
								            			{


								            				$sql11 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
															$runquery11 = mysqli_query($con,$sql11); 

															if ($runquery11) 
															{
																
																if ($main_sponsor_payment_from_member == 0) 
								            					{

								            						$sql12 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 1 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																	$runquery12 = mysqli_query($con,$sql12);

								            					}
								            					else if ($main_sponsor_payment_from_member == 1) 
								            					{

								            						$sql12 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 2 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																	$runquery12 = mysqli_query($con,$sql12);

								            					}

															}

								            			}


								            			else if ($main_sponsor_payment_from_member == 2) 
								            			{


								            				$sql13 = "UPDATE `tgroups_wallet` SET `fixed_deposite` = `fixed_deposite` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
															$runquery13 = mysqli_query($con,$sql13); 

															if ($runquery13) 
															{

																$sql14 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
																$runquery14 = mysqli_query($con,$sql14); 

																if ($runquery14) 
																{

								            						$sql15 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = 3 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																	$runquery15 = mysqli_query($con,$sql15);

																}

															}

								            			}

								            			else if ($main_sponsor_payment_from_member > 2) 
								            			{


								            				$sql16 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 100 WHERE `tgroups_wallet`.`fixed_id` = '$main_sponsor_fixed_id'";
															$runquery16 = mysqli_query($con,$sql16); 

															if ($runquery16) 
															{

																$sql17 = "UPDATE `tgroups_joining_id` SET `payment_from_member` = `payment_from_member` + 1 WHERE `tgroups_joining_id`.`fixed_id` = '$main_sponsor_fixed_id' ORDER BY `id` DESC LIMIT 1";
																$runquery17 = mysqli_query($con,$sql17);

															}

								            			}

								            		}
								            	}




								            	/*--------------------------------------------------------------------------------------------------------


								                                                   Insert amount into admin wallet  for ---- RE-ENTRY


								                ---------------------------------------------------------------------------------------------------------*/




								                if ($runquery2)
								            	{

								            		$sql18 = "UPDATE `tgroups_wallet` SET `balance_amount` = `balance_amount` + 50 WHERE `tgroups_wallet`.`fixed_id` = 'ADMIN'";
													$runquery18 = mysqli_query($con,$sql18); 

								            	}

								            }
								        }



						                /*--------------------------------------------------------------------------------------------------------


						                                Add main sponsor fixed id into re-entry and joining id table for ---- RE-ENTRY


						                ---------------------------------------------------------------------------------------------------------*/



						                if ($runquery) 
						                {

						                	$sql20 = "SELECT `applicant_name` , `adhar_number` FROM `tgroups_user` WHERE `fixed_id` = '$main_sponsor_fixed_id'";
											$runquery20 = mysqli_query($con,$sql20); 

						                	$myname = $row20['applicant_name'];
											$myaccountnumber = $row20['adhar_number'];

											$generate_random_3_digit_number= mt_rand(100, 999);
											$result = substr($myname, 0, 3);
											$result1 = mb_substr($myaccountnumber, 0, 3);
											$final=  $result.$generate_random_3_digit_number.$result1;
											$joining_id = strtoupper($final);


						                	
											if ($runquery20) 
											{

							                	$sql21 = "INSERT INTO `tgroups_re_entry` 
			                                            (
			                                                `fixed_id`,
			                                                `new_joining_id`,
			                                                `status`
			                                            ) 
			                                            VALUES
			                                            (
			                                                '$main_sponsor_fixed_id',
			                                                '$joining_id',
			                                                '1'
			                                            )";
		                                    	$runquery21 = mysqli_query($con,$sql21);



		                                    	if ($runquery21) 
												{

													$sql22 = "INSERT INTO `tgroups_joining_id` 
				                                            (
				                                                `fixed_id`,
				                                                `joining_id`
				                                            ) 
				                                            VALUES
				                                            (
				                                                '$main_sponsor_fixed_id',
				                                                '$joining_id'
				                                            )";
		                                    		$runquery22 = mysqli_query($con,$sql22);

												}

		                                    }

						                }

									}

					            }

					            echo '<script>alert("Payment successfuly deposited.");
		        	    			window.location("add_money.php</script>';
			            	}
			        }
		    	}
	        }
	        else
	        {
	        	echo '<script>alert("Failed payment transferred.");
	        	    window.location("add_money.php</script>';
	        }
	    }
	        
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Add Money</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Add Money</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Add money or Active User</h3></b></center><br>
				<div class="table-responsive">
					<table class="table table-bordered">
					    <thead>
					      	<tr>
					        	<th>Login ID</th>
					        	<th>Joining ID</th>
					        	<th>Sponsor Name</th>
					        	<th>Sponsor ID</th>
					        	<th>Applicant Name</th>
					        	<th>Applicant Mobile Number</th>
					        	<th>Add Money</th>
					        	<th>Account Create Date Time</th>
					        	<th></th>
					      	</tr>
					    </thead>
					    <tbody>
					      	<?php
								$sql="SELECT * FROM `tgroups_user` WHERE `active` = '0'";//`
							    $runquery = mysqli_query($con,$sql);
					    		if($runquery)
                            	{     
                                	while($row=mysqli_fetch_assoc($runquery)) 
                                	{
					    	?>
								      	<tr style="font-weight: normal;">
								        	<td><?php echo $row['login_id']; ?></td>
								        	<td><?php echo $row['joining_id']; ?></td>
								        	<td><?php echo $row['sponsor_name']; ?></td>
								        	<td><?php echo $row['sponsor_id']; ?></td>
								        	<td><?php echo $row['applicant_name']; ?></td>
								        	<td><?php echo $row['applicant_mobile_number']; ?></td>
								        	<form action="#" method="post">
								        		<input class="form-control" type="hidden" name="add_money_user_login_id" value="<?php echo $row['login_id']; ?>">
									        	<td><input class="form-control" type="number" name="add_money" value="250" readonly required></td>
									        	<td><?php echo $row['account_creation_date']; ?></td>
									        	<td><input class="btn btn-success btn-block" type="submit" value="Add Money" name="add_money_user_btn" /> </td>
								        	</form>								      	
								        </tr>
							<?php } } ?>
					    </tbody>
					</table>
				</div>
			</div>
		</div>

		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "../footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'index.php';
            </script>";
    }
?>