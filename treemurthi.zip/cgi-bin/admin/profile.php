<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
<?php
    include('../sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["admin_login_id"]) {
        if(isset($_POST['withdraw_approved_btn']))
	    {
	        $fixed_id = $_POST["fixed_id"];
	        $withdraw_id = $_POST["withdraw_id"];
	        $action = $_POST["action"];
	        
    	   if($action == "Approved") 
    	   {
    			$sql1="UPDATE `tgroups_withdraw_request` SET `is_status` = 'Approved' WHERE `tgroups_withdraw_request`.`id` = '$withdraw_id'";
                $runquery1 = mysqli_query($con,$sql1);
                if($runquery1)
                {
        		    echo '<script>alert("Successfull approved");
                    window.location="profile.php?1";</script>';
    		    }
    	   }
    	   else if($action == "Cancel")
    	   {
    	        $sql4="SELECT `withdraw_amount` FROM `tgroups_withdraw_request` WHERE `tgroups_withdraw_request`.`id` = '$withdraw_id'";
                $runquery4 = mysqli_query($con,$sql4);
                $row4=mysqli_fetch_assoc($runquery4);
                
                if($runquery4)
                {
        	        $sql5="SELECT `balance_amount` FROM `tgroups_wallet` WHERE `tgroups_wallet`.`login_id` = '$fixed_id'";
                    $runquery5 = mysqli_query($con,$sql5);
                    $row5=mysqli_fetch_assoc($runquery5);
                    
                    $total = $row4['withdraw_amount'] + $row5['balance_amount'];
                    if($runquery5)
                    {
            	        $sql3="UPDATE `tgroups_wallet` SET `balance_amount` = '$total' WHERE `tgroups_wallet`.`login_id` = '$fixed_id'";
                        $runquery3 = mysqli_query($con,$sql3);
                        
                        $sql2="UPDATE `tgroups_withdraw_request` SET `is_status` = 'Cancel' WHERE `tgroups_withdraw_request`.`id` = '$withdraw_id'";
                        $runquery2 = mysqli_query($con,$sql2);
                        if($runquery2 && $runquery3)
                       {
                		    echo '<script>alert("Successfull cancel");
                           window.location="profile.php?1";</script>';
            		   }
                    }
                }
    	   }
		}
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Admin Dashboard</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Admin Dashboard</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<?php
			$sql="SELECT tgroups_withdraw_request.`withdraw_amount`, tgroups_withdraw_request.`joining_id`, tgroups_withdraw_request.`datetime`, tgroups_user.`applicant_name`, tgroups_user.`fixed_id` FROM tgroups_withdraw_request INNER JOIN tgroups_user ON tgroups_withdraw_request.`joining_id`=tgroups_user.`joining_id` WHERE tgroups_withdraw_request.`is_status` = 'Pending'";
		    $runquery = mysqli_query($con,$sql);
		    
		?>
		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Users Withdraw Request</h3></b></center><br>
				<div class="table-responsive">
					<?php
						if ($runquery) 
						{
							$row=mysqli_fetch_assoc($runquery);
					?>
						<table class="table table-bordered">
						    <thead>
						      	<tr>
						        	<th>Login ID</th>
						        	<th>Joining ID</th>
						        	<th>Applicant Name</th>
						        	<th>Withdraw Amount</th>
						        	<th>Date Time</th>
						        	<th>Applicant Mobile Number</th>
						        	<th>Bank Name</th>
						        	<th>Branch Name</th>
						        	<th>Account Number</th>
						        	<th>IFSC Code</th>
						        	<th>Paytm Number</th>
						        	<th>PhonePe Number</th>
						        	<th>Google Pay Number</th>
						        	<th></th>
						        	<th></th>
						      	</tr>
						    </thead>
						    <tbody>
						      	<?php
									$sql="SELECT tgroups_withdraw_request.`id`, 
									tgroups_withdraw_request.`withdraw_amount`, 
									tgroups_withdraw_request.`fixed_id`, 
									tgroups_withdraw_request.`joining_id`, 
									tgroups_withdraw_request.`datetime`, 
									tgroups_user.`applicant_name`, 
									tgroups_user.`applicant_mobile_number`, 
									tgroups_user.`bank_name`, 
									tgroups_user.`branch_name`, 
									tgroups_user.`account_number`, 
									tgroups_user.`ifsc_code`, 
									tgroups_user.`paytm_number`, 
									tgroups_user.`phonepe_number`, 
									tgroups_user.`google_pay_number`, 
									tgroups_user.`fixed_id` FROM tgroups_withdraw_request INNER JOIN tgroups_user ON tgroups_withdraw_request.`joining_id`=tgroups_user.`joining_id` WHERE tgroups_withdraw_request.`is_status` = 'PENDING'";
								    $runquery = mysqli_query($con,$sql);
						    		if($runquery)
	                            	{     
	                                	while($row=mysqli_fetch_assoc($runquery)) 
	                                	{
						    	?>
									      	<tr style="font-weight: normal;">
									        	<td><?php echo $row['fixed_id']; ?></td>
									        	<td><?php echo $row['joining_id']; ?></td>
									        	<td><?php echo $row['applicant_name']; ?></td>
									        	<td><?php echo $row['withdraw_amount']; ?></td>
									        	<td><?php echo $row['datetime']; ?></td>
									        	<td><?php echo $row['applicant_mobile_number']; ?></td>
									        	<td><?php echo $row['bank_name']; ?></td>
									        	<td><?php echo $row['branch_name']; ?></td>
									        	<td><?php echo $row['account_number']; ?></td>
									        	<td><?php echo $row['ifsc_code']; ?></td>
									        	<td><?php echo $row['paytm_number']; ?></td>
									        	<td><?php echo $row['phonepe_number']; ?></td>
									        	<td><?php echo $row['google_pay_number']; ?></td>
									        	<form method="post" action="#"> 
	    								        	<input type="hidden" value="<?php echo $row['id']; ?>" name="withdraw_id" required>
	    								        	<input type="hidden" value="<?php echo $row['fixed_id']; ?>" name="fixed_id" required>
	    								        	<td><select name="action" class="btn">
	    								        	    <option value="Approved">Approved</option>
	    								        	    <option value="Cancel">Cancel</option>
	    								        	</select></td>
	    								        	<td><input class="btn btn-success btn-block" type="submit" value="Submit" name="withdraw_approved_btn" /> </td>
									      	    </form>
									      	</tr>
								<?php } } ?>
						    </tbody>
						</table>
					<?php } ?>
				</div>
			</div>
		</div>

		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "../footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'index.php';
            </script>";
    }
?>