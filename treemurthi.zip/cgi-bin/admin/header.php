<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<script>
			addEventListener("load", function () {
				setTimeout(hideURLbar, 0);
			}, false);

			function hideURLbar() {
				window.scrollTo(0, 1);
			}
		</script>
		<!-- //Meta tag Keywords -->

		<!-- Custom-Files -->
		<link rel="stylesheet" href="../css/bootstrap.css">
		<!-- Bootstrap-Core-CSS -->
		<link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
		<!-- Style-CSS -->

		<!-- css files -->
		<link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
		<!-- google fonts -->
		<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- //google fonts -->


		<!-- Web-Fonts -->
		<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext"
		 rel="stylesheet">
		<!-- //Web-Fonts -->
	</head>
	<body>
				<div class="container-fluid">
					<div class="header d-lg-flex justify-content-between align-items-center py-3 px-sm-3">
						<!-- logo -->
						<div id="logo">
							<h1><a href="index.php"><span class="fa fa-linode mr-2"></span>Trimurthi Groups</a></h1>
						</div>
						<!-- //logo -->
						<!-- nav -->
						<div class="nav_temps-amkls">
							<?php
					            if(isset($_SESSION["admin_login_id"])) 
					            {
					                $admin_name = $_SESSION["admin_name"];
					                $admin_login_id = $_SESSION["admin_login_id"]; 
					        ?>
					        		<nav>
										<label for="drop" class="toggle">Menu</label>
										<input type="checkbox" id="drop" />
										<ul class="menu">
											<li><a href="index.php" class="active">Home</a></li>
											<li>
												<label for="drop-2" class="toggle toogle-2">Users <span class="fa fa-angle-down" aria-hidden="true"></span>
												</label>
												<a href="#">Users <span class="fa fa-angle-down" aria-hidden="true"></span></a>
												<input type="checkbox" id="drop-2" />
												<ul>
													<li><a href="active_users.php" class="drop-text">Active</a></li>
													<li><a href="block_users.php" class="drop-text">Block</a></li>
												</ul>
											</li>
											<li><a href="add_money.php">Add Money</a></li>
											<li><a href="all_users.php">All Users</a></li>
											<li><a href="logout.php">Logout</a></li>
										</ul>
									</nav>
					        <?php
					        	}
							    else 
							    {
							?>
									<nav>
										<label for="drop" class="toggle">Menu</label>
										<input type="checkbox" id="drop" />
										<ul class="menu">
											<li><a href="index.php">Home</a></li>
											<li><a href="index.php">Login</a></li>
											<li><a href="admin_registration.php">Admin Registration</a></li>
											<li><a href="../index.php">Go to actual website</a></li>
										</ul>
									</nav>
							<?php
							    }
							?>
						</div>
					</div>
				</div>
	</body>
</html>