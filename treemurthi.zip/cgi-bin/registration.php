<?php
    include('sqlserverfiles/Config.php');
    session_start();
    
    if(isset($_SESSION["login_id"])) 
    {
        header("Location:profile.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Registration</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Registration</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="fluid-container">
			<div class="container">
				<form method="post" action="sqlserverfiles/sql_registration.php">
					<div class="row">
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Enter your sponsor details.</b></p></h3><br>
							<label>Sponsor Name</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" name="sponsor_name" placeholder="Enter Sponsor Name" required> 
							</div>
							<label>Sponsor ID</label>
							<div class="input-group">
								<span class="fa fa-lock" aria-hidden="true"></span>
								<input type="text" name="sponsor_id" maxlength="9" placeholder="Enter Sponsor ID" required>
							</div><br>

							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Enter your details.</b></p></h3><br>
							<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
							<label>Applicant Name</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" name="applicant_name" id="applicant_name" placeholder="Enter Your Name" required> 
                                <script>
                                    $("#applicant_name").on("keypress", function(evt) {
                                        var keycode = evt.charCode || evt.keyCode;
                                        if (keycode == 46) {
                                            return false;
                                        }
                                    });
                                </script>
							</div>
							<label>Applicant Mobile Number</label>
							<div class="input-group">
								<span class="fa fa-mobile" aria-hidden="true"></span>
								<input type="Number" name="applicant_mobile_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Mobile Number" required>
							</div>
							<label>Applicant Email ID</label>
							<div class="input-group">
								<span class="fa fa-envelope" aria-hidden="true"></span>
								<input type="email" name="applicant_email_id" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Enter Your Email ID" required>
							</div>	
							<label>Applicant Password</label>
							<div class="input-group">
								<span class="fa fa-lock" aria-hidden="true"></span>
								<input type="Password" name="applicant_password" placeholder="Enter Your Password" required>
							</div>	
						</div>
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Enter your bank details.</b></p></h3><br>
							<label>Bank Name</label>
							<div class="input-group">
								<span class="fa fa-university" aria-hidden="true"></span>
								<input type="text" name="bank_name" placeholder="Enter Bank Name"> 
							</div>
							<label>Branch Name</label>
							<div class="input-group">
								<span class="fa fa-map-marker" aria-hidden="true"></span>
								<input type="text" name="branch_name" placeholder="Enter Branch Name">
							</div>	
							<label>Account Number</label>
							<div class="input-group">
								<span class="fa fa-user-circle" aria-hidden="true"></span>
								<input type="number" name="account_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "16" placeholder="Enter Account Number">
							</div>	
							<label>IFSC Code</label>
							<div class="input-group">
								<span class="fa fa-codepen" aria-hidden="true"></span>
								<input type="text" name="ifsc_code" maxlength = "11" placeholder="Enter IFSC Code">
							</div>	<br>
						</div>
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Enter your online wallet details.</b></p></h3><br>
							<label>Paytm Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="number" name="paytm_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Paytm Number"> 
							</div>
							<label>PhonePe Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="number" name="phonepe_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your PhonePe Number">
							</div>	
							<label>Google Pay Number</label>
							<div class="input-group">
								<span class="fa fa-google" aria-hidden="true"></span>
								<input type="number" name="google_pay_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Google Pay Number">
							</div>	<br>
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Enter your pancard and adhar card details.</b></p></h3><br>
							<label>Pancard Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="text" name="pancard_number" maxlength = "10" placeholder="Enter Your Pancard Number"> 
							</div>
							<label>Adhar Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="number" name="adhar_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "12" placeholder="Enter Your Adhar Number" required> 
							</div>
							<!-- <button class="btn btn-danger btn-block" type="submit">Login</button > -->                
							<p class="account">By clicking Submit, you agree to our <a href="#">Terms & Conditions!</a></p><br>
							<input class="btn btn-danger btn-block" type="submit" value="Register" name="register" /> 
						</div>
					</div>
				</form>
			</div>
		</div><br>
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>