<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
    	$login_id = $_SESSION["login_id"];
    	if(isset($_POST['update_user']))
	    {
	        $applicant_password = $_POST["applicant_password"];
	    	/*--------------------------------------------------------------------------------------------------------

            ---------------------------------------------------------------------------------------------------------*/

            if (CRYPT_BLOWFISH == 1)
            {
                $passwordhash = crypt($applicant_password ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
            }
            else
            {   
                echo '<script>alert("Blowfish DES not supported.");
                window.location="profile.php";</script>';
            }
	        $applicant_name = $_POST["applicant_name"];
	        $applicant_mobile_number = $_POST["applicant_mobile_number"];
	        $applicant_email_id = $_POST["applicant_email_id"];
	        $bank_name = $_POST["bank_name"];
	        $branch_name = $_POST["branch_name"];
	        $account_number = $_POST["account_number"];
	        $ifsc_code = $_POST["ifsc_code"];
	        $paytm_number = $_POST["paytm_number"];
	        $phonepe_number = $_POST["phonepe_number"];
	        $google_pay_number = $_POST["google_pay_number"];

			$sql1="UPDATE `tgroups_user` SET 
			`decoded` = '$applicant_password',
			`applicant_name` = '$applicant_name', 
			`applicant_mobile_number` = '$applicant_mobile_number', 
			`applicant_email_id` = '$applicant_email_id', 
			`applicant_password` = '$passwordhash', 
			`bank_name` = '$bank_name', 
			`branch_name` = '$branch_name', 
			`account_number` = '$account_number', 
			`ifsc_code` = '$ifsc_code', 
			`paytm_number` = '$paytm_number', 
			`phonepe_number` = '$phonepe_number', 
			`google_pay_number` = '$google_pay_number'
			WHERE `tgroups_user`.`login_id` = '$login_id'";//`
			$runquery1 = mysqli_query($con,$sql1);
		}
?>
<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>Profile</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Startup Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
	</head>

	<body>
		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.html" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Profile</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<?php
			$sql="SELECT * FROM `tgroups_user` WHERE `login_id` = '$login_id'";//`
		    $runquery = mysqli_query($con,$sql);
		    $row=mysqli_fetch_assoc($runquery);
		?>
		<div class="fluid-container">
			<div class="container">
				<center><b><h3>Your details</h3></b></center><br>
				<form method="post" action="#"><!-- sqlserverfiles/sql_updateprofile.php-->
					<div class="row">
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Do Not Update your sponsor details.</b></p></h3><br>
							<label>Sponsor Name</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" name="sponsor_name" placeholder="Enter Sponsor Name" value="<?php echo $row['sponsor_name']; ?>" readonly required> 
							</div>
							<label>Sponsor ID</label>
							<div class="input-group">
								<span class="fa fa-lock" aria-hidden="true"></span>
								<input type="text" name="sponsor_id" maxlength="9" placeholder="Enter Sponsor ID" value="<?php echo $row['sponsor_id']; ?>" readonly required>
							</div><br>

							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Update your details.</b></p></h3><br>
							<label>Applicant Name</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" name="applicant_name" placeholder="Enter Your Name" value="<?php echo $row['applicant_name']; ?>" required> 
							</div>
							<label>Applicant Mobile Number</label>
							<div class="input-group">
								<span class="fa fa-mobile" aria-hidden="true"></span>
								<input type="Number" name="applicant_mobile_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Mobile Number" value="<?php echo $row['applicant_mobile_number']; ?>" required>
							</div>
							<label>Applicant Email ID</label>
							<div class="input-group">
								<span class="fa fa-envelope" aria-hidden="true"></span>
								<input type="email" name="applicant_email_id" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Enter Your Email ID" value="<?php echo $row['applicant_email_id']; ?>" required>
							</div>	
						</div>
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Update your bank details.</b></p></h3><br>
							<label>Bank Name</label>
							<div class="input-group">
								<span class="fa fa-university" aria-hidden="true"></span>
								<input type="text" name="bank_name" placeholder="Enter Bank Name" value="<?php echo $row['bank_name']; ?>" required> 
							</div>
							<label>Branch Name</label>
							<div class="input-group">
								<span class="fa fa-map-marker" aria-hidden="true"></span>
								<input type="text" name="branch_name" placeholder="Enter Branch Name" value="<?php echo $row['branch_name']; ?>" required>
							</div>	
							<label>Account Number</label>
							<div class="input-group">
								<span class="fa fa-user-circle" aria-hidden="true"></span>
								<input type="number" name="account_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "16" placeholder="Enter Account Number" value="<?php echo $row['account_number']; ?>" required>
							</div>	
							<label>IFSC Code</label>
							<div class="input-group">
								<span class="fa fa-codepen" aria-hidden="true"></span>
								<input type="text" name="ifsc_code" maxlength = "11" placeholder="Enter IFSC Code" value="<?php echo $row['ifsc_code']; ?>" required>
							</div>	<br>
						</div>
						<div class="col-md-4" style="border:1px solid #34b99336;">
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Update your online wallet details.</b></p></h3><br>
							<label>Paytm Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="number" name="paytm_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Paytm Number" value="<?php echo $row['paytm_number']; ?>"> 
							</div>
							<label>PhonePe Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="number" name="phonepe_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your PhonePe Number" value="<?php echo $row['phonepe_number']; ?>">
							</div>	
							<label>Google Pay Number</label>
							<div class="input-group">
								<span class="fa fa-google" aria-hidden="true"></span>
								<input type="number" name="google_pay_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" placeholder="Enter Your Google Pay Number" value="<?php echo $row['google_pay_number']; ?>">
							</div>	<br>
							<h3><p><b style="font-weight: bold;font-size: 140%;color: #705ecf;">Do Not Update your pancard details.</b></p></h3><br>
							<label>Pancard Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="text" name="pancard_number" maxlength = "10" placeholder="Enter Your Pancard Number" value="<?php echo $row['pancard_number']; ?>"> 
							</div>
							<label>Adhar Number</label>
							<div class="input-group">
								<span class="fa fa-credit-card" aria-hidden="true"></span>
								<input type="text" name="adhar_number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "12" placeholder="Enter Your Adhar Number" value="<?php echo $row['adhar_number']; ?>" readonly required> 
							</div>
							<input class="btn btn-danger btn-block" type="submit" value="Update" name="update_user" /> 
						</div>
					</div>
				</form>
			</div>
		</div>


		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->

	</body>

</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>