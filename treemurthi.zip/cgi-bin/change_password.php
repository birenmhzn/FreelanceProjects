<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if($_SESSION["login_id"]) {
        $login_id = $_SESSION["login_id"];
        if(isset($_POST['update_password_btn']))
        {
        	
            $update_password = $_POST["update_password"];
            if (CRYPT_BLOWFISH == 1)
            {
                $passwordhash = crypt($update_password ,'$2y$10$123534103030000999999ua/hX436ma7wYcLu/mLx99tio.j.Hyq2'); 
            }
            else
            {   
                echo '<script>alert("Blowfish DES not supported.");
                window.location="login.php";</script>';
            }
                        
            $sql="UPDATE `tgroups_user` SET `applicant_password` = '$passwordhash',`decoded` = '$update_password' WHERE `tgroups_user`.`login_id` = '$login_id'";//`
            $runquery = mysqli_query($con,$sql);
            if($runquery)
        	{
                echo '<script>alert("Your password successfully updated....");
        			window.location="change_password.php";</script>';
        	}	
        	else
        	{ 
                echo '<script>alert("Error to change your password.");
        			window.location="change_password.php";</script>';
        	}
        }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Change Password</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Change Password</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="signupform">
			<div class="container">
				<!-- main content -->
				<div class="main-content">
					<div class="contect_left_form">
						<div class="left_grid_info">
							<h1>Manage Your Business Account</h1>
							<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
							<img src="images/image.jpg" alt="" />
						</div>
					</div>
					<div class="login_info">
						<h2>Change your password now</h2>
						<p>Enter your new password.</p>
						<form action="#" method="post">
							<label>Enter New Password</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="password" placeholder="Enter New Password" name="update_password" required> 
							</div> 						
							<input class="btn btn-danger btn-block" type="submit" value="Update Password" name="update_password_btn" /> 
              			</form>
					</div>
				</div>
				<!-- //main content -->
			</div>
		</div>
		
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>