<script type="text/javascript">
    window.onload=function(){
      document.getElementById("add_redirect").click();
    };
</script>
<?php
    include('sqlserverfiles/Config.php');
    session_start();
    if(isset($_POST['forget_password_btn']))
    {
        $forget_password_login_id = $_POST["forget_password_login_id"];
        $sql="SELECT `applicant_email_id` FROM `tgroups_user` WHERE `login_id` = '$forget_password_login_id' ORDER BY `id` DESC LIMIT 1";//`
        $runquery = mysqli_query($con,$sql);
        $row=mysqli_fetch_assoc($runquery);
        $applicant_email_id = $row['applicant_email_id'];
        if($runquery) 
    	{
            $encrypt_email = base64_encode($forget_password_login_id);
    		$decrypt_email = base64_decode($encrypt_email);
            
            $message = '<p>Dear Trimurthi Groups user...<br> Thank you for registered with us. Your Password recovery link are given below. Please <a href="http://trimurthigroups.com/update_password.php?lid='.$encrypt_email.'"> Click here to login with new password..</a></p>';
    		//to send HTML mail, the Content-type header must be set:
    		$headers = "From: noreply@trimurthigroups.com\r\n";
    		$headers .= "Reply-To: noreply@trimurthigroups.com\r\n";
    		$headers .= "MIME-Version: 1.0\r\n";
    		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    
    		$subject = "Update New Password";
    		//mail function
    		$mail = mail($applicant_email_id, $subject, $message, $headers);
    		if($mail)
    		{
    			echo '<script>alert("Your Password Recovery Link Has Been Sent To Your Email Please Check the mail...");
    			window.location="login.php";</script>';
    		}	
    		else
    		{ 
    			echo "Error sending email..."; 
    		}
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Forget Password</title>
	 <!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
		
		<link href="css/LoginStyle.css" rel="stylesheet" type="text/css" media="all"/>
		<!-- //css files -->
	</head>
	<body>

		<!-- main banner -->
		<div class="main-top" id="home">
			
			<!-- header -->
			<header>
				<?php include "header.php"; ?>
			</header>
			<!-- //header -->

			<!-- banner -->
			<div class="banner_temps-amklspvt-2">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="index.php" class="font-weight-bold">Home</a></li>
					<li class="breadcrumb-item" aria-current="page">Forget Password</li>
				</ol>
			</div>
			<!-- //banner -->
		</div>
		<!-- //main banner -->

		<div class="signupform">
			<div class="container">
				<!-- main content -->
				<div class="main-content">
					<div class="contect_left_form">
						<div class="left_grid_info">
							<h1>Manage Your Business Account</h1>
							<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
							<img src="images/image.jpg" alt="" />
						</div>
					</div>
					<div class="login_info">
						<h2>Forget password DON'T WORRY!!</h2>
						<p>Enter your details to retrive your password.</p>
						<form action="#" method="post">
							<label>Login ID</label>
							<div class="input-group">
								<span class="fa fa-user" aria-hidden="true"></span>
								<input type="text" placeholder="Enter Your Login ID" name="forget_password_login_id" required> 
							</div> 						
							<input class="btn btn-danger btn-block" type="submit" value="Submit" name="forget_password_btn" /> 
              			</form>
						<p class="account1"><a href="login.php">Login</a></p>
					</div>
				</div>
				<!-- //main content -->
			</div>
		</div>
		
		<!-- copyright bottom -->
		<div class="copy-bottom bg-li py-4 border-top">
			<?php include "footer.php"; ?>
		</div>
		<!-- //copyright bottom -->
		
	</body>
</html>