<?php
    include('sqlserverfiles/Config.php');
    session_set_cookie_params(0);
    session_start();
    if($_SESSION["login_id"]) {
        $login_id = $_SESSION["login_id"];
    //$message = "Make payment first.";
    //echo "<script>alert('$message');</script>";
    //$url=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    //echo $url;
    //$myArray = explode('?', $url);
    //$login_id = $myArray[1];
?>
<script type="text/javascript">
	window.onload=function(){
	  document.getElementById("add_redirect").click();
	};
</script>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Make Payment</title>
	 	<!-- Meta-Tags -->
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta charset="utf-8">
	    <meta name="keywords" content="Trimurthi Groups, Groups, Trimurthi, How to make money, Make money online, Business Login Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
		    <button type="button" style="display: none;" id="add_redirect" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

		    <!-- Modal -->
		    <div class="modal fade" data-keyboard="false" data-backdrop="static" id="myModal" role="dialog">
			    <div class="modal-dialog">
		    		<div class="modal-content">
				        <div class="modal-header">
				    	    <h4 class="modal-title">Trimurthi Groups</h4>
				        </div>
				        <div class="modal-body">
				        	<h3>Make Payment 250 Rupees/- <a href="https://www.instamojo.com/@TriGroups/l2d306f0fd69f490bb987578624b2cc7e/" rel="im-checkout" data-behaviour="remote" data-style="flat" data-text="Pay"></a>
<script src="https://js.instamojo.com/v1/button.js"></script>
				        	<h3><a href="logout.php"><h3><b>Close</b></h3></a>
				        </div>
				    </div>
				</div>
			</div>
		</div>
	</body>
</html>
<?php
    }
    else 
    {
        echo "<script>
                alert('Please login first!');
                window.location = 'login.php';
            </script>";
    }
?>