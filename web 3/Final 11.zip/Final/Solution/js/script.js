function partner() {
    var checkBox = document.getElementById("marriedCheck");
    var text = document.getElementById("hide-partner");
    if (checkBox.checked == true){
        text.style.display = "block";
    } else {
       text.style.display = "none";
    }
}
function display_preferred_accommodation(){

    var name=document.getElementById("name").value;
    var address=document.getElementById("address").value;
    var dob=document.getElementById("dob").value;
    var email=document.getElementById("email").value;
    var occupation=document.getElementById("occupation").value;

	var married = document.getElementById("marriedCheck").checked;
	
	if(married){
		    var partner_name=document.getElementById("partner_name").value;
			var partner_occupation=document.getElementById("partner_occupation").value;
			var partner_dob=document.getElementById("partner_dob").value;
			var partner_gender=document.getElementById("partner_gender").value;
			
			var how_active=document.getElementById("how_active").value;

			if(name != "" && address != "" && dob != "" && email != "" && occupation != "" && partner_gender != "" && partner_dob != "" && partner_occupation != "" && partner_name != "" && how_active != "")
			{   
				var dis1 = document.getElementById("index");
				dis1.style.display = "none";
				var dis2 = document.getElementById("preferred_accommodation");
				dis2.style.display = "block";
			}
			else
			{
				alert("All fields must be filled out.");
			}
	} else{
			var how_active=document.getElementById("how_active").value;

			if(name != "" && address != "" && dob != "" && email != "" && occupation != "" && how_active != "")
			{   
				var dis1 = document.getElementById("index");
				dis1.style.display = "none";
				var dis2 = document.getElementById("preferred_accommodation");
				dis2.style.display = "block";
			}
			else
			{
				alert("All fields must be filled out.");
			}
	}
	    
}

function preferred_modes_of_travel(){

    var preferred_accommodation_room=document.getElementById("preferred_accommodation_room").value;
    var preferred_accommodation_bed_breakfast_with=document.getElementById("preferred_accommodation_bed_breakfast_with").value;

    if(preferred_accommodation_room != "" && preferred_accommodation_bed_breakfast_with != "")
    {
        var dis1 = document.getElementById("index");
        dis1.style.display = "none";
        var dis2 = document.getElementById("preferred_accommodation");
        dis2.style.display = "none";
        var dis3 = document.getElementById("preferred_modes_of_travel");
        dis3.style.display = "block"; 
    }
    else
    {
        alert("All fields must be filled out.");
    }   
}
function preferred_travel_environment2(){

    var preferred_modes_of_travel_air = document.getElementById("preferred_modes_of_travel_air").value;
    var preferred_modes_of_travel_water = document.getElementById("preferred_modes_of_travel_water").value;

    if(preferred_modes_of_travel_air != "" && preferred_modes_of_travel_water != "")
    {
        var dis1 = document.getElementById("index");
        dis1.style.display = "none";
        var dis2 = document.getElementById("preferred_accommodation");
        dis2.style.display = "none";
        var dis3 = document.getElementById("preferred_modes_of_travel");
        dis3.style.display = "none"; 
        var dis = document.getElementById("preferred_travel_environment");
        dis.style.display = "block";  
    }
    else
    {
        alert("All fields must be filled out.");
    }     
}
function preferred_travel_environment(){

    var preferred_destination_africa=document.getElementById("preferred_destination_africa").value;
    var preferred_destination_asia=document.getElementById("preferred_destination_asia").value;
    var preferred_destination_central_america=document.getElementById("preferred_destination_central_america").value;
    var preferred_destination_europe=document.getElementById("preferred_destination_europe").value;
    var preferred_destination_europe_union=document.getElementById("preferred_destination_europe_union").value;
    var preferred_destination_middle_east=document.getElementById("preferred_destination_middle_east").value;
    var preferred_destination_north_america=document.getElementById("preferred_destination_north_america").value;
    var preferred_destination_oceania=document.getElementById("preferred_destination_oceania").value;
    var preferred_destination_south_america=document.getElementById("preferred_destination_south_america").value;
    var preferred_destination_the_caribbean=document.getElementById("preferred_destination_the_caribbean").value;

    if(preferred_destination_africa != "" && preferred_destination_asia != "" && preferred_destination_central_america != "" && preferred_destination_europe != "" && preferred_destination_europe_union != "" && preferred_destination_middle_east != "" && preferred_destination_north_america != "" && preferred_destination_oceania != "" && preferred_destination_south_america != "" && preferred_destination_the_caribbean != "")
    {
        var dis1 = document.getElementById("index");
        dis1.style.display = "none";
        var dis2 = document.getElementById("preferred_accommodation");
        dis2.style.display = "none";
        var dis3 = document.getElementById("preferred_modes_of_travel");
        dis3.style.display = "none"; 
        var dis = document.getElementById("preferred_travel_environment");
        dis.style.display = "block";  
    }
    else
    {
        alert("All fields must be filled out.");
    }     
}

function display_child_div(){
    var myselect = document.getElementById("display_child_div1");
    var o=myselect.options[myselect.selectedIndex].value;

    switch(o)
    {
        case "1":
            document.getElementById("child-group1").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 1</h1><br><input class='inloc' type='text' name='children_name1' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date1'  ><br><select class='inloc' name='children_gender1'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
        break;
        case "2":
            document.getElementById("child-group2-1").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 1</h1><br><input class='inloc' type='text' name='children_name1' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date1'  ><br><select class='inloc' name='children_gender1'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group2-2").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 2</h1><br><input class='inloc' type='text' name='children_name2' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date2'  ><br><select class='inloc' name='children_gender2'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
        break;
        case "3":
            document.getElementById("child-group3-1").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 1</h1><br><input class='inloc' type='text' name='children_name1' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date1'  ><br><select class='inloc' name='children_gender1'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group3-2").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 2</h1><br><input class='inloc' type='text' name='children_name2' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date2'  ><br><select class='inloc' name='children_gender2'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group3-3").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 3</h1><br><input class='inloc' type='text' name='children_name3' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date3'  ><br><select class='inloc' name='children_gender3'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
        break;
        case "4":
            document.getElementById("child-group4-1").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 1</h1><br><input class='inloc' type='text' name='children_name1' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date1'  ><br><select class='inloc' name='children_gender1'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group4-2").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 2</h1><br><input class='inloc' type='text' name='children_name2' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date2'  ><br><select class='inloc' name='children_gender2'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group4-3").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 3</h1><br><input class='inloc' type='text' name='children_name3' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date3'  ><br><select class='inloc' name='children_gender3'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
            document.getElementById("child-group4-4").innerHTML ="<link href='css/style.css' rel='stylesheet'><center><div class='container' style='width:100%;'><center><h1>Children : 4</h1><br><input class='inloc' type='text' name='children_name4' placeholder='Enter Child Name'  ><br><input class='inloc' type='date' name='children_date4'  ><br><select class='inloc' name='children_gender4'  ><option value='gender'>GENDER</option><option value='male'>MALE</option><option value='female'>FEMALE</option></select></center></div></center>";
        break;
        case "0":
            
        document.getElementById( 'child-group1' ).style.display = 'none';
        document.getElementById( 'child-group2-1' ).style.display = 'none';
        document.getElementById( 'child-group2-2' ).style.display = 'none';
        document.getElementById( 'child-group3-1' ).style.display = 'none';
        document.getElementById( 'child-group3-2' ).style.display = 'none';
        document.getElementById( 'child-group3-3' ).style.display = 'none';
        document.getElementById( 'child-group4-1' ).style.display = 'none';
        document.getElementById( 'child-group4-2' ).style.display = 'none';
        document.getElementById( 'child-group4-3' ).style.display = 'none';
        document.getElementById( 'child-group4-4' ).style.display = 'none';
        break;
    }

    if (o==1) 
    {
        document.getElementById( 'child-group1' ).style.display = 'block';
        document.getElementById( 'child-group2-1' ).style.display = 'none';
        document.getElementById( 'child-group2-2' ).style.display = 'none';
        document.getElementById( 'child-group3-1' ).style.display = 'none';
        document.getElementById( 'child-group3-2' ).style.display = 'none';
        document.getElementById( 'child-group3-3' ).style.display = 'none';
        document.getElementById( 'child-group4-1' ).style.display = 'none';
        document.getElementById( 'child-group4-2' ).style.display = 'none';
        document.getElementById( 'child-group4-3' ).style.display = 'none';
        document.getElementById( 'child-group4-4' ).style.display = 'none';
    }
    else if (o==2)
    {
        document.getElementById( 'child-group2-1' ).style.display = 'block';
        document.getElementById( 'child-group2-2' ).style.display = 'block';
        document.getElementById( 'child-group1' ).style.display = 'none';
        document.getElementById( 'child-group3-1' ).style.display = 'none';
        document.getElementById( 'child-group3-2' ).style.display = 'none';
        document.getElementById( 'child-group3-3' ).style.display = 'none';
        document.getElementById( 'child-group4-1' ).style.display = 'none';
        document.getElementById( 'child-group4-2' ).style.display = 'none';
        document.getElementById( 'child-group4-3' ).style.display = 'none';
        document.getElementById( 'child-group4-4' ).style.display = 'none';
    }
    else if (o==3)
    {
        document.getElementById( 'child-group3-1' ).style.display = 'block';
        document.getElementById( 'child-group3-2' ).style.display = 'block';
        document.getElementById( 'child-group3-3' ).style.display = 'block';
        document.getElementById( 'child-group1' ).style.display = 'none';
        document.getElementById( 'child-group2-1' ).style.display = 'none';
        document.getElementById( 'child-group2-2' ).style.display = 'none';
        document.getElementById( 'child-group4-1' ).style.display = 'none';
        document.getElementById( 'child-group4-2' ).style.display = 'none';
        document.getElementById( 'child-group4-3' ).style.display = 'none';
        document.getElementById( 'child-group4-4' ).style.display = 'none';
    }
    else if (o==4)
    {
        document.getElementById( 'child-group4-1' ).style.display = 'block';
        document.getElementById( 'child-group4-2' ).style.display = 'block';
        document.getElementById( 'child-group4-3' ).style.display = 'block';
        document.getElementById( 'child-group4-4' ).style.display = 'block';
        document.getElementById( 'child-group1' ).style.display = 'none';
        document.getElementById( 'child-group2-1' ).style.display = 'none';
        document.getElementById( 'child-group2-2' ).style.display = 'none';
        document.getElementById( 'child-group3-1' ).style.display = 'none';
        document.getElementById( 'child-group3-2' ).style.display = 'none';
        document.getElementById( 'child-group3-3' ).style.display = 'none';
    }
    else if (o===0)
    {
        document.getElementById( 'child-group1' ).style.display = 'none';
        document.getElementById( 'child-group2-1' ).style.display = 'none';
        document.getElementById( 'child-group2-2' ).style.display = 'none';
        document.getElementById( 'child-group3-1' ).style.display = 'none';
        document.getElementById( 'child-group3-2' ).style.display = 'none';
        document.getElementById( 'child-group3-3' ).style.display = 'none';
        document.getElementById( 'child-group4-1' ).style.display = 'none';
        document.getElementById( 'child-group4-2' ).style.display = 'none';
        document.getElementById( 'child-group4-3' ).style.display = 'none';
        document.getElementById( 'child-group4-4' ).style.display = 'none';
    }
}

