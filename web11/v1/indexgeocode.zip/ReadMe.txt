Walkscore readme file.

There are 2 APIs used to get result.
live link : http://walkscore-001-site1.atempurl.com

--> First API is from cloudflare.com to get places names in typeahead textbox and catching respective places langitude and latitude.
    link: cloudflare.com
    API javascript link:https://cdn.polyfill.io/v2/polyfill.js?features=es5,Promise,fetch
                        https://unpkg.com/@esri/arcgis-rest-request@1.14.3/dist/umd/request.umd.min.js
                        https://unpkg.com/@esri/arcgis-rest-geocoder@1.14.3/dist/umd/geocoder.umd.min.js

--> Second one is to get accurate walkscore4 from walkscore.com
    link: walkscore.com
    APIlink:  http://api.walkscore.com/score?format=json&address=$address&lat=$lat&$lon&wsapikey=bd137b89d85dfdd9e511b0f787f84296

How to

--> First we have to enter the location name in search textbox. 
	--> It will give you more than one suggestions in drop down list that fetched from www.cloudflare.com JS links.

--> Select the accurate location from drop down list.
	--> Then it fetched the latitude and longitude of respective location and display it in hidden input box.

--> Click on search button to find the walkscore of respective location.
	--> After clicking its post the location address, latitude and longitude that are fetched from www.cloudflare.com.
	--> All required details post to www.walkscore.com API and walkscore API fetched the accurate walkscore and response as JSON object.
	--> JSON object decoded using PHP and prints the walkscore.

--> You can see the walkscore that fetched from walkscore.com API.