<?php
	session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>About</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"> <!-- CSS file link -->
	</head>
	<body class="background-color-white">
		<!-- Webpage body starts from here -->
		<!-- Header starts -->
		<?php include "header.php"; ?>
		<!-- Header ends -->

		<br>
		
		<div>
			<center>
				<div class="width-70">
					<table class="table">
						<tr>
							<td class="width-30 verticle-align-middle">
								<img src="img/8.jpg" width="320" height="490" class="margin-top-20">
							</td>
							<td class="verticle-align-top padding-left-2">
								<a href="index.php" class="text-decoration-none">Home</a> / <b>About</b>
								<br>
								<h1><font class="font-color-pink">About Us</font></h1>
								<hr class="width-70 float-left">
								<br>
								<p>
									Myflower is global flower suppliers since 1980. We started our journey from Mumbai.<br><br>
									Our founder Mr.XYZ ABC who is successful business man of india decide to enter
									flowers business in 1979. Till now Mr. XYZ ABC's wife Mrs. DEF HIJ with him in
									each and every business decision.<br><br>
									In 2003 we started selling flowers online, take online orders and do door to door
									flower delivery service.<br><br>
									Now MyFlower gives services in more than 20 countries all over the world and recently
									we open our new branch in New York,USA<br><br>
									We successfully open 1220 shops all over the india and sold more than 10 lacs flowers
									from that shops.<br><br>
									Till today's date we earn more than 10 lacs happy customers and we have
									12000 happy staff.<br><br>
									We have more than five thousand verieties of different flowers.
								</p>
							</td>
						</tr>
					</table>

					<!-- Footer starts from here -->
					<div>
						<center>
							<h3><b>© MyFlower 2019 All Rights Reserved.</b></h3>
						</center>
					</div>
					<!-- Footer ends here -->

				</div>
			</center>
		</div>

		<!-- Webpage body Ends here -->
	</body>
</html>