<?php
	session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Contact</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"> <!-- CSS file link -->
	</head>
	<body class="background-color-white">
		<!-- Webpage body starts from here -->
		<!-- Header starts -->		
		<?php include "header.php"; ?>
		<!-- Header ends -->

		<br>
		
		<div>
			<center>
				<div class="width-70">
					<table class="table">
						<tr>
							<td class="width-30">
								<img src="img/1.jpg" width="320" height="470">
							</td>
							<td class="verticle-align-top padding-left-2">
								<a href="index.php" class="text-decoration-none">Home</a> / <b>Contact</b>
								<br>
								<h1><font class="font-color-pink">Contact Us</font></h1>
								<hr class="width-70 float-left">
								<br>
								<p>
									<b>Email : </b> support@myflower.com
									<br>
									<b>Phone : </b> +91 1234567890
									<br>
									<b>Office Address : </b>Shop No. 103, Indrapark Estate, Thane (W).
								</p>
								<br><br>
								<h1><font class="font-color-pink">Follow Us</font></h1>
								<hr class="width-70 float-left">
								<br>
								<a href="#"><img src="img/fb.jpg" width="40" height="40"></a>
								<a href="#"><img src="img/google.jpg" width="40" height="40"></a>
								<a href="#"><img src="img/youtube.jpg" width="40" height="40"></a>
							</td>
						</tr>
					</table>

					<!-- Footer starts from here -->
					<div>
						<center>
							<h3><b>© MyFlower 2019 All Rights Reserved.</b></h3>
						</center>
					</div>
					<!-- Footer ends here -->

				</div>
			</center>
		</div>

		<!-- Webpage body Ends here -->
	</body>
</html>